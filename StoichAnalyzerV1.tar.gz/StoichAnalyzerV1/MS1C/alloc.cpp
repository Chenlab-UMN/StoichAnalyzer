#include "alloc.h"

Collector::Collector(char* stt, int ssz){
	start = stt;
	freebegin = stt;
	size = ssz;
	freesize = ssz;
//	memset(stt,0,ssz);
	return;
}

char* Collector::i_malloc(int i){
	char* newbegin;
	if(freesize < i) return NULL;
	newbegin = freebegin;
	freebegin += i;
	freesize -= i;
	return (newbegin);
}

void Collector::i_free(char* pos, int size){
	if(freebegin > (pos+size)) return;
	freebegin -= size;
	freesize += size;
//	memset(pos,0,size);
	return;
}
