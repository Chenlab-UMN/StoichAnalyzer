struct column0
{
  int scan_index;
  int scan_num;
  float R_time;
  float mz1;
  double intensiT;
  double intensiT2;
  double intensmooth;
};

struct intern_calib
{
  float mz;
  float time;
  int scannum;
};

double PPintegrator(char*, int, float, int, int, float*, float*, float*, int*,float,int,int*,float*,float*,float*,float*);
double noise_level(char*, int);
double PPintegratorA(char*, int, float, int, int, float*, float*, float*, int*,float,int,int*,float*,float*,vector<struct intern_calib>&);
double PPintegratorB(char*, int, float, int, int, float*, float*, float*, int*,float,int,int*,float*,float*,float,int, vector<struct intern_calib>&);
