#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <algorithm>
#include <string.h>

using namespace std;

//double PPintegrator(char*, int, double, int);
double PPintegrator(char*, int, float, int, int, float*, float*, float*, int*,float,int,int*,float*,float*,float*,float*);

double noise_level(char*, int);

struct ms1key
{
  string familyseq;
  string seq;
  int charge;
  float mz_ms1;
  string rawfname;
  int scannum;
  int ms1peak_order;
  int num_of_K;
  int MS2exist_indicator;
};

struct info_MS1_of_an_MS1peak
{
  int charge;
  float mz_ms1;
  string rawfname;
  int scannum;
  int ms1peak_order;
  int MS2exist_indicator;
  std::vector<float> MS2_stoich;////size should be num of sites.
};

struct seqfamily
{
  string familyseq;
  int num_of_K;
  int execute;
  std::vector<info_MS1_of_an_MS1peak> ms1p;
  //info_MS1_of_an_MS1peak ms1p[5];
};

struct masspeakpair
{
  double prob;
  double mass;
};
void NID_calculator(int data[], vector<masspeakpair> & v);

struct MS2word
{
  string familyseq;
  int ms1peak_order;
  std::vector<float> site_stoich;
};


struct peakms2
{
  int ms1peak_order;
  std::vector<float> GreekL_frac; 
  //GreekL_frac[0] is alphaL_frac, the occupancies of light at alpha site; GreekL_frac[1] is betaL_frac,...;
};

struct ms2dictionaryword
{
  string familyseq;
  std::vector<peakms2> peak; 
};


struct shapeparameterinput
{
  float max_R_time;
  float max_s_inten;
  float starting_time;
  float end_time;
  float array_starting_time;
  float array_end_time;
};


struct intern_calib
{
  float mz;
  float time;
  int scannum;
};

double PPintegratorA(char*, int, float, int, int, float*, float*, float*, int*,float,int,int*,float*,float*,float*,float*,std::vector<intern_calib>& b);
double PPintegratorB(char*, int, float, int, int, float*, float*, float*, int*,float,int,int*,float*,float*,float*,float*,float,int,std::vector<intern_calib>& bb, int);
//double PPintegratorB(char*, int, float, int, int, float*, float*, float*, int*,float,int,int*,float*,float*,float*,float*,float,int,struct intern_calib *bb,int);

