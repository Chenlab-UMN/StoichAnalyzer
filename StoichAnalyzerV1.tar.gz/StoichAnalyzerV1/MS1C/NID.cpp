// In this program, there are two major functions:
// get_product() and pick_n_merge()
// the output of get_product() is named emily here.
// emily is a vector of "masspeakpair." (masspeakpair is an 
// ordered pair represents mass and probabilty.
// emily is of more decimal digits.
// emily is under the condition that peak overlapping is 
// not considered. That is why we have ashley after the 
// process of pick_n_merge()
// molly is just an internal variable.
// emily was assigned to the value of molly at the end of get_product()
// ashley as assigned to the value of molly at the end of pick_n_merge() 

#include <iostream>
#include <vector>
#include <string>
#include <math.h>
#include <fstream>
#include <stdlib.h>     /* atoi */

using namespace std;

double factorial0(int n){
        double temp;
        if(n <= 1) return 1;
        temp = (double) n * factorial0(n - 1);
        return temp;
}

double combination0(int n, int r){
        return ((double) factorial0(n)/(factorial0(r)*factorial0(n-r)));
}

struct masspeakpair
{
    double prob;
    double mass;
};

struct masspeaktrio
{
    double prob;
    double mass;
    double mass_dis_from_prev;
};


class natural_distr{
    public:
	natural_distr(){
	}
	int getproduct(){
	    return num_c*num_o;
	}
	void set_num_c(int x){
	    num_c =x;
	}
        void set_num_o(int x){
            num_o =x;
        }
        void set_num_h(int x){
            num_h =x;
        }
	void set_num_n(int x){
            num_n =x;
        }
	void set_num_s(int x){
            num_s =x;
        }

	void set_merge_mass_range(double x){
            difference =x;
        }
	double * get_prob_c();
	std::vector<masspeakpair> get_product();
	std::vector<masspeakpair> pick_n_merge(double a, double b);
	vector<masspeakpair> emily;
	vector<masspeakpair> ashley;
    private:
	int num_c;
	int num_o;
	int num_h;
	int num_n;
	int num_s;
	double difference;
	double prob_c[2], prob_o[3], prob_h[2], prob_n[2], prob_s[4];
	double mass_c[2], mass_o[3], mass_h[2], mass_n[2], mass_s[4];
        void load_prob();
	void load_mass();
	//vector<masspeakpair> emily;
        std::vector<double> get_sub_product_c();
        std::vector<double> get_sub_product_o();
        std::vector<double> get_sub_product_h();
        std::vector<double> get_sub_product_n();
        std::vector<double> get_sub_product_s();
	std::vector<double> get_sub_mass_c();
	std::vector<double> get_sub_mass_o();
	std::vector<double> get_sub_mass_h();
        std::vector<double> get_sub_mass_n();
        std::vector<double> get_sub_mass_s();
};

double * natural_distr::get_prob_c(){
        load_prob();
        return &prob_c[0];
        }
void natural_distr::load_prob(){
        prob_c[0]=0.9893;  prob_c[1]=0.0107;
        prob_o[0]=0.99757; prob_o[1]=0.00038; prob_o[2]=0.00205;
        prob_h[0]=0.999885;prob_h[1]=0.000115;
        prob_n[0]=0.99632; prob_n[1]=0.00368;
        prob_s[0]=0.9493;  prob_s[1]=0.0076;
        prob_s[2]=0.0429;  prob_s[3]=0.0002;
        }
void natural_distr::load_mass(){
        mass_c[0]=12.0000; 	mass_c[1]=13.00335484;
        mass_o[0]=15.99491462; 	mass_o[1]=16.9991315; mass_o[2]=17.9991604;
        mass_h[0]=1.007825032;	mass_h[1]=2.014101778;
	mass_n[0]=14.00307401;  mass_n[1]=15.0001089;
	mass_s[0]=31.97207069;  mass_s[1]=32.9714585;
	mass_s[2]=33.96786683;  mass_s[3]=35.96708088;
        }

std::vector<double> natural_distr::get_sub_product_c(){
        load_prob();
        int i;
        double a00,a01,a02;
	std::vector<double> cc(num_c+1);
	for (i=0; i<=num_c; i++){
	    a00 = combination0(num_c,i);
	    a01 = pow(prob_c[0],num_c-i);
	    a02 = pow(prob_c[1],i);
	    cc[i]= a00*a01*a02;
	}   
	return cc;
	}

std::vector<double> natural_distr::get_sub_product_h(){
        load_prob();
        int i;
        double a00,a01,a02;
        std::vector<double> cc(num_h+1);
        for (i=0; i<=num_h; i++){
            a00 = combination0(num_h,i);
            a01 = pow(prob_h[0],num_h-i);
            a02 = pow(prob_h[1],i);
            cc[i]= a00*a01*a02;
        }
        return cc;
        }

std::vector<double> natural_distr::get_sub_product_o(){
        load_prob();
        int i,j,k;
	int size_o=(num_o+1)*(num_o+2)/2;
        double a00,a01,b00,b01,b02;
	std::vector<double> cc(size_o);
	k=0;
        for (i=0; i<=num_o; i++){
	    a00 = combination0(num_o,i);
	    a01 = pow(prob_o[0],num_o-i);//num_o-i is the number of 16_O
	    for (j=0;j<=i;j++){         //i is the sum of other two isotopes.
		b00 = combination0(i,j);
		b01 = pow(prob_o[1],i-j);//i-j is the number of 17_O
		b02 = pow(prob_o[2],j);
		cc[k]= a00*a01*b00*b01*b02;
//		cout <<"k= "<<k<<"  c="<<cc[k]<<"    #16_O="<< num_o-i <<"    #17_O="<<i-j<<"   #18_O="<<j<<endl;
		k++;
	    }
        }
        return cc;  //&cc[0];
        }

std::vector<double> natural_distr::get_sub_product_n(){
  load_prob();
  int i;
  double a00,a01,a02;
  std::vector<double> cc(num_n+1);
  for (i=0; i<=num_n; i++){
    a00 = combination0(num_n,i);
    a01 = pow(prob_n[0],num_n-i);
    a02 = pow(prob_n[1],i);
    cc[i]= a00*a01*a02;
  }
  return cc;
}

std::vector<double> natural_distr::get_sub_product_s(){
  load_prob();
  int i,j,k,jj;
  int size_s=(num_s+1)*(num_s+2)*(num_s+3)/6;
  double a00,a01,b00,b01,c00,c01,c02;
  std::vector<double> cc(size_s);
  k=0;
  for (i=0; i<=num_s; i++){
    a00 = combination0(num_s,i);
    a01 = pow(prob_s[0],num_s-i);//num_o-i is the number of 26_S
    for (j=0;j<=i;j++){         //i is the sum of other three isotopes.
      b00 = combination0(i,j);
      b01 = pow(prob_s[1],i-j);//i-j is the number of 27_S
      for (jj=0;jj<=j;jj++){
	c00 = combination0(j,jj);
	c01 = pow(prob_s[2],j-jj);
	c02 = pow(prob_s[3],jj);
        cc[k]= a00*a01*b00*b01*c00*c01*c02;
      //              cout <<"k= "<<k<<"  c="<<cc[k]<<"    #16_O="<< num_o-i <<"    #17_O="<<i-j<<"   #18_O="<<j<<endl;
        k++;
	}
    }
  }
  return cc;  //&cc[0];
}


std::vector<double> natural_distr::get_sub_mass_c(){
        load_mass();
        int i;
        double a01,a02;
        std::vector<double> cc(num_c+1);
        for (i=0; i<=num_c; i++){
            a01 = mass_c[0]*(num_c-i);
            a02 = mass_c[1]*i;
            cc[i]= a01+a02;
        }
        return cc;
}

std::vector<double> natural_distr::get_sub_mass_h(){
        load_mass();
        int i;
        double a01,a02;
        std::vector<double> cc(num_h+1);
        for (i=0; i<=num_h; i++){
            a01 = mass_h[0]*(num_h-i);
            a02 = mass_h[1]*i;
            cc[i]= a01+a02;
        }
        return cc;
}


std::vector<double> natural_distr::get_sub_mass_o(){
        load_mass();
        int i,j,k;
        int size_o=(num_o+1)*(num_o+2)/2;
        double a01,b01,b02;
        std::vector<double> cc(size_o);
        k=0;
        for (i=0; i<=num_o; i++){
            a01 = mass_o[0]*(num_o-i);//num_o-i is the number of 16_O
            for (j=0;j<=i;j++){         //i is the sum of other two isotopes.
                b01 = mass_o[1]*(i-j);//i-j is the number of 17_O
                b02 = mass_o[2]*j;
                cc[k]= a01+b01+b02;
                k++;
            }
        }
        return cc;  //&cc[0];
        }

std::vector<double> natural_distr::get_sub_mass_n(){
        load_mass();
        int i;
        double a01,a02;
        std::vector<double> cc(num_n+1);
        for (i=0; i<=num_n; i++){
            a01 = mass_n[0]*(num_n-i);
            a02 = mass_n[1]*i;
            cc[i]= a01+a02;
        }
        return cc;
}


std::vector<double> natural_distr::get_sub_mass_s(){
        load_mass();
        int i,j,k,jj;
        int size_s=(num_s+1)*(num_s+2)*(num_s+3)/6;
        double a01,b01,c01,c02;
        std::vector<double> cc(size_s);
        k=0;
        for (i=0; i<=num_s; i++){
	  a01 = mass_s[0]*(num_s-i);//num_o-i is the number of 16_O
	  for (j=0;j<=i;j++){         //i is the sum of other two isotopes.
	    b01 = mass_s[1]*(i-j);//i-j is the number of 17_O
	    for (jj=0; jj<=j; jj++){
	      c01 = mass_s[2]*(j-jj);
	      c02 = mass_s[3]*jj;
	      cc[k]= a01+b01+c01+c02;
	      k++;
	    }
	  }
	}
	return cc;  //&cc[0];
}


std::vector<masspeakpair> natural_distr::get_product(){
    std::vector<double> pro_c;
    std::vector<double> pro_o;
    std::vector<double> pro_h;
    std::vector<double> pro_n;
    std::vector<double> mas_c;
    std::vector<double> mas_o;
    std::vector<double> mas_h;
    std::vector<double> mas_n;
    std::vector<masspeakpair> molly;
    unsigned i,j,k,el,m,q=0;
    double t,temp_m,temp_p;
//    std::vector<double> pro_s;
//    std::vector<double> mas_s;
    pro_c = get_sub_product_c();
    pro_o = get_sub_product_o();
    pro_h = get_sub_product_h();
    pro_n = get_sub_product_n();
    mas_c = get_sub_mass_c();
    mas_o = get_sub_mass_o();
    mas_h = get_sub_mass_h();
    mas_n = get_sub_mass_n();

    if (num_s != 0) {
        cout << "XXXXXXYYYYYTTT1"<<endl;
        std::vector<double> pro_s;
        std::vector<double> mas_s;
	pro_s = get_sub_product_s();
	mas_s = get_sub_mass_s();

    for (i=0; i < (pro_c.size()); i++){
        if (pro_c[i] > 1.00e-06){
        for (j=0; j < (pro_o.size()); j++){
            if (pro_o[j] > 1.00e-06){
            for (k=0; k < (pro_h.size()); k++){
                if(pro_h[k] > 1.00e-06){
                for (el=0; el < (pro_n.size()); el++){
                    if(pro_n[el] > 1.00e-06){
                    t = pro_c[i]*pro_o[j]*pro_h[k]*pro_n[el];
		    for (m=0; m < (pro_s.size()); m++){
                        if((pro_s[m] > 1.00e-06)&&(t > 1.00e-03)){
                        	molly.push_back(masspeakpair());
                             	molly[q].prob=t*pro_s[m];
                            	molly[q].mass=mas_c[i]+mas_o[j]+mas_h[k]+mas_n[el]+mas_s[m];
                               	q++;
			}
                    }//for
                    }//if
                }
                }
            }//for
            }//if
        }
        }
    }//for
    } else { //(num_s == 0)
    for (i=0; i < (pro_c.size()); i++){
	if (pro_c[i] > 1.00e-06){ 
	for (j=0; j < (pro_o.size()); j++){
	    if (pro_o[j] > 1.00e-06){
	    for (k=0; k < (pro_h.size()); k++){
		if(pro_h[k] > 1.00e-06){
		for (el=0; el < (pro_n.size()); el++){
		    if(pro_n[el] > 1.00e-06){
		    	t = pro_c[i]*pro_o[j]*pro_h[k]*pro_n[el];
		    	if(t > 1.00e-09){
			    molly.push_back(masspeakpair());//push back (or say create) a new object 
			//Now modify it
			    molly[q].prob=t;
			    molly[q].mass=mas_c[i]+mas_o[j]+mas_h[k]+mas_n[el];
//			cout <<el<<"  "<<molly[el].prob<<"  "<< molly[el].mass<<endl;
			    q++;
			}
		    }	
		}
		}
	    }//for
	    }//if
	}
	}
    }//for
    }//if (num_s == 0)

    //SORTING BY MASS
    for (i=0; i < (molly.size()-1); i++){
	for (j=i; j< (molly.size()); j++){
	    if (molly[i].mass > molly[j].mass){
		temp_m=molly[j].mass; 
		molly[j].mass=molly[i].mass; 
		molly[i].mass=temp_m;
		temp_p=molly[j].prob; 
		molly[j].prob=molly[i].prob; 
		molly[i].prob=temp_p;
	    }
	}
    }
    return molly;
}//end of function natural_distr::get_product()

std::vector<masspeakpair> natural_distr::pick_n_merge(double prob_thr, double mass_thr){
    std::vector<masspeakpair> molly;
    std::vector<masspeaktrio> willy;
    unsigned i,k,token;
    double temp_mass, temp_prob, sum_willy_massdis;
    k=0;
    for (i=0; i < emily.size(); i++){
        if (emily[i].prob > prob_thr){
            willy.push_back(masspeaktrio());
            willy[k].prob=emily[i].prob;
            willy[k].mass=emily[i].mass;
            if (k==0){
                willy[k].mass_dis_from_prev=0;//prevent k-1 segmentation fault;
            }else{
                willy[k].mass_dis_from_prev=willy[k].mass-willy[k-1].mass;
            }
            k++;
        }
    }

  i=0; token=0; k=0;
  while(i < willy.size()){
    sum_willy_massdis=0.0000;
    temp_mass=willy[token].mass;
    temp_prob=willy[token].prob;
    i=token+1;
    while(((sum_willy_massdis+willy[i].mass_dis_from_prev) < mass_thr) && (i < willy.size())){
        temp_mass = (temp_mass*temp_prob+willy[i].mass*willy[i].prob)/(temp_prob+willy[i].prob);
        temp_prob +=willy[i].prob;
        sum_willy_massdis +=willy[i].mass_dis_from_prev;
        i++;
    };
    molly.push_back(masspeakpair());
    molly[k].prob=temp_prob;
    molly[k].mass=temp_mass;
    k++;
    token=i;
  }

  return molly;
}//end of function natural_distr::pick_n_merge()


void NID_calculator(int data[], vector<masspeakpair> & v)
{
    natural_distr natural1;
	cout<< "Start here? so weird!"<< endl;
	    natural1.set_num_c(data[0]);
	    natural1.set_num_h(data[1]);
	    natural1.set_num_o(data[2]);
	    natural1.set_num_n(data[3]);
	    natural1.set_num_s(data[4]);
	    natural1.emily = natural1.get_product();
	    cout.precision(12);
	    natural1.ashley = natural1.pick_n_merge(0.0002,0.02); //the width of the window is 20 ppm for mass=1000. compared with 30 = (-15 ppm ~15 ppm) in PPintegrator
//            cout << "What is in ashley?" <<endl;
//    	    for (i=0; i < natural1.ashley.size(); i++){
//        	cout <<i<<"   "<< natural1.ashley[i].mass <<"   "<< natural1.ashley[i].prob << endl;
//		}
	v=natural1.ashley;
}



