#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <algorithm>
#include <string.h>
#include <iomanip> //for std::setprecision

using namespace std;

//double PPintegrator(char*, int, double, int);

struct ms1key
{
	string familyseq;
	string seq;
	int charge;
	float mz_ms1;
	string rawfname;
	int scannum;
	int ms1peak_order;
	int num_of_K;
	int MS2exist_indicator;
};

struct info_MS1_of_an_MS1peak
{
	int charge;
	float mz_ms1;
	string rawfname;
	int scannum;
	int ms1peak_order;
	int MS2exist_indicator;
	std::vector<float> MS2_stoich;////size should be num of sites.
};

struct seqfamily
{
	string familyseq;
	int num_of_K;
	int execute;
	std::vector<info_MS1_of_an_MS1peak> ms1p;
	//info_MS1_of_an_MS1peak ms1p[5];
};

struct masspeakpair
{
	double prob;
	double mass;
};
void NID_calculator(int data[], vector<masspeakpair> & v);

struct MS2word
{
	string familyseq;
	int ms1peak_order;
	std::vector<float> site_stoich;
};


struct peakms2
{
	int ms1peak_order;
	std::vector<float> GreekL_frac; 
	//GreekL_frac[0] is alphaL_frac, the occupancies of light at alpha site; GreekL_frac[1] is betaL_frac,...;
};

struct ms2dictionaryword
{
	string familyseq;
	std::vector<peakms2> peak; 
};


struct shapeparameterinput
{
	float max_R_time;
	float max_s_inten;
	float starting_time;
	float end_time;
	float array_starting_time;
	float array_end_time;
};

#include "MS1.hpp"
//Usage ./a.out output_of_ms1perl ms2dictionaryfile folder_of_mzXMLfiles mz_error(_for)_calibrating_peak  mz_error(_for)_calibrated_peak output_gg output_stoich 
ms1key lala;
std::vector<ms1key> dudu;
seqfamily tempfamily;
std::vector<seqfamily> seqfamilies;
MS2word MS2word_temp;
std::vector<MS2word> array_of_single_def_word;
peakms2 peak_temp;
ms2dictionaryword dicword;
std::vector<ms2dictionaryword> dictionary;
double II[5];

int main(int argc, char *argv[]){
	string sss;
	std::string charge_temp,mz_ms1_temp,bestrawfile_temp,bestscan_temp;
	std::string kk_temp,num_of_K_temp, MS2exist_temp;
	//std::string Cnum_temp,Hnum_temp,Onum_temp,Nnum_temp,Snum_temp,Dnum_temp;
	//std::string free_nTnum_temp,AHnum_temp;
	//int Cnum,Hnum,Onum,Nnum,Snum,Dnum,free_nTnum,AHnum;
	//int charge,bestscan;
	//float mz_value;
	std::string delimiter = " ";
	ifstream infile1, infile2;
	ofstream outf01,outf02; //outfiles
	infile1.open (argv[1]);
	infile2.open (argv[2]);
	outf01.open (argv[6]); //GGGG
	outf02.open (argv[7]); //total

	info_MS1_of_an_MS1peak temp_ms1p;
	int ii, j2, same_seq;
	shapeparameterinput sh[2];
	vector<struct intern_calib> Q,Q1,Q2,Q3,Q4,Q5;
	//intern_calib temp_member_Q;
	//std::vector<intern_calib_info> Q;

	float starting_time, end_time, max_R_time;
	float max_s_inten, array_starting_time, array_end_time;
	float starting_time_i1, end_time_i1, max_R_time_i1;
	float starting_time_i2, end_time_i2, max_R_time_i2;
	float starting_time_i3, end_time_i3, max_R_time_i3;
	float starting_time_i4, end_time_i4, max_R_time_i4;
	float starting_time_i5, end_time_i5, max_R_time_i5;
	int max_scan_num_i1, max_scan_num_i2, max_scan_num_i3,  max_scan_num_i4,  max_scan_num_i5; 
	int max_scan_num, light_max_scan_num;
	string ms1peak_order_temp, size_temp, site_stoi_temp;
	int size; 
	int num_of_KK, real_maxx_scan_num;
	float site_stoi_tempp, real_maxx_inten;
	float mz_error_calibrating_peak, mz_error_calibrated_peak, mz_error;
	const float mass_dif_3DH = 5.025539917;
	bool negligible, negligibleI2, negligibleI3, negligibleI4, real_continue;
	int samems2,j;
	string family_seq_pre="whatever";
	std::string ffolder = argv[3];   //"../mzXMLfolder/";
	std::string theXMLfname;
	std::string tail = ".mzXML";
	char XMLfname[80];
	//theXMLfname += tail; strcpy(XMLfname, theXMLfname.c_str());

	mz_error_calibrating_peak=atof(argv[4]); //
	mz_error=  mz_error_calibrating_peak;
	mz_error_calibrated_peak =atof(argv[5]);

	cout << "mz_error_calibrating_peak=" << mz_error_calibrating_peak<< endl;
	//cout << "0.2+mz_error_calibrating_peak=" << (mz_error_calibrating_peak+0.2) << endl; 
	while(getline(infile1,sss))
	{    
		size_t pos = 0;
		if((pos = sss.find(delimiter)) != std::string::npos) {//12
			lala.familyseq = sss.substr(0, pos);
			sss.erase(0, pos + delimiter.length());
			if((pos = sss.find(delimiter)) != std::string::npos) {//11
				lala.seq = sss.substr(0, pos);
				sss.erase(0, pos + delimiter.length());
				if ((pos = sss.find(delimiter)) != std::string::npos){//10
					charge_temp = sss.substr(0, pos);
					const char* cucku =  charge_temp.c_str();
					lala.charge= std::atoi(cucku);
					sss.erase(0, pos + delimiter.length());
					if ((pos = sss.find(delimiter)) != std::string::npos){//9
						mz_ms1_temp = sss.substr(0, pos);
						const char* cucku =  mz_ms1_temp.c_str();
						lala.mz_ms1= std::atof(cucku);
						sss.erase(0, pos + delimiter.length());
						if ((pos = sss.find(delimiter)) != std::string::npos){//8
							lala.rawfname = sss.substr(0, pos);
							//theXMLfname=lala.rawfname;
							sss.erase(0, pos + delimiter.length());
							if ((pos = sss.find(delimiter)) != std::string::npos){//7
								bestscan_temp = sss.substr(0, pos);
								const char* cucku =  bestscan_temp.c_str();
								lala.scannum = std::atoi(cucku);
								sss.erase(0, pos + delimiter.length());

								if ((pos = sss.find(delimiter)) != std::string::npos){ //6
									num_of_K_temp = sss.substr(0, pos);
									const char* cucku = num_of_K_temp.c_str();
									lala.num_of_K = std::atoi(cucku);
									sss.erase(0, pos + delimiter.length());

									if ((pos = sss.find(delimiter)) != std::string::npos){//5
										kk_temp = sss.substr(0, pos);
										const char* cucku = kk_temp.c_str();
										lala.ms1peak_order= std::atoi(cucku);
										sss.erase(0, pos + delimiter.length());

										MS2exist_temp = sss;
										const char* cucku5 = MS2exist_temp.c_str();
										lala.MS2exist_indicator = std::atoi(cucku5);
									}//5
								}//6
							}//7
						}//8
					}//9
				}//10
			}//11
		}//12
		dudu.push_back(lala);
		cout << "seq     charge      mz       rawfile    scan"<<endl;
		cout << lala.seq <<" "<<lala.charge<<" "<<lala.mz_ms1<<" "<<lala.rawfname<<" "<<lala.scannum<<endl;
	}//while(getline(infile,sss))

	// theXMLfname += tail;
	// strcpy(XMLfname, theXMLfname.c_str());
	cout << "CHECK PT000A" << endl;
	if(dudu.size()>0){
		tempfamily.familyseq = dudu[0].familyseq;
		tempfamily.num_of_K  = dudu[0].num_of_K; 
		temp_ms1p.charge  = dudu[0].charge;
		temp_ms1p.mz_ms1  = dudu[0].mz_ms1;
		temp_ms1p.rawfname= dudu[0].rawfname;
		temp_ms1p.scannum = dudu[0].scannum;
		temp_ms1p.ms1peak_order = dudu[0].ms1peak_order;
		temp_ms1p.MS2exist_indicator = dudu[0].MS2exist_indicator;
		//index = 1 + tempfamily.num_of_K - temp_ms1p.ms1peak_order;
		//tempfamily.ms1p[index] = temp_ms1p; // array of a struct  assigning work?
		tempfamily.ms1p.push_back(temp_ms1p);
		seqfamilies.push_back(tempfamily);
	}
	cout << "CHECK PT000B" << endl;

	int i;
	for (ii=1; ii<dudu.size(); ii++){
		same_seq = 0;
		for (i=0; i<seqfamilies.size(); i++){
			if (dudu[ii].familyseq == seqfamilies[i].familyseq){
				same_seq = -1;
				temp_ms1p.charge  = dudu[ii].charge;
				temp_ms1p.mz_ms1  = dudu[ii].mz_ms1;
				temp_ms1p.rawfname= dudu[ii].rawfname;
				temp_ms1p.scannum = dudu[ii].scannum;
				temp_ms1p.ms1peak_order = dudu[ii].ms1peak_order;
				temp_ms1p.MS2exist_indicator = dudu[ii].MS2exist_indicator;

				//index = 1 + dudu[ii].num_of_K - temp_ms1p.ms1peak_order;
				//seqfamilies[i].ms1p[index] = temp_ms1p; // array of a struct  assigning work?
				seqfamilies[i].ms1p.push_back(temp_ms1p);       
				break;
			}
		}
		if (same_seq == 0){
			tempfamily.ms1p.clear();
			tempfamily.familyseq = dudu[ii].familyseq;
			tempfamily.num_of_K  = dudu[ii].num_of_K;
			temp_ms1p.charge  = dudu[ii].charge;
			temp_ms1p.mz_ms1  = dudu[ii].mz_ms1;
			temp_ms1p.rawfname= dudu[ii].rawfname;
			temp_ms1p.scannum = dudu[ii].scannum;
			temp_ms1p.ms1peak_order = dudu[ii].ms1peak_order;
			temp_ms1p.MS2exist_indicator = dudu[ii].MS2exist_indicator;
			//index = 1 + tempfamily.num_of_K - temp_ms1p.ms1peak_order;
			//tempfamily.ms1p[index] = temp_ms1p; 
			tempfamily.ms1p.push_back(temp_ms1p);
			seqfamilies.push_back(tempfamily);
		}
	}//for (ii=1; ii<dudu.size(); ii++){

	cout << "CHECK PT001" << endl;
	while(getline(infile2,sss))
	{
		size_t pos = 0;
		if((pos = sss.find(delimiter)) != std::string::npos) {//12
			MS2word_temp.familyseq = sss.substr(0, pos);
			sss.erase(0, pos + delimiter.length());
			if ((pos = sss.find(delimiter)) != std::string::npos){//11
				ms1peak_order_temp = sss.substr(0, pos);
				const char* cucku =  ms1peak_order_temp.c_str();
				MS2word_temp.ms1peak_order = std::atoi(cucku);
				// ms1peak_order_tempp= std::atoi(cucku);
				// MS2word_temp.ms1peak_order0.push_back(ms1peak_order_tempp);
				sss.erase(0, pos + delimiter.length());
				if ((pos = sss.find(delimiter)) != std::string::npos){//10
					size_temp = sss.substr(0, pos);
					const char* cucku6 =  size_temp.c_str();
					size = std::atoi(cucku6);
					MS2word_temp.site_stoich.clear();

					for (i=0; i< (size-1); i++){
						sss.erase(0, pos + delimiter.length());
						pos = sss.find(delimiter);
						site_stoi_temp = sss.substr(0, pos);
						const char* cucku =  site_stoi_temp.c_str();
						site_stoi_tempp = std::atof(cucku);
						MS2word_temp.site_stoich.push_back(site_stoi_tempp);
					}
					sss.erase(0, pos + delimiter.length());
					const char* cucku7 = sss.c_str();
					site_stoi_tempp = std::atof(cucku7);
					MS2word_temp.site_stoich.push_back(site_stoi_tempp);
				}//10
			}//11
		}//12
		array_of_single_def_word.push_back(MS2word_temp);
	}

	if (array_of_single_def_word.size()!=0){ 
		peak_temp.ms1peak_order = array_of_single_def_word[0].ms1peak_order;
		//peak_temp.GreekL_frac = array_of_single_def_word[0].site_stoich;
		peak_temp.GreekL_frac.clear(); 
		for (j=0; j<array_of_single_def_word[0].site_stoich.size(); j++) {
			peak_temp.GreekL_frac.push_back(array_of_single_def_word[0].site_stoich[j]);
		}

		dicword.peak.clear();
		dicword.peak.push_back(peak_temp);
		dicword.familyseq = array_of_single_def_word[0].familyseq;
		dictionary.push_back(dicword);
		for (i=1; i<array_of_single_def_word.size(); i++) {
			samems2 = 0;
			for (j=0; j < dictionary.size(); j++) {
				if (array_of_single_def_word[i].familyseq.compare(dictionary[j].familyseq)==0) { 
					peak_temp.ms1peak_order = array_of_single_def_word[i].ms1peak_order;
					//peak_temp.GreekL_frac = array_of_single_def_word[i].site_stoich;
					peak_temp.GreekL_frac.clear();
					for (j2=0; j2<array_of_single_def_word[i].site_stoich.size(); j2++) {
						peak_temp.GreekL_frac.push_back(array_of_single_def_word[i].site_stoich[j2]);
					}
					dictionary[j].peak.push_back(peak_temp);
					samems2 = 1; 
					break;
				}
			}
			if (samems2 == 0) {
				peak_temp.ms1peak_order = array_of_single_def_word[i].ms1peak_order;
				//peak_temp.GreekL_frac = array_of_single_def_word[i].site_stoich;
				peak_temp.GreekL_frac.clear();
				for (j=0; j<array_of_single_def_word[i].site_stoich.size(); j++) {
					peak_temp.GreekL_frac.push_back(array_of_single_def_word[i].site_stoich[j]);
				}
				dicword.peak.clear();
				dicword.peak.push_back(peak_temp);
				dicword.familyseq = array_of_single_def_word[i].familyseq;
				dictionary.push_back(dicword);
			}
		}
	}//end of if (array_of_single_def_word.size()!=0)

	double I2;
	//std::vector<double> mz; 
	double M1, I1, I3, I4, I5,total_alphaL,total_betaL,total_gammaL,total_deltaL,threshold;
	int jj;
	//std::vector<float>  alphaL_frac, betaL_frac, gammaL_frac, deltaL_frac;
	float alphaL_frac[3], betaL_frac[3], gammaL_frac[3], deltaL_frac[3]; //3 middle peaks for 4-Lysine-case
	// std::vector<int> if_sured_mz; 
	//std::vector<int> charge, scannum;

	cout <<"seqfamilies.size()=" << seqfamilies.size() << endl;
	for (i=0; i < seqfamilies.size(); i++){
		cout <<endl<<"ii="<<i<<"      seqfamilies[ii].familyseq=" <<seqfamilies[i].familyseq<<endl;

		if (seqfamilies[i].num_of_K == 1){ 
			cout <<"1Kcase   ms1psize" <<  seqfamilies[i].ms1p.size() << endl;
			num_of_KK =1;
			if ( seqfamilies[i].ms1p[0].scannum != -1 ) {
				cout << "B4 calling PPinte for I2 scannum="<<seqfamilies[i].ms1p[0].scannum << "   seqfamilies[i].ms1p[0].mz_ms1=" << seqfamilies[i].ms1p[0].mz_ms1;
				cout << "    fname="<<seqfamilies[i].ms1p[0].rawfname <<endl;
				theXMLfname = ffolder; theXMLfname += seqfamilies[i].ms1p[0].rawfname;	
				theXMLfname += tail;
				strcpy(XMLfname, theXMLfname.c_str());
				I2 = PPintegratorA(XMLfname, seqfamilies[i].ms1p[0].scannum, seqfamilies[i].ms1p[0].mz_ms1, 1,1, &starting_time, &end_time, &max_R_time, &max_scan_num,mz_error_calibrating_peak,num_of_KK,&real_maxx_scan_num,&real_maxx_inten, &max_s_inten, Q);
				if ( I2 > 0) {
					cout << endl<<"Hooray!,";
					cout << "size_of_Q=, " << Q.size() << endl;
				}
				if (I2 < 0.0001) {
					if ((I2 < -0.999) && (I2 > -1.001)){
						cout << "The peak I2 (with given scannum) was not found. LN 360" <<endl ;
						I2 = 0.0000; 
						continue;
						//? or use "continue;" to jump to the next seq.
					} else if ((I2 < -1.999) && (I2 > -8.001)) {
						continue; // peak is there but cannot get exact value! dump!
					} else if ((I2 < -19.999)&&(I2 > -20.001)) {
						return 0; //cannot open the file. stop the program. exit!
					}
				}

				sh[1].max_R_time = max_R_time;
				sh[1].max_s_inten= max_s_inten;
				sh[1].starting_time = starting_time;
				sh[1].end_time= end_time;
				//sh[1].array_starting_time=array_starting_time;
				//sh[1].array_end_time=array_end_time;
				
				cout << "Time of I2 " << starting_time <<" "<< max_R_time <<"  "<< end_time << endl;
				cout << "afterI2, max_scan_num= " << max_scan_num<<endl;
				//cout << "GGGG,I2,"<<seqfamilies[i].familyseq<<"%"<<seqfamilies[i].ms1p[0].rawfname<<"%"<<seqfamilies[i].ms1p[0].charge<<","<<real_maxx_scan_num<<","<<I2<<endl;
				cout << "GGGG,I2,"<<seqfamilies[i].familyseq<<"%"<<seqfamilies[i].ms1p[0].rawfname<<"%"<<seqfamilies[i].ms1p[0].charge<<","<<max_scan_num<<","<<I2<<",";
				printf("%10.5f\n", seqfamilies[i].ms1p[0].mz_ms1);

				outf01 << "I2,"<<seqfamilies[i].familyseq<<"%"<<seqfamilies[i].ms1p[0].rawfname<<"%"<<seqfamilies[i].ms1p[0].charge<<","<<max_scan_num<<","<<I2<<",";
				outf01 << std::fixed << std::setprecision(5) << seqfamilies[i].ms1p[0].mz_ms1 <<endl;

				//cout << "real_maxx_scan_num for background test is "<< real_maxx_scan_num << endl;//OK stop! in 1Kcase, we never use it. this is just a test.
				if  ( seqfamilies[i].ms1p[1].scannum != -1 ) {
					max_R_time_i2 = max_R_time;
					max_scan_num_i2= max_scan_num;
					starting_time_i2 = starting_time;
					end_time_i2= end_time;           //These temperary memnory is used because of 
					cout << "I1 active" << endl;
					cout << "B4 calling PPinte for I1 scannum="<<seqfamilies[i].ms1p[1].scannum << " seqfamilies[i].ms1p[1].mz_ms1=" << seqfamilies[i].ms1p[1].mz_ms1;
					cout << "    fname="<<seqfamilies[i].ms1p[1].rawfname <<endl;
					theXMLfname = ffolder; theXMLfname += seqfamilies[i].ms1p[1].rawfname;
					theXMLfname += tail;
					strcpy(XMLfname, theXMLfname.c_str());
					I1 = PPintegratorA(XMLfname, seqfamilies[i].ms1p[1].scannum, seqfamilies[i].ms1p[1].mz_ms1, 1,1, &starting_time, &end_time, &max_R_time, &max_scan_num,mz_error_calibrating_peak,num_of_KK,&real_maxx_scan_num,&real_maxx_inten, &max_s_inten, Q);
				} else {
					cout << "size of Q2   = " << Q.size() << endl;
					cout << "I1 pasive" << endl;
					cout << "B4 calling PPinte for I1 scannum="<<seqfamilies[i].ms1p[1].scannum << " seqfamilies[i].ms1p[1].mz_ms1=" << seqfamilies[i].ms1p[1].mz_ms1;
					cout << "    fname="<<seqfamilies[i].ms1p[1].rawfname <<endl;
					theXMLfname = ffolder; theXMLfname += seqfamilies[i].ms1p[1].rawfname;
					theXMLfname += tail;
					strcpy(XMLfname, theXMLfname.c_str());

					//int rr=  Q.size();
					I1 = PPintegratorB(XMLfname, max_scan_num,seqfamilies[i].ms1p[1].mz_ms1, 0,1, &starting_time, &end_time, &max_R_time, &light_max_scan_num,mz_error_calibrated_peak, num_of_KK,&real_maxx_scan_num,&real_maxx_inten, &max_s_inten, mass_dif_3DH, seqfamilies[i].ms1p[1].charge, Q);
				}
				if (I1 < 0.0001) {
					if ((I1 < -0.999) && (I1 > -1.001)){
						cout << "The peak I1 (with given scannum) was not found. LN 395" <<endl ;
						I1 = 0.0000; 
					} else if ((I1 < -1.999) && (I1 > -8.001)) {
						continue; // peak is there but cannot get the value! dump!
					} else if ((I1 <-19.999) && (I1 > -20.001)) {
						return 0; //cannot open the file. exit
					}
				}
				if (I1 > 100) {
					cout << "Time of I1 " << starting_time <<" "<< max_R_time <<"  "<< end_time << endl;
					cout << "afterI1, max_scan_num= " << max_scan_num<< "   light_max_scan_num= " << light_max_scan_num <<endl;
					//cout << "GGGG,I1,"<<seqfamilies[i].familyseq<<"%"<<seqfamilies[i].ms1p[0].rawfname<<"%"<<seqfamilies[i].ms1p[0].charge<<","<<real_maxx_scan_num<<","<<I1<<endl;
					if  ( seqfamilies[i].ms1p[1].scannum != -1 ) {
						cout << "GGGG,I1,"<<seqfamilies[i].familyseq<<"%"<<seqfamilies[i].ms1p[0].rawfname<<"%"<<seqfamilies[i].ms1p[0].charge<<","<<max_scan_num<<","<<I1<<",";
						outf01 <<    "I1,"<<seqfamilies[i].familyseq<<"%"<<seqfamilies[i].ms1p[0].rawfname<<"%"<<seqfamilies[i].ms1p[0].charge<<","<<max_scan_num<<","<<I1<<",";
					} else {
						cout << "GGGG,I1,"<<seqfamilies[i].familyseq<<"%"<<seqfamilies[i].ms1p[0].rawfname<<"%"<<seqfamilies[i].ms1p[0].charge<<","<<light_max_scan_num<<","<<I1<<",";
						outf01 <<    "I1,"<<seqfamilies[i].familyseq<<"%"<<seqfamilies[i].ms1p[0].rawfname<<"%"<<seqfamilies[i].ms1p[0].charge<<","<<light_max_scan_num<<","<<I1<<",";
					}
					printf("%10.5f\n", seqfamilies[i].ms1p[1].mz_ms1);
					outf01 << std::fixed << std::setprecision(5) << seqfamilies[i].ms1p[1].mz_ms1 <<endl;
					sh[0].max_R_time = max_R_time;
					sh[0].max_s_inten= max_s_inten;
					sh[0].starting_time = starting_time;
					sh[0].end_time= end_time;
					//sh[0].array_starting_time=array_starting_time;
					//sh[0].array_end_time=array_end_time;
				} else {
					cout << "I1 not found. I1=0. stoich =0." << endl;
					// do we need to have  sh[0].max_R_time = sh[1].max_R_time here for "multiple K" case?
				}

			} else {
				cout << "scannum of I2 is not given." << endl;
				cout << "B4 calling PPinte for I1 scannum="<<seqfamilies[i].ms1p[1].scannum << " seqfamilies[i].ms1p[1].mz_ms1=" << seqfamilies[i].ms1p[1].mz_ms1;
				cout << "    fname="<<seqfamilies[i].ms1p[1].rawfname <<endl;
				theXMLfname = ffolder; theXMLfname += seqfamilies[i].ms1p[1].rawfname;
				theXMLfname += tail;
				strcpy(XMLfname, theXMLfname.c_str());
				I1 = PPintegratorA(XMLfname, seqfamilies[i].ms1p[1].scannum, seqfamilies[i].ms1p[1].mz_ms1, 1,1, &starting_time, &end_time, &max_R_time, &max_scan_num,mz_error_calibrating_peak,num_of_KK,&real_maxx_scan_num,&real_maxx_inten, &max_s_inten, Q);
				if (I1 < 0.0001) {
					if ((I1 < -0.999) && (I1 > -1.001)){
						cout << "The peak I1 (with given scannum) was not found. LN 417" <<endl ;
						I1 = 0.0000;
						continue;
					} else if ((I1 < -1.999) && (I1 > -8.001)) {
						continue; 
					} else if ((I1 <-19.999) && (I1 > -20.001)) {
						return 0; 
					}
				}
				cout << "Time of I1 " << starting_time <<" "<< max_R_time <<"  "<< end_time << endl;
				cout << "afterI1, max_scan_num= " << max_scan_num << endl;
				cout << "GGGG,I1,"<<seqfamilies[i].familyseq<<"%"<<seqfamilies[i].ms1p[0].rawfname<<"%"<<seqfamilies[i].ms1p[0].charge<<","<<max_scan_num<<","<<I1<<",";
				printf("%10.5f\n", seqfamilies[i].ms1p[1].mz_ms1);
				outf01 <<    "I1,"<<seqfamilies[i].familyseq<<"%"<<seqfamilies[i].ms1p[0].rawfname<<"%"<<seqfamilies[i].ms1p[0].charge<<","<<max_scan_num<<","<<I1<<",";
				outf01 << std::fixed << std::setprecision(5) << seqfamilies[i].ms1p[1].mz_ms1 <<endl;

				sh[0].max_R_time = max_R_time;
				sh[0].max_s_inten= max_s_inten;
				sh[0].starting_time = starting_time;
				sh[0].end_time= end_time;
				//sh[0].array_starting_time=array_starting_time;
				//sh[0].array_end_time=array_end_time;

				cout << "B4 calling PPinte for I2 scannum="<<seqfamilies[i].ms1p[0].scannum << " seqfamilies[i].ms1p[0].mz_ms1=" << seqfamilies[i].ms1p[0].mz_ms1;
				cout << "    fname="<<seqfamilies[i].ms1p[0].rawfname <<endl;
				theXMLfname = ffolder; theXMLfname += seqfamilies[i].ms1p[0].rawfname;
				theXMLfname += tail;
				strcpy(XMLfname, theXMLfname.c_str());
				I2 = PPintegratorB(XMLfname, max_scan_num,      seqfamilies[i].ms1p[0].mz_ms1, 0,0, &starting_time, &end_time, &max_R_time, &light_max_scan_num,mz_error_calibrated_peak,num_of_KK,&real_maxx_scan_num,&real_maxx_inten, &max_s_inten, mass_dif_3DH, seqfamilies[i].ms1p[0].charge, Q);
				
				if (I2 < 0.0001) {
					if ((I2 < -0.999) && (I2 > -1.001)){
						cout << "The peak I2 (with given scannum) was not found. LN 436" <<endl ;
						I2 = 0.0000;
					} else if ((I2 < -1.999) && (I2 > -8.001)) {
						continue; // peak is there but cannot get the value! dump!
					} else if ((I2 < -19.999)&&(I2 > -20.001)) {
						return 0; //cannot open the file. exit
					}
				}
				if (I2 > 100) { 
					cout << "Time of I2 " << starting_time <<" "<< max_R_time <<"  "<< end_time << endl;
					cout << "afterI2, max_scan_num= " << max_scan_num<< "   light_max_scan_num= " << light_max_scan_num <<endl;
					cout << "GGGG,I2,"<<seqfamilies[i].familyseq<<"%"<<seqfamilies[i].ms1p[0].rawfname<<"%"<<seqfamilies[i].ms1p[0].charge<<","<<light_max_scan_num<<","<<I2<<",";
					printf("%10.5f\n", seqfamilies[i].ms1p[0].mz_ms1);
					outf01 <<    "I2,"<<seqfamilies[i].familyseq<<"%"<<seqfamilies[i].ms1p[0].rawfname<<"%"<<seqfamilies[i].ms1p[0].charge<<","<<light_max_scan_num<<","<<I2<<",";
					outf01 << std::fixed << std::setprecision(5) << seqfamilies[i].ms1p[0].mz_ms1 <<endl;
					sh[1].max_R_time = max_R_time;
					sh[1].max_s_inten= max_s_inten;
					sh[1].starting_time = starting_time;
					sh[1].end_time= end_time;
					//sh[1].array_starting_time=array_starting_time;
					//sh[1].array_end_time=array_end_time;
				} else {
					cout<<"I2 not found. I2=0. stoich =1." << endl;
					// do we need to have  sh[1].max_R_time = sh[0].max_R_time here for "multiple K" case?
				}
			}
			total_alphaL = I1/(I1+I2);
			cout << "total_alphaL= "<<total_alphaL<<"   seqfamilies[i].familyseq="<<seqfamilies[i].familyseq<<"   fname="<<seqfamilies[i].ms1p[0].rawfname <<" I2="<<I2<<endl << endl;
			outf02<<"total_alphaL= "<<total_alphaL<<"   seqfamilies[i].familyseq="<<seqfamilies[i].familyseq<<"   fname="<<seqfamilies[i].ms1p[0].rawfname <<" I2="<<I2<<endl;
			//cout << "utal_alpha,"<<total_alphaL<<","<<seqfamilies[i].familyseq<<","<<seqfamilies[i].ms1p[0].rawfname;
			//cout << ",heavy,"<< sh[1].max_R_time << "," << sh[1].max_s_inten << "," << sh[1].starting_time << "," << sh[1].end_time << "," << sh[1].array_starting_time << "," << sh[1].array_end_time;
			//cout << ",light,"<< sh[0].max_R_time << "," << sh[0].max_s_inten << "," << sh[0].starting_time << "," << sh[0].end_time << "," << sh[0].array_starting_time << "," << sh[0].array_end_time<<endl<<endl;

			cout << "utal_alpha,"<<total_alphaL<<","<<seqfamilies[i].familyseq<<","<<seqfamilies[i].ms1p[0].rawfname;
			cout << ",heavy,"<< sh[1].max_R_time << "," << sh[1].max_s_inten << "," << sh[1].starting_time << "," << sh[1].end_time ;
			cout << ",light,"<< sh[0].max_R_time << "," << sh[0].max_s_inten << "," << sh[0].starting_time << "," << sh[0].end_time <<endl<<endl;
		}// end of if (seqfamilies[i].num_of_K == 1) 

		if (seqfamilies[i].num_of_K == 2) {
			cout <<"2Kcase   ms1psize=" <<  seqfamilies[i].ms1p.size() << endl;
			num_of_KK = 2;
			if (seqfamilies[i].ms1p[1].MS2exist_indicator== 0) {
				if (seqfamilies[i].ms1p[1].scannum !=-1 ) { //scannum of middle peak is given but not an entry in MS2 dictionary
					cout << "middle peak I2 larger than background noise; supposed, because scannum of middle peak is given. dump." <<endl;
					continue;
				} else { // (That means if (seqfamilies[i].ms1p[1].scannum ==-1 )
					if (seqfamilies[i].ms1p[0].scannum !=-1){ //LN 559
						cout << "B4 calling PPinte for I3 scannum="<<seqfamilies[i].ms1p[0].scannum << " seqfamilies[i].ms1p[0].mz_ms1=" << seqfamilies[i].ms1p[0].mz_ms1;
						cout << "    fname="<<seqfamilies[i].ms1p[0].rawfname <<endl;
						theXMLfname = ffolder; theXMLfname += seqfamilies[i].ms1p[0].rawfname;
						theXMLfname += tail;
						strcpy(XMLfname, theXMLfname.c_str());

						//I3 = PPintegrator(XMLfname, seqfamilies[i].ms1p[0].scannum, seqfamilies[i].ms1p[0].mz_ms1, 1,1, &starting_time, &end_time, &max_R_time, &max_scan_num,mz_error,num_of_KK,&real_maxx_scan_num,&real_maxx_inten, &max_s_inten, &array_starting_time, &array_end_time);//heavy
						I3 = PPintegratorA(XMLfname, seqfamilies[i].ms1p[0].scannum, seqfamilies[i].ms1p[0].mz_ms1, 1,1, &starting_time, &end_time, &max_R_time, &max_scan_num,mz_error_calibrating_peak,num_of_KK,&real_maxx_scan_num,&real_maxx_inten, &max_s_inten, Q); //heavy
						if ( I3 > 0) {
							cout << "size_of_Q=, " << Q.size() << endl;
						}

						if (I3 < 0.0001) {
							if ((I3 < -0.999) && (I3 > -1.001)){
								cout << "The peak I3 (with given scannum) was not found. LN 466" <<endl ;
								I3 = 0.0000;
								continue;
							} else if ((I3 < -1.999) && (I3 > -8.001)) {
								continue; // peak is there but cannot get the value! dump!
							} else if ((I3 < -19.999)&&(I3 > -20.001)) {
								return 0; //cannot open the file. exit
							}
						}
						starting_time_i3 = starting_time;
						end_time_i3 = end_time;
						max_R_time_i3= max_R_time;
						max_scan_num_i3= max_scan_num;
						sh[0].max_R_time = max_R_time;
						sh[0].max_s_inten= max_s_inten;
						sh[0].starting_time = starting_time;
						sh[0].end_time= end_time;

						//Because a vector of struct intern_calibra qq was not change in PPintegratorB() We don't need to copy Q here for later calibrating I1.
						cout << "Time of I3 " << starting_time <<" "<< max_R_time <<"  "<< end_time << endl;
						cout << "afterI3,  max_scan_num= " << max_scan_num << endl;
						cout << "GGGG,I3,"<<seqfamilies[i].familyseq<<"%"<<seqfamilies[i].ms1p[0].rawfname<<"%"<<seqfamilies[i].ms1p[0].charge<<","<<max_scan_num<<","<<I3<<",";
						printf("%10.5f\n", seqfamilies[i].ms1p[0].mz_ms1);
						outf01 <<    "I3,"<<seqfamilies[i].familyseq<<"%"<<seqfamilies[i].ms1p[0].rawfname<<"%"<<seqfamilies[i].ms1p[0].charge<<","<<max_scan_num<<","<<I3<<",";
						outf01 << std::fixed << std::setprecision(5) << seqfamilies[i].ms1p[0].mz_ms1 <<endl;

						cout << "B4 calling PPinte for M1 scannum="<<seqfamilies[i].ms1p[1].scannum << " seqfamilies[i].ms1p[1].mz_ms1=" << seqfamilies[i].ms1p[1].mz_ms1;
						cout << "   fname="<<seqfamilies[i].ms1p[1].rawfname <<endl;
						theXMLfname = ffolder; theXMLfname += seqfamilies[i].ms1p[1].rawfname;
						theXMLfname += tail;
						strcpy(XMLfname, theXMLfname.c_str());
						//light_max_scan_num is one of the output of M1 = PPintegrator() this is just for reference, still better to use Time of I3 in setting time limits for I1; 
						M1 = PPintegratorB(XMLfname, max_scan_num, seqfamilies[i].ms1p[1].mz_ms1, 0,1, &starting_time, &end_time, &max_R_time, &light_max_scan_num,mz_error_calibrated_peak,num_of_KK,&real_maxx_scan_num,&real_maxx_inten, &max_s_inten, mass_dif_3DH, seqfamilies[i].ms1p[0].charge, Q);

						negligible = false;
						if (M1 < 0.0001) {
							if ((M1 < -0.999) && (M1 > -1.001)){
								cout << "The peak M1 (with given scannum) was not found. LN 578" <<endl;
								//negligible = true;
							} else if ((M1 < -1.999) && (M1 > -8.001)) {
								cout<< "M1 is mixed with other peptide."<< endl;
								continue; // peak is there but cannot get the value! dump!
								// what fall here is there is 1. (-6) no peak found after deconvol in overlapping zone
								//                            2. (-6) "TWO ARRAYS DO NOT MATCH." 
								// now another thought is: since it is a middle peak, 
								//            even (B) no aft-dev peak found but 1-3 b4-dev columns found in overalpping zone 
								//               it is still possible that condition (real_maxx_inten < threshold) holds
								//            So in such a case, we may just need to find out  *real_max_scan_num, float* real_max_inten
								//            in PPintegrator"C", 
								//            and then in main(), check if the condition (real_maxx_inten < 3* background noise ) holds.
								//            if yes, negligible; if not, dump.
								// OK, NOW in implementation: in PPintegratorC, 
								// in case (B), if no aft-dev peak found and only 1-2 b4-dev peak found
								// we pass these 1-2 scanumm return -3, -4 to main(). Then main check if the only one or the only both satisfy
								// condition (real_maxx_inten < threshold). Then we can set the peak M1 to zero.
								// OK we don't do the following
								// in case (A), we limit ourself only considering b4-array of fewer than 3, if all 3 scanumm all satisfy
								// (real_maxx_inten < threshold). Then we set it to zero.
							} 
							negligible = true;
						}
						if (negligible == false) {
							cout << "Time of M1 " << starting_time <<" "<< max_R_time <<"  "<< end_time << endl;
							cout << "afterM1 before thres, max_scan_num= " << max_scan_num<<"   light_max_scan_num= " << light_max_scan_num <<endl;
							cout << "real_maxx_scan_num for background test is "<< real_maxx_scan_num << endl;
							threshold= 3 * noise_level(XMLfname, real_maxx_scan_num);
							cout << "threshold=" <<threshold<<"  real_maxx_inten=" << real_maxx_inten <<endl;
							if ( real_maxx_inten > threshold) {
								cout << "M1 apex larger than background noise but sequence is not in MS2 dictionary. dump." << endl;
								continue;
							} else {
								negligible = true;
							}
						}	      
						if (negligible == true) {
							M1=0.000000; alphaL_frac[0]=0.000; betaL_frac[0] =0.000;
							cout << "GGGG,M1pass,"<<seqfamilies[i].familyseq<<"%"<<seqfamilies[i].ms1p[0].rawfname<<"%"<<seqfamilies[i].ms1p[0].charge<<","<<light_max_scan_num<<","<<0<<",";
							printf("%10.5f\n", seqfamilies[i].ms1p[1].mz_ms1);
							outf01 <<    "M1pass,"<<seqfamilies[i].familyseq<<"%"<<seqfamilies[i].ms1p[0].rawfname<<"%"<<seqfamilies[i].ms1p[0].charge<<","<<light_max_scan_num<<","<<0<<",";
							outf01 << std::fixed << std::setprecision(5) << seqfamilies[i].ms1p[1].mz_ms1 <<endl;

							//active/passive mod
							//if ( light_max_scan_num !=0 ) {
							//  max_scan_num = light_max_scan_num;
							//} //we still use I3's time instead of M1's time
							if (seqfamilies[i].ms1p[2].scannum !=-1) {
								cout << "I1 active" << endl;
								cout << "B4 calling PPinte for I1 scannum="<<seqfamilies[i].ms1p[2].scannum << " seqfamilies[i].ms1p[2].mz_ms1=" << seqfamilies[i].ms1p[2].mz_ms1;
								cout << "    fname="<<seqfamilies[i].ms1p[2].rawfname <<endl;
								theXMLfname = ffolder; theXMLfname += seqfamilies[i].ms1p[2].rawfname;
								theXMLfname += tail;
								strcpy(XMLfname, theXMLfname.c_str());
								//once addinfo ==1; *starting_time, *end_time, *max_R_time, *max_scan_num does not matter.
								I1 = PPintegratorA(XMLfname, seqfamilies[i].ms1p[2].scannum, seqfamilies[i].ms1p[2].mz_ms1, 1,1, &starting_time, &end_time, &max_R_time, &max_scan_num,mz_error_calibrating_peak,num_of_KK,&real_maxx_scan_num,&real_maxx_inten, &max_s_inten, Q);
							} else{
								cout << "I1 passive" << endl; //I2 is negligible; use I3; these values were really reset in M1 calculation because return value of M1 was positive values.
								starting_time = starting_time_i3;
								end_time = end_time_i3;
								max_R_time= max_R_time_i3;
								max_scan_num= max_scan_num_i3;
								cout << "B4 calling PPinte for I1 scannum="<<seqfamilies[i].ms1p[2].scannum << " seqfamilies[i].ms1p[2].mz_ms1=" << seqfamilies[i].ms1p[2].mz_ms1;
								cout << "    fname="<<seqfamilies[i].ms1p[2].rawfname <<endl;
								theXMLfname = ffolder; theXMLfname += seqfamilies[i].ms1p[2].rawfname;
								theXMLfname += tail;
								strcpy(XMLfname, theXMLfname.c_str());
								I1 = PPintegratorB(XMLfname, max_scan_num, seqfamilies[i].ms1p[2].mz_ms1, 0,1, &starting_time, &end_time, &max_R_time, &light_max_scan_num,mz_error_calibrated_peak,num_of_KK,&real_maxx_scan_num,&real_maxx_inten, &max_s_inten, 2*mass_dif_3DH, seqfamilies[i].ms1p[0].charge, Q);
							}
							if (I1 < 0.0001) {
								if ((I1 < -0.999) && (I1 > -1.001)){
									cout << "The peak I1 (with given scannum) was not found. LN 630" <<endl ;
									I1 = 0.0000;
								} else if ((I1 < -1.999) && (I1 > -8.001)) {
									continue;
								}
							}

							sh[2].max_R_time = max_R_time;
							sh[2].max_s_inten= max_s_inten;
							sh[2].starting_time = starting_time;
							sh[2].end_time= end_time;
							cout << "GGGG,I1,"<<seqfamilies[i].familyseq<<"%"<<seqfamilies[i].ms1p[0].rawfname<<"%"<<seqfamilies[i].ms1p[0].charge<<","<<light_max_scan_num<<","<<I1<<",";
							printf("%10.5f\n", seqfamilies[i].ms1p[2].mz_ms1);
							outf01 <<    "I1,"<<seqfamilies[i].familyseq<<"%"<<seqfamilies[i].ms1p[0].rawfname<<"%"<<seqfamilies[i].ms1p[0].charge<<","<<light_max_scan_num<<","<<I1<<",";
							outf01 << std::fixed << std::setprecision(5) << seqfamilies[i].ms1p[2].mz_ms1 <<endl;

							cout << "Time of I1 " << starting_time <<" "<< max_R_time <<"  "<< end_time << endl;
							if (seqfamilies[i].ms1p[2].scannum !=-1) {
								cout << "afterI1, max_scan_num= " << max_scan_num << endl;
							} else {
								cout << "afterI1, max_scan_num= " << max_scan_num <<"   light_max_scan_num= " << light_max_scan_num <<endl;
							}
						} else { //if (negligible == true) {
							//cout << "GGGG,M1,"<<seqfamilies[i].familyseq<<"%"<<seqfamilies[i].ms1p[0].rawfname<<"%"<<seqfamilies[i].ms1p[0].charge<<","<<max_scan_num<<","<<0<<","<<seqfamilies[i].ms1p[2].mz_ms1<<endl;
						}
					} else if (seqfamilies[i].ms1p[2].scannum !=-1) { //LN 651
						cout << "B4 calling PPinte for I1 scannum="<<seqfamilies[i].ms1p[2].scannum << " seqfamilies[i].ms1p[2].mz_ms1=" << seqfamilies[i].ms1p[2].mz_ms1;
						cout << "    fname="<<seqfamilies[i].ms1p[2].rawfname <<endl;
						theXMLfname = ffolder; theXMLfname += seqfamilies[i].ms1p[2].rawfname;
						theXMLfname += tail;
						strcpy(XMLfname, theXMLfname.c_str());
						
						I1 =PPintegratorA(XMLfname, seqfamilies[i].ms1p[2].scannum, seqfamilies[i].ms1p[2].mz_ms1, 1,1, &starting_time, &end_time, &max_R_time, &max_scan_num,mz_error_calibrating_peak,num_of_KK,&real_maxx_scan_num,&real_maxx_inten, &max_s_inten, Q);
						cout << "Time of I1 " << starting_time <<" "<< max_R_time <<"  "<< end_time << endl;
						cout << "afterI1, max_scan_num= " << max_scan_num<<endl;
						if (I1 < 0.0001) {
							if ((I1 < -0.999) && (I1 > -1.001)){
								cout << "The peak I1 (with given scannum) was not found. LN 657" <<endl ;
								I1 = 0.0000;
							} else if ((I1 < -1.999) && (I1 > -8.001)) {
								continue;
							}
						}
						cout << "Time of I1 " << starting_time <<" "<< max_R_time <<"  "<< end_time << endl;
						cout << "afterI1,  max_scan_num= " << max_scan_num <<endl;
						cout << "GGGG,I1,"<<seqfamilies[i].familyseq<<"%"<<seqfamilies[i].ms1p[0].rawfname<<"%"<<seqfamilies[i].ms1p[0].charge<<","<<max_scan_num<<","<<I1<<",";
						printf("%10.5f\n", seqfamilies[i].ms1p[2].mz_ms1);
						outf01 <<    "I1,"<<seqfamilies[i].familyseq<<"%"<<seqfamilies[i].ms1p[0].rawfname<<"%"<<seqfamilies[i].ms1p[0].charge<<","<<max_scan_num<<","<<I1<<",";
						outf01 << std::fixed << std::setprecision(5) << seqfamilies[i].ms1p[2].mz_ms1 <<endl;

						starting_time_i1 = starting_time;
						end_time_i1 = end_time;
						max_R_time_i1= max_R_time;
						max_scan_num_i1= max_scan_num;

						sh[2].max_R_time = max_R_time;
						sh[2].max_s_inten= max_s_inten;
						sh[2].starting_time = starting_time;
						sh[2].end_time= end_time;

						cout << "B4 calling PPinte for M1 scannum="<<seqfamilies[i].ms1p[1].scannum << " seqfamilies[i].ms1p[1].mz_ms1=" << seqfamilies[i].ms1p[1].mz_ms1;
						cout << "   fname="<<seqfamilies[i].ms1p[1].rawfname <<endl;
						theXMLfname = ffolder; theXMLfname += seqfamilies[i].ms1p[1].rawfname;
						theXMLfname += tail;
						strcpy(XMLfname, theXMLfname.c_str());
						M1 = PPintegratorB(XMLfname, max_scan_num, seqfamilies[i].ms1p[1].mz_ms1, 0,0, &starting_time, &end_time, &max_R_time, &light_max_scan_num,mz_error_calibrated_peak,num_of_KK,&real_maxx_scan_num,&real_maxx_inten, &max_s_inten, mass_dif_3DH, seqfamilies[i].ms1p[2].charge, Q);
						
						negligible = false;
						if (M1 < 0.0001) {
							if ((M1 < -0.999) && (M1 > -1.001)){
								cout << "The peak M1 (with given scannum) was not found. LN 680" <<endl ;
								//negligible = true;
							} else if ((M1 < -1.999) && (M1 > -8.001)) {
								cout<< "M1 is mixed with other peptide."<< endl;
								continue; // peak is there but cannot get the value! dump!
							}
							negligible = true;
						}
						if (negligible == false) {
							cout << "Time of M1 " << starting_time <<" "<< max_R_time <<"  "<< end_time << endl;
							cout << "afterM1 beforethres, max_scan_num= " << max_scan_num<<"   light_max_scan_num= " << light_max_scan_num <<endl;
							cout << "real_maxx_scan_num for background test is "<< real_maxx_scan_num << endl;
							threshold= 3 * noise_level(XMLfname, real_maxx_scan_num);
							cout << "threshold=" <<threshold<<"  real_maxx_inten=" << real_maxx_inten <<endl;
							if (real_maxx_inten > threshold) {
								cout << "M1 apex larger than background noise but sequence is not in MS2 dictionary. dump." << endl;
								continue;
							} else {
								negligible = true;
							}
						}
						if (negligible == true) {
							M1=0.00000; alphaL_frac[0]=0.000; betaL_frac[0] =0.000;
							cout << "GGGG,M1pass,"<<seqfamilies[i].familyseq<<"%"<<seqfamilies[i].ms1p[0].rawfname<<"%"<<seqfamilies[i].ms1p[0].charge<<","<<light_max_scan_num<<","<<M1<< ",";
							printf("%10.5f\n", seqfamilies[i].ms1p[1].mz_ms1);
							outf01 <<    "M1pass,"<<seqfamilies[i].familyseq<<"%"<<seqfamilies[i].ms1p[0].rawfname<<"%"<<seqfamilies[i].ms1p[0].charge<<","<<light_max_scan_num<<","<<M1<< ",";
							outf01 << std::fixed << std::setprecision(5) << seqfamilies[i].ms1p[1].mz_ms1 <<endl;

							//no active, only passive mod
							cout << "I3 passive" << endl;
							starting_time = starting_time_i1;
							end_time = end_time_i1;
							max_R_time= max_R_time_i1;
							max_scan_num= max_scan_num_i1;
							cout << "B4 calling PPinte for I3 scannum="<<seqfamilies[i].ms1p[0].scannum << " seqfamilies[i].ms1p[0].mz_ms1=" << seqfamilies[i].ms1p[0].mz_ms1; 
							cout << "    fname="<<seqfamilies[i].ms1p[0].rawfname << endl;
							theXMLfname = ffolder; theXMLfname += seqfamilies[i].ms1p[2].rawfname;
							theXMLfname += tail;
							strcpy(XMLfname, theXMLfname.c_str());
							I3 =PPintegratorB(XMLfname, max_scan_num, seqfamilies[i].ms1p[0].mz_ms1, 0,0, &starting_time, &end_time, &max_R_time, &light_max_scan_num,mz_error_calibrated_peak,num_of_KK,&real_maxx_scan_num,&real_maxx_inten, &max_s_inten, 2*mass_dif_3DH, seqfamilies[i].ms1p[0].charge, Q);
							if (I3 < 0.0001) {
								if ((I3 < -0.999) && (I3 > -1.001)){
									cout << "The peak I3 (with given scannum) was not found. LN 629" <<endl ;
									I3 = 0.0000;
								} else if ((I3 < -1.999) && (I3 > -8.001)) {
									continue;
								}
							}
							sh[0].max_R_time = max_R_time;
							sh[0].max_s_inten= max_s_inten;
							sh[0].starting_time = starting_time;
							sh[0].end_time= end_time;
							cout << "Time of I3 " << starting_time <<" "<< max_R_time <<"  "<< end_time << endl;
							cout << "afterI3, max_scan_num= " << max_scan_num<<"   light_max_scan_num= " << light_max_scan_num <<endl;
							cout << "GGGG,I3,"<<seqfamilies[i].familyseq<<"%"<<seqfamilies[i].ms1p[0].rawfname<<"%"<<seqfamilies[i].ms1p[0].charge<<","<<light_max_scan_num<<","<<I3<<",";
							printf("%10.5f\n", seqfamilies[i].ms1p[0].mz_ms1);
							outf01 <<    "I3,"<<seqfamilies[i].familyseq<<"%"<<seqfamilies[i].ms1p[0].rawfname<<"%"<<seqfamilies[i].ms1p[0].charge<<","<<light_max_scan_num<<","<<I3<<",";
							outf01 << std::fixed << std::setprecision(5) << seqfamilies[i].ms1p[0].mz_ms1 <<endl;
						} else {   //if (negligible == true)
						}
					}// else if (seqfamilies[i].ms1p[2].scannum !=-1) { //&&seqfamilies[i].ms1p[2].scannum =-1
				}// else{ //(That means if (seqfamilies[i].ms1p[1].scannum ==-1 )
				cout << "I1="<< I1 <<"     M1="<< M1 << "     I3="<< I3 <<endl;
				total_alphaL= I1/(I1+I3); //only LL and HH. No LH or HL
				total_betaL = I1/(I1+I3);
			} else {  //  if (seqfamilies[i].ms1p[1].MS2exist_indicator== 0)
				cout<< "This sequence is in MS2 dictionary!  II[0]=I3, II[1]=I2=M1, II[2]=I1;" << endl;
				if (seqfamilies[i].ms1p[0].scannum !=-1) { // includes cases of (if_sured_mz heavy, middle, light) = (1,0,0) (1,1,0) (1,1,1) (1,0,1)
					// in this section it is sure that Q is built in heaviest peak.
					real_continue = false; // we need to use this to jump out outer loop.
					
					for (ii=0; ii<3; ii++) {
						if (seqfamilies[i].ms1p[ii].scannum !=-1){
							cout << "B4 calling PPinte for I"<<(3-ii)<<" scannum="<<seqfamilies[i].ms1p[ii].scannum << " seqfamilies[i].ms1p["<<ii<<"].mz_ms1=" << seqfamilies[i].ms1p[ii].mz_ms1;
							cout << "    fname="<<seqfamilies[i].ms1p[ii].rawfname << endl;
							theXMLfname = ffolder; theXMLfname += seqfamilies[i].ms1p[ii].rawfname; 
							theXMLfname += tail;
							strcpy(XMLfname, theXMLfname.c_str());
							II[ii] = PPintegratorA(XMLfname, seqfamilies[i].ms1p[ii].scannum, seqfamilies[i].ms1p[ii].mz_ms1, 1,1, &starting_time, &end_time, &max_R_time, &max_scan_num,mz_error_calibrating_peak,num_of_KK,&real_maxx_scan_num,&real_maxx_inten, &max_s_inten, Q);
							//II[0] means I3
							
							if (II[ii] < 0.0001) {
								if ((II[ii] < -0.999) && (II[ii] > -1.001)){
									cout << "The peak II[ii] (with given scannum) was not found. LN 749" <<endl ;
									II[ii] = 0.0000;
								} else if ((II[ii] < -1.999) && (II[ii] > -8.001)) {
									real_continue = true; //we need to break the inner loop; skip the rest of the current cycle in outer loop.
									break; 
								}
							}
							cout << "Time of I"<<(3-ii)<<" " << starting_time <<" "<< max_R_time <<"  "<< end_time << endl;
							cout << "afterI"<<(3-ii)<<", max_scan_num= " << max_scan_num << endl;
							cout << "GGGG,I"<<(3-ii)<<","<<seqfamilies[i].familyseq<<"%"<<seqfamilies[i].ms1p[0].rawfname<<"%"<<seqfamilies[i].ms1p[0].charge<<","<<max_scan_num<<","<<II[ii]<<",";
							printf("%10.5f\n", seqfamilies[i].ms1p[ii].mz_ms1);
							outf01 <<    "I"<<(3-ii)<<","<<seqfamilies[i].familyseq<<"%"<<seqfamilies[i].ms1p[0].rawfname<<"%"<<seqfamilies[i].ms1p[0].charge<<","<<max_scan_num<<","<<II[ii]<<",";
							outf01 << std::fixed << std::setprecision(5) << seqfamilies[i].ms1p[ii].mz_ms1 <<endl;
							//we need to have 
							starting_time_i3 = starting_time;
							end_time_i3 = end_time;
							max_R_time_i3= max_R_time;
							max_scan_num_i3= max_scan_num;
							sh[ii].max_R_time = max_R_time;
							sh[ii].max_s_inten= max_s_inten;
							sh[ii].starting_time = starting_time;
							sh[ii].end_time= end_time;
						} else {
							starting_time = starting_time_i3;
							end_time = end_time_i3;
							max_R_time= max_R_time_i3;
							max_scan_num= max_scan_num_i3;

							cout << "B4 calling PPinte for I"<<(3-ii) <<" scannum="<< max_scan_num << " seqfamilies[i].ms1p["<<ii<<"].mz_ms1=" << seqfamilies[i].ms1p[ii].mz_ms1;
							cout << "    fname="<<seqfamilies[i].ms1p[ii].rawfname << endl;
							theXMLfname = ffolder; theXMLfname += seqfamilies[i].ms1p[ii].rawfname; 
							theXMLfname += tail;
							strcpy(XMLfname, theXMLfname.c_str());
							II[ii] =PPintegratorB(XMLfname, max_scan_num, seqfamilies[i].ms1p[ii].mz_ms1, 0,1, &starting_time, &end_time, &max_R_time, &light_max_scan_num,mz_error_calibrated_peak,num_of_KK,&real_maxx_scan_num,&real_maxx_inten, &max_s_inten, ii*mass_dif_3DH, seqfamilies[i].ms1p[0].charge, Q);
							//Because Q is built in heaviest peak(ii=0); now middle peak (ii=1) has mz gap mass_dif_3DH/charge; lightest peak (ii=2) has mz gap 2*mass_dif_3DH/charge.
							if (II[ii] < 0.0001) {
								if ((II[ii] < -0.999) && (II[ii] > -1.001)){
									cout << "The peak II["<<ii<<"] (with given scannum) was not found. LN 778" <<endl ;
									II[ii] = 0.0000;
								} else if ((II[ii] < -1.999) && (II[ii] > -8.001)) {
									cout<< "The peak II["<<ii<<"] is mixed with other peptide."<< endl;
									real_continue = true; 
									break;
								}
							}
							sh[ii].max_R_time = max_R_time;
							sh[ii].max_s_inten= max_s_inten;
							sh[ii].starting_time = starting_time;
							sh[ii].end_time= end_time;
							cout << "Time of I"<<(3-ii)<<" " << starting_time <<" "<< max_R_time <<"  "<< end_time << endl;
							cout << "afterI"<<(3-ii)<<", max_scan_num= " << max_scan_num<<"   light_max_scan_num= " << light_max_scan_num <<endl;
							cout << "GGGG,I"<<(3-ii)<<","<<seqfamilies[i].familyseq<<"%"<<seqfamilies[i].ms1p[0].rawfname<<"%"<<seqfamilies[i].ms1p[0].charge<<","<<light_max_scan_num<<","<<II[ii]<<",";
							printf("%10.5f\n", seqfamilies[i].ms1p[ii].mz_ms1);
							outf01 <<    "I"<<(3-ii)<<","<<seqfamilies[i].familyseq<<"%"<<seqfamilies[i].ms1p[0].rawfname<<"%"<<seqfamilies[i].ms1p[0].charge<<","<<light_max_scan_num<<","<<II[ii]<<",";
							outf01 << std::fixed << std::setprecision(5) << seqfamilies[i].ms1p[ii].mz_ms1 <<endl;
						}
					}// for loop
					if ( real_continue == true) {
						cout << "The real_continue boolean works well. LN 791" << endl;
						continue;
					}
				} else if (seqfamilies[i].ms1p[1].scannum !=-1) { //the following includes cases of (0,1,1) (0,1,0)
					cout << "case for MS1 (I3, I2, I1) = (0,1,1), (0,1,0) ; 1 means scannum is given." <<endl;
					cout << "B4 calling PPinte for M1 scannum="<<seqfamilies[i].ms1p[1].scannum << " seqfamilies[i].ms1p[1].mz_ms1=" << seqfamilies[i].ms1p[1].mz_ms1 << " fname="<<seqfamilies[i].ms1p[1].rawfname << endl;
					theXMLfname = ffolder; theXMLfname += seqfamilies[i].ms1p[1].rawfname;
					theXMLfname += tail;
					strcpy(XMLfname, theXMLfname.c_str());
					II[1] =PPintegratorA(XMLfname, seqfamilies[i].ms1p[1].scannum, seqfamilies[i].ms1p[1].mz_ms1, 1,1, &starting_time, &end_time, &max_R_time, &max_scan_num,mz_error_calibrating_peak,num_of_KK,&real_maxx_scan_num,&real_maxx_inten, &max_s_inten, Q);
					
					if (II[1] < 0.0001) {
						if ((II[1] < -0.999) && (II[1] > -1.001)){
							cout << "The peak II[1] (with given scannum) was not found. LN 804" <<endl ;
							II[1] = 0.0000;
						} else if ((II[1] < -1.999) && (II[1] > -8.001)) {
							continue;
						}
					}
					// Need to record the time here to prevent... I3 cal mess up the time value which will be used in I1 cal.
					starting_time_i2 = starting_time;
					end_time_i2 = end_time;
					max_R_time_i2= max_R_time;
					max_scan_num_i2= max_scan_num;

					sh[1].max_R_time = max_R_time;
					sh[1].max_s_inten= max_s_inten;
					sh[1].starting_time = starting_time;
					sh[1].end_time= end_time;
					cout << "Time of M1" << starting_time <<" "<< max_R_time <<"  "<< end_time << endl;
					cout << "afterM1, max_scan_num= " << max_scan_num <<endl;
					cout << "GGGG,M1,"<<seqfamilies[i].familyseq<<"%"<<seqfamilies[i].ms1p[0].rawfname<<"%"<<seqfamilies[i].ms1p[0].charge<<","<<max_scan_num<<","<<II[1]<<",";
					printf("%10.5f\n", seqfamilies[i].ms1p[1].mz_ms1);
					outf01 <<    "M1,"<<seqfamilies[i].familyseq<<"%"<<seqfamilies[i].ms1p[0].rawfname<<"%"<<seqfamilies[i].ms1p[0].charge<<","<<max_scan_num<<","<<II[1]<<",";
					outf01 << std::fixed << std::setprecision(5) << seqfamilies[i].ms1p[1].mz_ms1 <<endl;
					//no active, only passive mod
					cout << "I3 passive" << endl;
					cout << "B4 calling PPinte for I3 scannum="<<seqfamilies[i].ms1p[0].scannum << " seqfamilies[i].ms1p[0].mz_ms1=" << seqfamilies[i].ms1p[0].mz_ms1;
					cout << "    fname="<<seqfamilies[i].ms1p[0].rawfname << endl;
					theXMLfname = ffolder; theXMLfname += seqfamilies[i].ms1p[0].rawfname;
					theXMLfname += tail;
					strcpy(XMLfname, theXMLfname.c_str());
					II[0] =PPintegratorB(XMLfname, max_scan_num, seqfamilies[i].ms1p[0].mz_ms1, 0,0, &starting_time, &end_time, &max_R_time, &light_max_scan_num,mz_error_calibrated_peak,num_of_KK,&real_maxx_scan_num,&real_maxx_inten, &max_s_inten, mass_dif_3DH, seqfamilies[i].ms1p[1].charge, Q);
					if (II[0] < 0.0001) {
						if ((II[0] < -0.999) && (II[0] > -1.001)){
							cout << "The peak I3 (with given scannum) was not found. LN 827" <<endl ;
							II[0] = 0.0000;
						} else if ((II[0] < -1.999) && (II[0] > -8.001)) {
							cout<< "I3 is mixed with other peptide."<< endl;
							continue;
						}
					}
					sh[0].max_R_time = max_R_time;
					sh[0].max_s_inten= max_s_inten;
					sh[0].starting_time = starting_time;
					sh[0].end_time= end_time;
					cout << "Time of I3" << starting_time <<" "<< max_R_time <<"  "<< end_time << endl;
					cout << "afterI3, max_scan_num= " << max_scan_num<<"   light_max_scan_num= " << light_max_scan_num <<endl;
					cout << "GGGG,I3,"<<seqfamilies[i].familyseq<<"%"<<seqfamilies[i].ms1p[0].rawfname<<"%"<<seqfamilies[i].ms1p[0].charge<<","<<light_max_scan_num<<","<<II[0]<<",";
					printf("%10.5f\n", seqfamilies[i].ms1p[0].mz_ms1);
					outf01 <<    "I3,"<<seqfamilies[i].familyseq<<"%"<<seqfamilies[i].ms1p[0].rawfname<<"%"<<seqfamilies[i].ms1p[0].charge<<","<<light_max_scan_num<<","<<II[0]<<",";
					outf01 << std::fixed << std::setprecision(5) << seqfamilies[i].ms1p[0].mz_ms1 <<endl;

					if (seqfamilies[i].ms1p[2].scannum !=-1){
						cout << "B4 calling PPinte for I1 scannum="<<seqfamilies[i].ms1p[2].scannum << " seqfamilies[i].ms1p[2].mz_ms1=" << seqfamilies[i].ms1p[2].mz_ms1;
						cout << "    fname="<<seqfamilies[i].ms1p[2].rawfname << endl;
						theXMLfname = ffolder; theXMLfname += seqfamilies[i].ms1p[2].rawfname;
						theXMLfname += tail;
						strcpy(XMLfname, theXMLfname.c_str());
						II[2] =PPintegratorA(XMLfname, seqfamilies[i].ms1p[2].scannum, seqfamilies[i].ms1p[2].mz_ms1, 1,1, &starting_time, &end_time, &max_R_time, &max_scan_num,mz_error_calibrating_peak,num_of_KK,&real_maxx_scan_num,&real_maxx_inten, &max_s_inten, Q);
					} else {
						//Need to retrieve the recorded the time here.
						starting_time = starting_time_i2; 
						end_time= end_time_i2;
						max_R_time = max_R_time_i2; 
						max_scan_num = max_scan_num_i2;
						cout << "B4 calling PPinte for I1 scannum="<<seqfamilies[i].ms1p[2].scannum << " seqfamilies[i].ms1p[2].mz_ms1=" << seqfamilies[i].ms1p[2].mz_ms1;
						cout << "    fname="<<seqfamilies[i].ms1p[2].rawfname << endl;
						theXMLfname = ffolder; theXMLfname += seqfamilies[i].ms1p[2].rawfname;
						theXMLfname += tail;
						strcpy(XMLfname, theXMLfname.c_str());
						II[2] = PPintegratorB(XMLfname, max_scan_num, seqfamilies[i].ms1p[2].mz_ms1, 0,1, &starting_time, &end_time, &max_R_time, &light_max_scan_num,mz_error_calibrated_peak,num_of_KK,&real_maxx_scan_num,&real_maxx_inten, &max_s_inten, mass_dif_3DH, seqfamilies[i].ms1p[0].charge, Q);
					}
					if (II[2] < 0.0001) {
						if ((II[2] < -0.999) && (II[2] > -1.001)){
							cout << "The peak I1 (with given scannum) was not found. LN 753" <<endl ;
							II[2] = 0.0000;
						} else if ((II[2] < -1.999) && (II[2] > -8.001)) {
							continue;
						}
					}
					sh[2].max_R_time = max_R_time;
					sh[2].max_s_inten= max_s_inten;
					sh[2].starting_time = starting_time;
					sh[2].end_time= end_time;
					if (seqfamilies[i].ms1p[2].scannum !=-1){
						cout << "GGGG,I1,"<<seqfamilies[i].familyseq<<"%"<<seqfamilies[i].ms1p[0].rawfname<<"%"<<seqfamilies[i].ms1p[0].charge<<","<<max_scan_num<<","<<II[2]<<",";
						outf01 <<    "I1,"<<seqfamilies[i].familyseq<<"%"<<seqfamilies[i].ms1p[0].rawfname<<"%"<<seqfamilies[i].ms1p[0].charge<<","<<max_scan_num<<","<<II[2]<<",";
					} else {
						cout << "GGGG,I1,"<<seqfamilies[i].familyseq<<"%"<<seqfamilies[i].ms1p[0].rawfname<<"%"<<seqfamilies[i].ms1p[0].charge<<","<<light_max_scan_num<<","<<II[2]<<",";
						outf01 <<    "I1,"<<seqfamilies[i].familyseq<<"%"<<seqfamilies[i].ms1p[0].rawfname<<"%"<<seqfamilies[i].ms1p[0].charge<<","<<light_max_scan_num<<","<<II[2]<<",";
					}
					printf("%10.5f\n", seqfamilies[i].ms1p[2].mz_ms1);
					outf01 << std::fixed << std::setprecision(5) << seqfamilies[i].ms1p[2].mz_ms1 <<endl;
					cout << "Time of M1" << starting_time <<" "<< max_R_time <<"  "<< end_time << endl;

					if (seqfamilies[i].ms1p[2].scannum !=-1) {
						cout << "afterM1, max_scan_num= " << max_scan_num <<endl;
					} else {
						cout << "afterM1, max_scan_num= " << max_scan_num<<"   light_max_scan_num= " << light_max_scan_num <<endl;
					}
					cout << "real_maxx_scan_num for background test is "<< real_maxx_scan_num << endl;
				} else {// (0,0,1) is nearly impossible, both site are stoich_of_light > 90% .
					cout << "case for MS1 (I3, I2, I1) = (0,0,1) ; 1 means scannum is given. BTW, dictionary is given." <<endl;
					cout << "B4 calling PPinte for I1 scannum="<<seqfamilies[i].ms1p[2].scannum << " seqfamilies[i].ms1p[1].mz_ms1=" << seqfamilies[i].ms1p[2].mz_ms1 << " fname="<<seqfamilies[i].ms1p[2].rawfname << endl;
					theXMLfname = ffolder; theXMLfname += seqfamilies[i].ms1p[2].rawfname;
					theXMLfname += tail;
					strcpy(XMLfname, theXMLfname.c_str());
					//II[1] =PPintegratorA(XMLfname, seqfamilies[i].ms1p[1].scannum, seqfamilies[i].ms1p[1].mz_ms1, 1,1, &starting_time, &end_time, &max_R_time, &max_scan_num,mz_error_calibrating_peak,num_of_KK,&real_maxx_scan_num,&real_maxx_inten, &max_s_inten, Q);
					II[2] =PPintegratorA(XMLfname, seqfamilies[i].ms1p[2].scannum, seqfamilies[i].ms1p[2].mz_ms1, 1,1, &starting_time, &end_time, &max_R_time, &max_scan_num,mz_error_calibrating_peak,num_of_KK,&real_maxx_scan_num,&real_maxx_inten, &max_s_inten, Q);
					//II[2] means I1
					if (II[2] < 0.0001) {
						if ((II[2] < -0.999) && (II[2] > -1.001)){
							cout << "The peak II[2] (with given scannum) was not found. LN 917" <<endl ;
							II[2] = 0.0000;
						} else if ((II[2] < -1.999) && (II[2] > -8.001)) {
							continue;
						}
					}
					starting_time_i1 = starting_time;
					end_time_i1 = end_time;
					max_R_time_i1= max_R_time;
					max_scan_num_i1= max_scan_num;

					sh[2].max_R_time = max_R_time;
					sh[2].max_s_inten= max_s_inten;
					sh[2].starting_time = starting_time;
					sh[2].end_time= end_time;
					cout << "GGGG,I1,"<<seqfamilies[i].familyseq<<"%"<<seqfamilies[i].ms1p[0].rawfname<<"%"<<seqfamilies[i].ms1p[0].charge<<","<<max_scan_num<<","<<II[2]<<",";
					printf("%10.5f\n", seqfamilies[i].ms1p[2].mz_ms1);
					outf01 <<    "I1,"<<seqfamilies[i].familyseq<<"%"<<seqfamilies[i].ms1p[0].rawfname<<"%"<<seqfamilies[i].ms1p[0].charge<<","<<max_scan_num<<","<<II[2]<<",";
					outf01 << std::fixed << std::setprecision(5) << seqfamilies[i].ms1p[2].mz_ms1 <<endl;

					cout << "Time of I1: " << starting_time <<" "<< max_R_time <<"  "<< end_time << endl;
					cout << "afterI1, max_scan_num= " << max_scan_num <<endl;
					cout << "B4 calling PPinte for I2 scannum="<< max_scan_num << " seqfamilies[i].ms1p[1].mz_ms1=" << seqfamilies[i].ms1p[1].mz_ms1;
					cout << "    fname="<<seqfamilies[i].ms1p[1].rawfname << endl;
					theXMLfname = ffolder; theXMLfname += seqfamilies[i].ms1p[1].rawfname;
					theXMLfname += tail;
					strcpy(XMLfname, theXMLfname.c_str());
					II[1] =PPintegratorB(XMLfname, max_scan_num, seqfamilies[i].ms1p[1].mz_ms1, 0,0, &starting_time, &end_time, &max_R_time, &light_max_scan_num,mz_error_calibrated_peak,num_of_KK,&real_maxx_scan_num,&real_maxx_inten, &max_s_inten, 1*mass_dif_3DH, seqfamilies[i].ms1p[0].charge, Q);

					if (II[1] < 0.0001) {
						if ((II[1] < -0.999) && (II[1] > -1.001)){
							cout << "The peak II[1] (with given scannum) was not found. LN 943" <<endl ;
							II[1] = 0.0000;
						} else if ((II[1] < -1.999) && (II[1] > -8.001)) {
							continue;
						}
					}
					sh[1].max_R_time = max_R_time;
					sh[1].max_s_inten= max_s_inten;
					sh[1].starting_time = starting_time;
					sh[1].end_time= end_time;
					cout << "Time of I2: " << starting_time <<" "<< max_R_time <<"  "<< end_time << endl;
					cout << "afterI2, max_scan_num= " << max_scan_num <<endl;
					cout << "GGGG,I2,"<<seqfamilies[i].familyseq<<"%"<<seqfamilies[i].ms1p[0].rawfname<<"%"<<seqfamilies[i].ms1p[0].charge<<","<<light_max_scan_num<<","<<II[1]<<",";
					printf("%10.5f\n", seqfamilies[i].ms1p[1].mz_ms1);
					outf01 <<    "I2,"<<seqfamilies[i].familyseq<<"%"<<seqfamilies[i].ms1p[0].rawfname<<"%"<<seqfamilies[i].ms1p[0].charge<<","<<light_max_scan_num<<","<<II[1]<<",";
					outf01 << std::fixed << std::setprecision(5) << seqfamilies[i].ms1p[1].mz_ms1 <<endl;

					starting_time = starting_time_i1;
					end_time = end_time_i1;
					max_R_time= max_R_time_i1;
					max_scan_num= max_scan_num_i1; //this align with lightest; if you use max_scan_num=light_max_scan_num then it aligned with nearest.
					
					cout << "B4 calling PPinte for I3 scannum="<< max_scan_num << " seqfamilies[i].ms1p[0].mz_ms1=" << seqfamilies[i].ms1p[0].mz_ms1;
					cout << "    fname="<<seqfamilies[i].ms1p[0].rawfname << endl;
					theXMLfname = ffolder; theXMLfname += seqfamilies[i].ms1p[0].rawfname;
					theXMLfname += tail;
					strcpy(XMLfname, theXMLfname.c_str());
					II[0] =PPintegratorB(XMLfname, max_scan_num, seqfamilies[i].ms1p[0].mz_ms1, 0,0, &starting_time, &end_time, &max_R_time, &light_max_scan_num,mz_error_calibrated_peak,num_of_KK,&real_maxx_scan_num,&real_maxx_inten, &max_s_inten, 2*mass_dif_3DH, seqfamilies[i].ms1p[0].charge, Q);

					if (II[0] < 0.0001) {
						if ((II[0] < -0.999) && (II[0] > -1.001)){
							cout << "The peak II[0] (with given scannum) was not found. LN 943" <<endl ;
							II[0] = 0.0000;
						} else if ((II[0] < -0.999) && (II[0] > -8.001)) {
							continue;
						}
					}
					sh[0].max_R_time = max_R_time;
					sh[0].max_s_inten= max_s_inten;
					sh[0].starting_time = starting_time;
					sh[0].end_time= end_time;
					cout << "Time of I3: " << starting_time <<" "<< max_R_time <<"  "<< end_time << endl;
					cout << "afterI3, max_scan_num= " << max_scan_num <<endl;
					cout << "GGGG,I3,"<<seqfamilies[i].familyseq<<"%"<<seqfamilies[i].ms1p[0].rawfname<<"%"<<seqfamilies[i].ms1p[0].charge<<","<<light_max_scan_num<<","<<II[0]<<",";
					printf("%10.5f\n", seqfamilies[i].ms1p[0].mz_ms1);
					outf01 <<    "I3,"<<seqfamilies[i].familyseq<<"%"<<seqfamilies[i].ms1p[0].rawfname<<"%"<<seqfamilies[i].ms1p[0].charge<<","<<light_max_scan_num<<","<<II[0]<<",";
					outf01 << std::fixed << std::setprecision(5) << seqfamilies[i].ms1p[0].mz_ms1 <<endl;
				}
				// Here we know the correspondant MS2exist_indicator == 1;
				// So now we look up the seq in dictionary.
				alphaL_frac[0]=0.000;  betaL_frac[0]=0.000;
				for (j=0; j<dictionary.size(); j++) {
					if (seqfamilies[i].familyseq.compare(dictionary[j].familyseq)==0){
						for  (jj=0; jj<dictionary[j].peak.size(); jj++) {
							if ( dictionary[j].peak[jj].ms1peak_order == 2 ) { //looking for I2
								//for (k=0; k<dictionary[j].peak[jj].GreekL_frac.size(); k++){
								alphaL_frac[0]=dictionary[j].peak[jj].GreekL_frac[0];
								betaL_frac[0] =dictionary[j].peak[jj].GreekL_frac[1];
								//}
								break;
							}
						}//for jj
						break;
					}// if familyseq are the same
				}//for j

				cout << "II[2]=" << II[2]<<"     II[1]="<< II[1] << "     II[0]=" << II[0] << "  beta"<<endl;
				cout << "alphaL_frac[0]=" << alphaL_frac[0] << "       betaL_frac[0]=" << betaL_frac[0] << endl;
				if (II[0]==-1) {II[0]=0.0000;}
				if (II[1]==-1) {II[1]=0.0000;}
				if (II[2]==-1) {II[2]=0.0000;}
				total_alphaL= (II[2]+II[1]*alphaL_frac[0])/(II[0]+II[1]+II[2]);
				total_betaL = (II[2]+II[1]*betaL_frac[0] )/(II[0]+II[1]+II[2]);
			} // if (seqfamilies[i].ms1p[1].MS2exist_indicator== 0) {} else {
			cout << "total_alphaL= " << total_alphaL <<"  total_betaL= " << total_betaL; 
			cout << "     seqfamilies[i].familyseq=" <<seqfamilies[i].familyseq<<"   fname="<<seqfamilies[i].ms1p[0].rawfname<<endl<<endl;

			outf02 << "total_alphaL= " << total_alphaL <<"  total_betaL= " << total_betaL;
			outf02 << "     seqfamilies[i].familyseq=" <<seqfamilies[i].familyseq<<"   fname="<<seqfamilies[i].ms1p[0].rawfname<<endl;

			if ((total_alphaL > 0.00000) || (total_betaL > 0.00000)) { 
				if (((total_alphaL - total_betaL) < 0.00001) && ((total_alphaL - total_betaL) > -0.00001)) {
					// in the below the index of the array is consistent with code in 2K, that is the ii for II[ii]; but different from 1K which has sh[0] as light one.
					// Here sh[0] represents heavy peak.
					cout << "utal_alpha,"<<total_alphaL<<","<<total_betaL<<",,,"<<seqfamilies[i].familyseq<<","<<seqfamilies[i].ms1p[0].rawfname;
					cout << ",heavy,"<< sh[0].max_R_time << "," << sh[0].max_s_inten << "," << sh[0].starting_time << "," << sh[0].end_time;
					cout << ",light,"<< sh[2].max_R_time << "," << sh[2].max_s_inten << "," << sh[2].starting_time << "," << sh[2].end_time; 
					cout << ",middle,,,,"<<endl<<endl;
				} else {
					cout << "utal_alpha,"<<total_alphaL<<","<<total_betaL<<",,,"<<seqfamilies[i].familyseq<<","<<seqfamilies[i].ms1p[0].rawfname;
					cout << ",heavy,"<< sh[0].max_R_time << "," << sh[0].max_s_inten << "," << sh[0].starting_time << "," << sh[0].end_time;
					cout << ",light,"<< sh[2].max_R_time << "," << sh[2].max_s_inten << "," << sh[2].starting_time << "," << sh[2].end_time;
					cout << ",middle,"<< sh[1].max_R_time << "," << sh[1].max_s_inten << "," << sh[1].starting_time << "," << sh[1].end_time<<endl<<endl;
				}
			}
		}// end of if (seqfamilies[i].num_of_K == 2)


		if (seqfamilies[i].num_of_K == 3) {
			cout <<"3Kcase   ms1psize=" <<  seqfamilies[i].ms1p.size() << endl;
			num_of_KK =3;
			if ((seqfamilies[i].ms1p[1].MS2exist_indicator== 0) && (seqfamilies[i].ms1p[1].scannum !=-1 )) {
				cout << "middle peak I3 larger than background noise; supposed, because scannum of middle peak is given. dump." <<endl;
				continue;
			}
			if ((seqfamilies[i].ms1p[2].MS2exist_indicator== 0) && (seqfamilies[i].ms1p[2].scannum !=-1 )) {
				cout << "middle peak I2 larger than background noise; supposed, because scannum of middle peak is given. dump." <<endl;
				continue;
			}
			
			if ((seqfamilies[i].ms1p[1].MS2exist_indicator== 0) && (seqfamilies[i].ms1p[1].scannum ==-1 )) { // (if_sured_mz[1] == 0)
				if (seqfamilies[i].ms1p[0].scannum !=-1){ // (if_sured_mz[0] == 1)
					cout << "B4 calling PPinte for I4 scannum="<<seqfamilies[i].ms1p[0].scannum << "   seqfamilies[i].ms1p[0].mz_ms1=" << seqfamilies[i].ms1p[0].mz_ms1;
					cout << "   fname="<<seqfamilies[i].ms1p[0].rawfname <<endl;
					theXMLfname = ffolder; theXMLfname += seqfamilies[i].ms1p[0].rawfname;
					theXMLfname += tail;
					strcpy(XMLfname, theXMLfname.c_str());
					I4 = PPintegratorA(XMLfname, seqfamilies[i].ms1p[0].scannum, seqfamilies[i].ms1p[0].mz_ms1, 1,1,&starting_time, &end_time, &max_R_time, &max_scan_num,mz_error_calibrating_peak,num_of_KK,&real_maxx_scan_num,&real_maxx_inten, &max_s_inten, Q4); //heavy

					if (I4 < 0.0001) {
						if ((I4 < -0.999) && (I4 > -1.001)){
							cout << "The peak I4 (with given scannum) was not found. LN 1155" <<endl ;
							I4 = 0.0000;
							continue;
						} else if ((I4 < -1.999) && (I4 > -8.001)) {
							continue;
						} else if ((I4 < -19.999)&& (I4 > -20.001)) {
							return 0; //cannot open the file. exit
						}
					}
					cout << "Time of I4 " << starting_time <<" "<< max_R_time <<"  "<< end_time << endl;
					cout << "afterI4, max_scan_num= " << max_scan_num <<endl;
					//cout << "GGGG,I4,"<<seqfamilies[i].familyseq<<"%"<<seqfamilies[i].ms1p[0].rawfname<<"%"<<seqfamilies[i].ms1p[0].charge<<","<<max_scan_num<<","<<II[0]<<",";
					cout << "GGGG,I4,"<<seqfamilies[i].familyseq<<"%"<<seqfamilies[i].ms1p[0].rawfname<<"%"<<seqfamilies[i].ms1p[0].charge<<","<<max_scan_num<<","<<I4<<",";
					printf("%10.5f\n", seqfamilies[i].ms1p[0].mz_ms1);
					outf01 <<    "I4,"<<seqfamilies[i].familyseq<<"%"<<seqfamilies[i].ms1p[0].rawfname<<"%"<<seqfamilies[i].ms1p[0].charge<<","<<max_scan_num<<","<<I4<<",";
					outf01 << std::fixed << std::setprecision(5) << seqfamilies[i].ms1p[0].mz_ms1 <<endl;

					starting_time_i4 = starting_time;
					end_time_i4 = end_time;
					max_R_time_i4= max_R_time;
					max_scan_num_i4= max_scan_num;
					sh[0].max_R_time = max_R_time;
					sh[0].max_s_inten= max_s_inten;
					sh[0].starting_time = starting_time;
					sh[0].end_time= end_time;

					light_max_scan_num = 0;
					cout << "passive I3" << endl;
					cout << "B4 calling PPinte for M2(or I3) scannum="<<seqfamilies[i].ms1p[1].scannum << " seqfamilies[i].ms1p[1].mz_ms1=" << seqfamilies[i].ms1p[1].mz_ms1;
					cout << "    fname="<<seqfamilies[i].ms1p[1].rawfname <<endl;
					theXMLfname = ffolder; theXMLfname += seqfamilies[i].ms1p[1].rawfname;
					theXMLfname += tail;
					strcpy(XMLfname, theXMLfname.c_str());
					I3 = PPintegratorB(XMLfname, max_scan_num, seqfamilies[i].ms1p[1].mz_ms1, 0,1, &starting_time, &end_time, &max_R_time, &light_max_scan_num,mz_error_calibrated_peak,num_of_KK,&real_maxx_scan_num,&real_maxx_inten, &max_s_inten, mass_dif_3DH, seqfamilies[i].ms1p[0].charge, Q4);

					cout << "I3 =" << I3 <<endl; 
					negligibleI3 = false;
					if (I3 < 0.0001) {
						if (((I3 < -0.999) && (I3 > -1.001))|| (I3==0)) {
							cout << "The peak I3 (with given scannum) was not found. LN 1092" <<endl ;
							negligibleI3 = true;
						} else if ((I3 < -1.999) && (I3 > -9.00)) {
							cout << "return value of I3 range between -2 and -9, dump." << endl;
							continue; // peak is there but cannot get the value! dump!
						}
					}
					if (negligibleI3 == false) {
						cout << "Time of I3 " << starting_time <<" "<< max_R_time <<"  "<< end_time << endl;
						cout << "afterI3, max_scan_num= " << max_scan_num<<"   light_max_scan_num= " << light_max_scan_num <<endl;
						cout << "real_maxx_scan_num for background test is "<< real_maxx_scan_num << endl;
						threshold= 3 * noise_level(XMLfname, real_maxx_scan_num);
						cout << "threshold=" <<threshold<<"  real_maxx_inten=" << real_maxx_inten <<endl;
						if (real_maxx_inten > threshold) {
							cout << "I3 apex larger than background noise but sequence is not in MS2 dictionary. dump." << endl;
							continue;
						} else {
							negligibleI3 = true;
						}
					}
					sh[1].max_R_time = max_R_time;
					sh[1].max_s_inten= max_s_inten;
					sh[1].starting_time = starting_time;
					sh[1].end_time= end_time;
					
					if (negligibleI3 == true) {
						I3=0.000000; //alphaL_frac[0]=0.000; betaL_frac[0] =0.000;  ///?? CHECK with 	     
						if (seqfamilies[i].ms1p[2].MS2exist_indicator == 0) {
							//passive cal I2
							cout << "GGGG,I3,"<<seqfamilies[i].familyseq<<"%"<<seqfamilies[i].ms1p[0].rawfname<<"%"<<seqfamilies[i].ms1p[0].charge<<","<<light_max_scan_num<<","<<0.00<<",";
							printf("%10.5f\n", seqfamilies[i].ms1p[1].mz_ms1);
							outf01 <<    "I3,"<<seqfamilies[i].familyseq<<"%"<<seqfamilies[i].ms1p[0].rawfname<<"%"<<seqfamilies[i].ms1p[0].charge<<","<<light_max_scan_num<<","<<0.00<<",";
							outf01 << std::fixed << std::setprecision(5) << seqfamilies[i].ms1p[1].mz_ms1 <<endl;

							cout << "I2 passive" << endl;
							starting_time = starting_time_i4;
							end_time= end_time_i4;
							max_R_time = max_R_time_i4;
							max_scan_num = max_scan_num_i4;

							light_max_scan_num =0;
							cout << "B4 calling PPinte for I2 scannum="<<seqfamilies[i].ms1p[2].scannum << " seqfamilies[i].ms1p[2].mz_ms1=" << seqfamilies[i].ms1p[2].mz_ms1;
							cout << "    fname="<<seqfamilies[i].ms1p[2].rawfname <<endl;
							theXMLfname = ffolder; theXMLfname += seqfamilies[i].ms1p[2].rawfname;
							theXMLfname += tail;
							strcpy(XMLfname, theXMLfname.c_str());
							I2 = PPintegratorB(XMLfname, max_scan_num, seqfamilies[i].ms1p[2].mz_ms1, 0,1, &starting_time, &end_time, &max_R_time, &light_max_scan_num,mz_error_calibrated_peak,num_of_KK,&real_maxx_scan_num,&real_maxx_inten, &max_s_inten, 2*mass_dif_3DH, seqfamilies[i].ms1p[0].charge, Q4);

							negligibleI2 = false;
							if (I2 < 0.0001) {
								if ((I2 < -0.999) && (I2 > -1.001)) {
									cout << "The peak I2 (with given scannum) was not found. LN 885" <<endl ;
									negligibleI2 = true;
								} else if ((I2 < -1.999) && (I2 > -8.001)) {
									continue; // peak is there but cannot get the value! dump!
								}
							}
							if (negligibleI2 == false) {
								cout << "Time of I2 " << starting_time <<" "<< max_R_time <<"  "<< end_time << endl;
								cout << "afterI2,    max_scan_num= " << max_scan_num <<"   light_max_scan_num= " << light_max_scan_num << endl;
								cout << "real_maxx_scan_num for background test is "<< real_maxx_scan_num << endl;
								threshold= 3 * noise_level(XMLfname, real_maxx_scan_num);
								cout << "threshold=" <<threshold<<"  real_maxx_inten=" << real_maxx_inten <<endl;
								if (real_maxx_inten > threshold) {
									cout << "I2 apex larger than background noise but sequence is not in MS2 dictionary. dump." << endl;
									continue;
								} else {
									negligibleI2 = true;
								}
							}
							sh[2].max_R_time = max_R_time;
							sh[2].max_s_inten= max_s_inten;
							sh[2].starting_time = starting_time;
							sh[2].end_time= end_time;

							if (negligibleI2 == true) { //if ( (I2 == 0.00) || (I2 <= threshold) ) {
								I2=0.000000;
								cout << "GGGG,I2,"<<seqfamilies[i].familyseq<<"%"<<seqfamilies[i].ms1p[0].rawfname<<"%"<<seqfamilies[i].ms1p[0].charge<<","<<light_max_scan_num<<","<<0.00<<",";
								printf("%10.5f\n", seqfamilies[i].ms1p[2].mz_ms1);
								outf01 <<    "I2,"<<seqfamilies[i].familyseq<<"%"<<seqfamilies[i].ms1p[0].rawfname<<"%"<<seqfamilies[i].ms1p[0].charge<<","<<light_max_scan_num<<","<<0.00<<",";
								outf01 << std::fixed << std::setprecision(5) << seqfamilies[i].ms1p[2].mz_ms1 <<endl;

								//cal I1
								if (seqfamilies[i].ms1p[3].scannum !=-1) {
									cout << "I1 active" << endl;
									cout << "B4 calling PPinte for I1 scannum="<<seqfamilies[i].ms1p[3].scannum << " seqfamilies[i].ms1p[3].mz_ms1=" << seqfamilies[i].ms1p[3].mz_ms1;
									cout << "   fname="<<seqfamilies[i].ms1p[3].rawfname <<endl;
									theXMLfname = ffolder; theXMLfname += seqfamilies[i].ms1p[3].rawfname;
									theXMLfname += tail;
									strcpy(XMLfname, theXMLfname.c_str());
									I1 = PPintegratorA(XMLfname, seqfamilies[i].ms1p[3].scannum, seqfamilies[i].ms1p[3].mz_ms1, 1,1, &starting_time, &end_time, &max_R_time, &max_scan_num,mz_error_calibrating_peak,num_of_KK,&real_maxx_scan_num,&real_maxx_inten, &max_s_inten, Q1);
								} else {
									cout << "I1 passive" << endl;
									starting_time = starting_time_i4;
									end_time= end_time_i4;
									max_R_time = max_R_time_i4;
									max_scan_num = max_scan_num_i4;
									light_max_scan_num =0;
									cout << "B4 calling PPinte for I1 scannum="<<seqfamilies[i].ms1p[3].scannum << " seqfamilies[i].ms1p[3].mz_ms1=" << seqfamilies[i].ms1p[3].mz_ms1;
									cout << "    fname="<<seqfamilies[i].ms1p[3].rawfname <<endl;
									theXMLfname = ffolder; theXMLfname += seqfamilies[i].ms1p[3].rawfname;
									theXMLfname += tail;
									strcpy(XMLfname, theXMLfname.c_str());
									I1 = PPintegratorB(XMLfname, max_scan_num, seqfamilies[i].ms1p[3].mz_ms1, 0,1, &starting_time, &end_time, &max_R_time, &light_max_scan_num,mz_error_calibrated_peak,num_of_KK,&real_maxx_scan_num,&real_maxx_inten, &max_s_inten, 3*mass_dif_3DH, seqfamilies[i].ms1p[0].charge, Q4);
								}
								if (I1 < 0.0001) {
									if ((I1 < -0.999) && (I1 > -1.001)){
										cout << "The peak I1 (with given scannum) was not found. LN 1299" <<endl ;
										I1 = 0.0000;
									} else if ((I1 < -1.999) && (I1 > -8.001)) {
										continue;
									}
								}
								cout << "Time of I1 " << starting_time <<" "<< max_R_time <<"  "<< end_time << endl;
								if (seqfamilies[i].ms1p[3].scannum !=-1) {
									cout << "afterI1,    max_scan_num= " << max_scan_num << endl;
								} else {
									cout << "afterI1,    max_scan_num= " << max_scan_num <<"    light_max_scan_num= " << light_max_scan_num<< endl;
								}
								sh[3].max_R_time = max_R_time;
								sh[3].max_s_inten= max_s_inten;
								sh[3].starting_time = starting_time;
								sh[3].end_time= end_time;
								if (seqfamilies[i].ms1p[3].scannum !=-1) {
									cout << "GGGG,I1,"<<seqfamilies[i].familyseq<<"%"<<seqfamilies[i].ms1p[0].rawfname<<"%"<<seqfamilies[i].ms1p[0].charge<<","<<max_scan_num<<","<<I1<<",";
									outf01 <<    "I1,"<<seqfamilies[i].familyseq<<"%"<<seqfamilies[i].ms1p[0].rawfname<<"%"<<seqfamilies[i].ms1p[0].charge<<","<<max_scan_num<<","<<I1<<",";
								} else {
									cout << "GGGG,I1,"<<seqfamilies[i].familyseq<<"%"<<seqfamilies[i].ms1p[0].rawfname<<"%"<<seqfamilies[i].ms1p[0].charge<<","<<light_max_scan_num<<","<<I1<<",";
									outf01 <<    "I1,"<<seqfamilies[i].familyseq<<"%"<<seqfamilies[i].ms1p[0].rawfname<<"%"<<seqfamilies[i].ms1p[0].charge<<","<<light_max_scan_num<<","<<I1<<",";
								}
								printf("%10.5f\n", seqfamilies[i].ms1p[3].mz_ms1);
								outf01 << std::fixed << std::setprecision(5) << seqfamilies[i].ms1p[3].mz_ms1 <<endl;
							}//end of if (negligibleI2 == true)
						} else { //active cal I2, then I1 //assume: if it is in dictionary, it should be given scannum.
							if (seqfamilies[i].ms1p[2].scannum ==-1) { cout << "WRONG ASSUMPTION HERE.YOU SHOULD CORRECT YOU CODE."; 
								cout << "You need to consider case in which scannum is not given for I2 LN 947-948" << endl; return 0;
							}
							cout << "I2 active" << endl;
							cout << "B4 calling PPinte for I2 scannum="<< seqfamilies[i].ms1p[2].scannum << " seqfamilies[i].ms1p[2].mz_ms1=" << seqfamilies[i].ms1p[2].mz_ms1;
							cout << "    fname="<<seqfamilies[i].ms1p[2].rawfname <<endl;
							theXMLfname = ffolder; theXMLfname += seqfamilies[i].ms1p[2].rawfname;
							theXMLfname += tail;
							strcpy(XMLfname, theXMLfname.c_str());
							I2 = PPintegratorA(XMLfname, seqfamilies[i].ms1p[2].scannum, seqfamilies[i].ms1p[2].mz_ms1, 1,1, &starting_time, &end_time, &max_R_time, &max_scan_num,mz_error_calibrating_peak,num_of_KK,&real_maxx_scan_num,&real_maxx_inten, &max_s_inten, Q2);
							if (I2 < 0.0001) {
								if ((I2 < -0.999) && (I2 > -1.001)){
									cout << "The peak I2 (with given scannum) was not found. LN 958" <<endl ;
									I2 = 0.0000;
								} else if ((I2 < -1.999) && (I2 > -8.001)) {
									continue; // peak is there but cannot get the value! dump!
								}
							}

							sh[2].max_R_time = max_R_time;
							sh[2].max_s_inten= max_s_inten;
							sh[2].starting_time = starting_time;
							sh[2].end_time= end_time;
							cout << "GGGG,I2,"<<seqfamilies[i].familyseq<<"%"<<seqfamilies[i].ms1p[0].rawfname<<"%"<<seqfamilies[i].ms1p[0].charge<<","<<max_scan_num<<","<<I2<<",";
							printf("%10.5f\n", seqfamilies[i].ms1p[2].mz_ms1);
							outf01 <<    "I2,"<<seqfamilies[i].familyseq<<"%"<<seqfamilies[i].ms1p[0].rawfname<<"%"<<seqfamilies[i].ms1p[0].charge<<","<<max_scan_num<<","<<I2<<",";
							outf01 << std::fixed << std::setprecision(5) << seqfamilies[i].ms1p[2].mz_ms1 <<endl;
							cout << "Time of I2 " << starting_time <<" "<< max_R_time <<"  "<< end_time << endl;
							cout << "afterI2,    max_scan_num= " << max_scan_num << endl;

							if (seqfamilies[i].ms1p[3].scannum !=-1) {
								cout << "I1 active" << endl;
								cout << "B4 calling PPinte for I1 scannum="<<seqfamilies[i].ms1p[3].scannum << " seqfamilies[i].ms1p[3].mz_ms1=" << seqfamilies[i].ms1p[3].mz_ms1;
								cout << "    fname="<<seqfamilies[i].ms1p[3].rawfname <<endl;
								theXMLfname = ffolder; theXMLfname += seqfamilies[i].ms1p[3].rawfname;
								theXMLfname += tail;
								strcpy(XMLfname, theXMLfname.c_str());
								I1 = PPintegratorA(XMLfname, seqfamilies[i].ms1p[3].scannum, seqfamilies[i].ms1p[3].mz_ms1, 1,1, &starting_time, &end_time, &max_R_time, &max_scan_num,mz_error_calibrating_peak,num_of_KK,&real_maxx_scan_num,&real_maxx_inten, &max_s_inten, Q1);
							} else {
								cout << "I1 passive" << endl;
								if ( I4 > (2*I2) ) {		    
									starting_time = starting_time_i4;
									end_time= end_time_i4;
									max_R_time = max_R_time_i4;
									max_scan_num = max_scan_num_i4;
									cout << "using I4 result to set up I1's time limits" <<endl; 
									//we have to save Q at I4 as Q4 first
									light_max_scan_num =0;
									cout << "B4 calling PPinte for I1 scannum="<<seqfamilies[i].ms1p[3].scannum << " seqfamilies[i].ms1p[3].mz_ms1=" << seqfamilies[i].ms1p[3].mz_ms1;
									cout << "    fname="<<seqfamilies[i].ms1p[3].rawfname <<endl;
									theXMLfname = ffolder; theXMLfname += seqfamilies[i].ms1p[3].rawfname;
									theXMLfname += tail;
									strcpy(XMLfname, theXMLfname.c_str());
									I1 = PPintegratorB(XMLfname, max_scan_num, seqfamilies[i].ms1p[3].mz_ms1, 0,1, &starting_time, &end_time, &max_R_time, &light_max_scan_num,mz_error_calibrated_peak,num_of_KK,&real_maxx_scan_num,&real_maxx_inten, &max_s_inten,3*mass_dif_3DH, seqfamilies[i].ms1p[0].charge, Q4);
								} else { 
									cout << "using I2 result to set up I1's time limits" <<endl;
									light_max_scan_num =0;
									cout << "B4 calling PPinte for I1 scannum="<<seqfamilies[i].ms1p[3].scannum << " seqfamilies[i].ms1p[3].mz_ms1=" << seqfamilies[i].ms1p[3].mz_ms1;
									cout << "    fname="<<seqfamilies[i].ms1p[3].rawfname <<endl;
									theXMLfname = ffolder; theXMLfname += seqfamilies[i].ms1p[3].rawfname;
									theXMLfname += tail;
									strcpy(XMLfname, theXMLfname.c_str());
									I1 = PPintegratorB(XMLfname, max_scan_num, seqfamilies[i].ms1p[3].mz_ms1, 0,1, &starting_time, &end_time, &max_R_time, &light_max_scan_num,mz_error_calibrated_peak,num_of_KK,&real_maxx_scan_num,&real_maxx_inten, &max_s_inten, mass_dif_3DH, seqfamilies[i].ms1p[0].charge, Q2);
									//As Q was rebuilt in actively searching I2, so,... here we use 1*mass_dif_3DH instead of 3*mass_dif_3DH.
								}

							}
							if (I1 < 0.0001) {
								if ((I1 < -0.999) && (I1 > -1.001)){
									cout << "The peak I1 (with given scannum) was not found. LN 994" <<endl ;
									I1 = 0.00000;
								} else if ((I1 < -1.999) && (I1 > -8.001)) {
									continue; // peak is there but cannot get the value! dump!
								}
							}
							sh[3].max_R_time = max_R_time;
							sh[3].max_s_inten= max_s_inten;
							sh[3].starting_time = starting_time;
							sh[3].end_time= end_time;
							cout << "GGGG,I1,"<<seqfamilies[i].familyseq<<"%"<<seqfamilies[i].ms1p[0].rawfname<<"%"<<seqfamilies[i].ms1p[0].charge<<","<<max_scan_num<<","<<I1<<",";
							printf("%10.5f\n", seqfamilies[i].ms1p[3].mz_ms1);
							outf01 <<    "I1,"<<seqfamilies[i].familyseq<<"%"<<seqfamilies[i].ms1p[0].rawfname<<"%"<<seqfamilies[i].ms1p[0].charge<<","<<max_scan_num<<","<<I1<<",";
							outf01 << std::fixed << std::setprecision(5) << seqfamilies[i].ms1p[3].mz_ms1 <<endl;
							cout << "Time of I1 " << starting_time <<" "<< max_R_time <<"  "<< end_time << endl;
							if (seqfamilies[i].ms1p[3].scannum !=-1) {
								cout << "afterI1,    max_scan_num= " << max_scan_num << endl;
							} else {
								cout << "afterI1,    max_scan_num= " << max_scan_num <<"    light_max_scan_num= " << light_max_scan_num<< endl;
							}
						}//end of "MS2 dictionary for I2 exists"

					} //end of  if (negligibleI3 == true)  no need to do else {continue;}// It was end of if( (I3 == 0.00) || (I3 <= threshold)
				} else if ((seqfamilies[i].ms1p[2].MS2exist_indicator== 1) && (seqfamilies[i].ms1p[2].scannum !=-1 )) {// (I2 ms2 ==1 && I2 ms1 ==1 ) {
					//active cal I2
					cout << "I2 active" << endl;
					cout << "B4 calling PPinte for I2 scannum="<<seqfamilies[i].ms1p[2].scannum << " seqfamilies[i].ms1p[2].mz_ms1=" << seqfamilies[i].ms1p[2].mz_ms1;
					cout << "   fname="<<seqfamilies[i].ms1p[2].rawfname <<endl;
					theXMLfname = ffolder; theXMLfname += seqfamilies[i].ms1p[2].rawfname;
					theXMLfname += tail;
					strcpy(XMLfname, theXMLfname.c_str());
					I2 = PPintegratorA(XMLfname, seqfamilies[i].ms1p[2].scannum, seqfamilies[i].ms1p[2].mz_ms1, 1,1, &starting_time, &end_time, &max_R_time, &max_scan_num,mz_error_calibrating_peak,num_of_KK,&real_maxx_scan_num,&real_maxx_inten, &max_s_inten, Q2);

					if (I2 < 0.0001) {
						if ((I2 < -0.999) && (I2 > -1.001)){
							cout << "The peak I2 (with given scannum) was not found. LN 1430" <<endl ;
							I2 = 0.0000;
						} else if ((I2 < -1.999) && (I2 > -8.001)) {
							continue; // peak is there but cannot get the value! dump!
						}
					}
					cout << "Time of I2 " << starting_time <<" "<< max_R_time <<"  "<< end_time << endl;
					cout << "afterI2,    max_scan_num= " << max_scan_num << endl;
					cout << "GGGG,I2,"<<seqfamilies[i].familyseq<<"%"<<seqfamilies[i].ms1p[0].rawfname<<"%"<<seqfamilies[i].ms1p[0].charge<<","<<max_scan_num<<","<<I2<<",";
					printf("%10.5f\n", seqfamilies[i].ms1p[2].mz_ms1);
					outf01 <<    "I2,"<<seqfamilies[i].familyseq<<"%"<<seqfamilies[i].ms1p[0].rawfname<<"%"<<seqfamilies[i].ms1p[0].charge<<","<<max_scan_num<<","<<I2<<",";
					outf01 << std::fixed << std::setprecision(5) << seqfamilies[i].ms1p[2].mz_ms1 <<endl;

					// if I1 ms1 ==0 then  save all arguments here for I1 cal.
					starting_time_i2 = starting_time;
					end_time_i2 = end_time;
					max_R_time_i2= max_R_time;
					max_scan_num_i2= max_scan_num;
					sh[2].max_R_time = max_R_time;
					sh[2].max_s_inten= max_s_inten;
					sh[2].starting_time = starting_time;
					sh[2].end_time= end_time;
					//pasive cal I3
					light_max_scan_num=0;
					cout << "I3 passive" << endl;
					cout << "B4 calling PPinte for I3 scannum="<<seqfamilies[i].ms1p[1].scannum << "   seqfamilies[i].ms1p[1].mz_ms1=" << seqfamilies[i].ms1p[1].mz_ms1;
					cout << "   fname="<<seqfamilies[i].ms1p[1].rawfname <<endl;
					theXMLfname = ffolder; theXMLfname += seqfamilies[i].ms1p[1].rawfname;
					theXMLfname += tail;
					strcpy(XMLfname, theXMLfname.c_str());
					I3 = PPintegratorB(XMLfname, max_scan_num, seqfamilies[i].ms1p[1].mz_ms1, 0,0, &starting_time, &end_time, &max_R_time, &light_max_scan_num,mz_error_calibrated_peak,num_of_KK,&real_maxx_scan_num,&real_maxx_inten, &max_s_inten, mass_dif_3DH, seqfamilies[i].ms1p[0].charge, Q2);

					negligibleI3 = false;
					if (I3 < 0.0001) {
						if ((I3 < -0.999) && (I3 > -1.001)) {
							cout << "The peak I3 (with given scannum) was not found. LN 1049" <<endl ;
							negligibleI3 = true;
						} else if ((I3 < -1.999) && (I3 > -8.001)) {
							continue; // peak is there but cannot get the value! dump!
						}
					}	   

					if (negligibleI3 == false) {
						cout << "Time of I3 " << starting_time <<" "<< max_R_time <<"  "<< end_time << endl;
						cout << "afterI3,    max_scan_num= " << max_scan_num <<"    light_max_scan_num= " << light_max_scan_num<< endl;
						cout << "real_maxx_scan_num for background test is "<< real_maxx_scan_num << endl;
						threshold= 3 * noise_level(XMLfname, real_maxx_scan_num); //light_max_scan_num instead of max_scan_num?
						cout << "threshold=" <<threshold<<"  real_maxx_inten=" << real_maxx_inten <<endl;
						if ( real_maxx_inten > threshold) {
							cout << "I3 apex larger than background noise but sequence is not in MS2 dictionary. dump." << endl;
							continue;
						} else {
							negligibleI3 = true;
						}
					}
					sh[1].max_R_time = max_R_time;
					sh[1].max_s_inten= max_s_inten;
					sh[1].starting_time = starting_time;
					sh[1].end_time= end_time;

					if (negligibleI3 == true) {
						I3=0.000000; //alphaL_frac[0]=0.000; betaL_frac[0] =0.000;  ///?? CHECK with
						cout << "I4 passive" << endl;
						//I3 is negligible, means it is very small, better use I2
						starting_time = starting_time_i2;
						end_time = end_time_i2;
						max_R_time = max_R_time_i2;
						max_scan_num = max_scan_num_i2;
						light_max_scan_num=0;
						cout << "GGGG,I3,"<<seqfamilies[i].familyseq<<"%"<<seqfamilies[i].ms1p[0].rawfname<<"%"<<seqfamilies[i].ms1p[0].charge<<","<<max_scan_num<<","<<I3<<",";
						printf("%10.5f\n", seqfamilies[i].ms1p[1].mz_ms1);
						outf01 <<    "I3,"<<seqfamilies[i].familyseq<<"%"<<seqfamilies[i].ms1p[0].rawfname<<"%"<<seqfamilies[i].ms1p[0].charge<<","<<max_scan_num<<","<<I3<<",";
						outf01 << std::fixed << std::setprecision(5) << seqfamilies[i].ms1p[1].mz_ms1 <<endl;

						cout << "B4 calling PPinte for I4 scannum="<<seqfamilies[i].ms1p[0].scannum << " seqfamilies[i].ms1p[0].mz_ms1=" << seqfamilies[i].ms1p[0].mz_ms1;
						cout << "    fname="<<seqfamilies[i].ms1p[0].rawfname <<endl;
						theXMLfname = ffolder; theXMLfname += seqfamilies[i].ms1p[0].rawfname;
						theXMLfname += tail;
						strcpy(XMLfname, theXMLfname.c_str()); 
						I4 = PPintegratorB(XMLfname, max_scan_num, seqfamilies[i].ms1p[0].mz_ms1, 0,0, &starting_time, &end_time, &max_R_time, &light_max_scan_num,mz_error_calibrated_peak,num_of_KK,&real_maxx_scan_num,&real_maxx_inten, &max_s_inten, 2*mass_dif_3DH, seqfamilies[i].ms1p[0].charge, Q2);

						if (I4 < 0.0001) {
							if ((I4 < -0.999) && (I4 > -1.001)){
								cout << "The peak I4 (with given scannum) was not found. LN 1020" <<endl ;
								I4 = 0.0000;
							} else if ((I4 < -1.999) && (I4 > -8.001)) {
								continue; // peak is there but cannot get the value! dump!
							}
						}
						sh[0].max_R_time = max_R_time;
						sh[0].max_s_inten= max_s_inten;
						sh[0].starting_time = starting_time;
						sh[0].end_time= end_time;

						cout << "GGGG,I4,"<<seqfamilies[i].familyseq<<"%"<<seqfamilies[i].ms1p[0].rawfname<<"%"<<seqfamilies[i].ms1p[0].charge<<","<<max_scan_num<<","<<I4<<",";
						printf("%10.5f\n", seqfamilies[i].ms1p[0].mz_ms1);
						outf01 <<    "I4,"<<seqfamilies[i].familyseq<<"%"<<seqfamilies[i].ms1p[0].rawfname<<"%"<<seqfamilies[i].ms1p[0].charge<<","<<max_scan_num<<","<<I4<<",";
						outf01 << std::fixed << std::setprecision(5) << seqfamilies[i].ms1p[0].mz_ms1 <<endl;

						cout << "Time of I4 " << starting_time <<" "<< max_R_time <<"  "<< end_time << endl;
						cout << "afterI4,    max_scan_num= " << max_scan_num <<"    light_max_scan_num= " << light_max_scan_num<< endl;
						//cal I1
						if (seqfamilies[i].ms1p[3].scannum !=-1) {
							cout << "B4 calling PPinte for I1 scannum="<<seqfamilies[i].ms1p[3].scannum << "   seqfamilies[i].ms1p[3].mz_ms1=" << seqfamilies[i].ms1p[3].mz_ms1;
							cout << "   fname="<<seqfamilies[i].ms1p[3].rawfname <<endl;
							theXMLfname = ffolder; theXMLfname += seqfamilies[i].ms1p[3].rawfname;
							theXMLfname += tail;
							strcpy(XMLfname, theXMLfname.c_str());
							I1 = PPintegratorA(XMLfname, seqfamilies[i].ms1p[3].scannum, seqfamilies[i].ms1p[3].mz_ms1, 1,1, &starting_time, &end_time, &max_R_time, &max_scan_num,mz_error_calibrating_peak,num_of_KK,&real_maxx_scan_num,&real_maxx_inten, &max_s_inten, Q1);
						} else {
							starting_time = starting_time_i2;
							end_time = end_time_i2;
							max_R_time= max_R_time_i2;
							max_scan_num= max_scan_num_i2;
							cout << "B4 calling PPinte for I1 scannum="<<seqfamilies[i].ms1p[3].scannum << "   seqfamilies[i].ms1p[3].mz_ms1=" << seqfamilies[i].ms1p[3].mz_ms1;
							//I1 = PPintegrator(XMLfname, seqfamilies[i].ms1p[3].scannum, seqfamilies[i].ms1p[3].mz_ms1, 1, &starting_time, &end_time, &max_R_time, &max_scan_num,mz_error,num_of_KK,&real_maxx_scan_num,&real_maxx_inten, &max_s_inten, &array_starting_time, &array_end_time);//heavy
							cout << "   fname="<<seqfamilies[i].ms1p[3].rawfname <<endl;
							theXMLfname = ffolder; theXMLfname += seqfamilies[i].ms1p[3].rawfname;
							theXMLfname += tail;
							strcpy(XMLfname, theXMLfname.c_str());
							I1 = PPintegratorB(XMLfname, max_scan_num, seqfamilies[i].ms1p[3].mz_ms1, 0,1, &starting_time, &end_time, &max_R_time, &light_max_scan_num,mz_error_calibrated_peak,num_of_KK,&real_maxx_scan_num,&real_maxx_inten, &max_s_inten, mass_dif_3DH, seqfamilies[i].ms1p[0].charge, Q2);
							//As Q2 was built in actively searching I2, so,... here we use mass_dif_3DH
						}
						if (I1 < 0.0001) {
							if ((I1 < -0.999) && (I1 > -1.001)){
								cout << "The peak I1 (with given scannum) was not found. LN 1468" <<endl ;
								I1 = 0.0000;
							} else if ((I1 < -1.999) && (I1 > -8.001)) {
								continue; // peak is there but cannot get the value! dump!
							}
						}
						sh[3].max_R_time = max_R_time;
						sh[3].max_s_inten= max_s_inten;
						sh[3].starting_time = starting_time;
						sh[3].end_time= end_time;
						cout << "GGGG,I1,"<<seqfamilies[i].familyseq<<"%"<<seqfamilies[i].ms1p[0].rawfname<<"%"<<seqfamilies[i].ms1p[0].charge<<","<<max_scan_num<<","<<I1<<",";
						printf("%10.5f\n", seqfamilies[i].ms1p[3].mz_ms1);
						outf01 <<    "I1,"<<seqfamilies[i].familyseq<<"%"<<seqfamilies[i].ms1p[0].rawfname<<"%"<<seqfamilies[i].ms1p[0].charge<<","<<max_scan_num<<","<<I1<<",";
						outf01 << std::fixed << std::setprecision(5) << seqfamilies[i].ms1p[3].mz_ms1 <<endl;

						cout << "Time of I1 " << starting_time <<" "<< max_R_time <<"  "<< end_time << endl;
						if (seqfamilies[i].ms1p[3].scannum !=-1) {
							cout << "afterI1,    max_scan_num= " << max_scan_num << endl;
						} else {
							cout << "afterI1,    max_scan_num= " << max_scan_num <<"    light_max_scan_num= " << light_max_scan_num<< endl;
						}

					}// end of if (negligibleI3 == true) // it was the end of if ((I3 == 0.00)||(I3 <= threshold))
					//	   } else if (seqfamilies[i].ms1p[3].MS2exist_indicator== 1) {
				} else if (seqfamilies[i].ms1p[3].scannum !=-1){
					//active cal I1
					cout << "B4 calling PPinte for I1 scannum="<<seqfamilies[i].ms1p[3].scannum << " seqfamilies[i].ms1p[3].mz_ms1=" << seqfamilies[i].ms1p[3].mz_ms1;
					cout << "    fname="<<seqfamilies[i].ms1p[3].rawfname <<endl;
					theXMLfname = ffolder; theXMLfname += seqfamilies[i].ms1p[3].rawfname;
					theXMLfname += tail;
					strcpy(XMLfname, theXMLfname.c_str());
					I1 = PPintegratorA(XMLfname, seqfamilies[i].ms1p[3].scannum, seqfamilies[i].ms1p[3].mz_ms1, 1,1, &starting_time, &end_time, &max_R_time, &max_scan_num,mz_error_calibrating_peak,num_of_KK,&real_maxx_scan_num,&real_maxx_inten, &max_s_inten, Q1);
					
					if (I1 < 0.0001) {
						if ((I1 < -0.999) && (I1 > -1.001)){
							cout << "The peak I1 (with given scannum) was not found. LN 1501" <<endl ;
							I1 = 0.0000;
						} else if ((I1 < -1.999) && (I1 > -8.001)) {
							continue; // peak is there but cannot get the value! dump!                                                                                       
						}
					}
					sh[3].max_R_time = max_R_time;
					sh[3].max_s_inten= max_s_inten;
					sh[3].starting_time = starting_time;
					sh[3].end_time= end_time;
					cout << "GGGG,I1,"<<seqfamilies[i].familyseq<<"%"<<seqfamilies[i].ms1p[0].rawfname<<"%"<<seqfamilies[i].ms1p[0].charge<<","<<max_scan_num<<","<<I1<<",";
					printf("%10.5f\n", seqfamilies[i].ms1p[3].mz_ms1);
					outf01 <<    "I1,"<<seqfamilies[i].familyseq<<"%"<<seqfamilies[i].ms1p[0].rawfname<<"%"<<seqfamilies[i].ms1p[0].charge<<","<<max_scan_num<<","<<I1<<",";
					outf01 << std::fixed << std::setprecision(5) << seqfamilies[i].ms1p[3].mz_ms1 <<endl;

					cout << "Time of I1 " << starting_time <<" "<< max_R_time <<"  "<< end_time << endl;
					cout << "afterI1,    max_scan_num= " << max_scan_num << endl;	   
					starting_time_i1 = starting_time;
					end_time_i1 = end_time;
					max_R_time_i1= max_R_time;
					max_scan_num_i1= max_scan_num;
					cout << "I2 passive" << endl; 
					light_max_scan_num =0;
					cout << "B4 calling PPinte for I2 scannum="<<seqfamilies[i].ms1p[2].scannum << " seqfamilies[i].ms1p[2].mz_ms1=" << seqfamilies[i].ms1p[2].mz_ms1;
					cout << "    fname="<<seqfamilies[i].ms1p[2].rawfname <<endl;
					theXMLfname = ffolder; theXMLfname += seqfamilies[i].ms1p[2].rawfname;
					theXMLfname += tail;
					strcpy(XMLfname, theXMLfname.c_str());
					I2 = PPintegratorB(XMLfname, max_scan_num, seqfamilies[i].ms1p[2].mz_ms1, 0,0, &starting_time, &end_time, &max_R_time, &light_max_scan_num,mz_error_calibrated_peak,num_of_KK,&real_maxx_scan_num,&real_maxx_inten, &max_s_inten, mass_dif_3DH, seqfamilies[i].ms1p[0].charge, Q1);
					
					negligibleI2 = false;
					if (I2 < 0.0001) {
						if ((I2 < -0.999) && (I2 > -1.001)){
							cout << "The peak I2 (with given scannum) was not found. LN 1165" <<endl ;
							negligibleI2 = true;
						} else if ((I2 < -1.999) && (I2 > -8.001)) {
							continue; // peak is there but cannot get the value! dump!
						}
					}
					if (negligibleI2 == false) {
						cout << "Time of I2 " << starting_time <<" "<< max_R_time <<"  "<< end_time << endl;
						cout << "afterI2 beforethres, max_scan_num= " << max_scan_num<<"   light_max_scan_num= " << light_max_scan_num <<endl;
						cout << "real_maxx_scan_num for background test is "<< real_maxx_scan_num << endl;
						threshold= 3 * noise_level(XMLfname, real_maxx_scan_num);
						cout << "threshold=" <<threshold<<"  real_maxx_inten=" << real_maxx_inten <<endl;
						if ( real_maxx_inten > threshold) {
							cout << "I2 apex larger than background noise but sequence is not in MS2 dictionary. dump." << endl;
							continue;
						} else {
							negligibleI2 = true;
						}
					}
					sh[2].max_R_time = max_R_time;
					sh[2].max_s_inten= max_s_inten;
					sh[2].starting_time = starting_time;
					sh[2].end_time= end_time;

					if (negligibleI2 == true) {
						I2=0.000000; //alphaL_frac[0]=0.000; betaL_frac[0] =0.000;
						cout << "GGGG,I2,"<<seqfamilies[i].familyseq<<"%"<<seqfamilies[i].ms1p[0].rawfname<<"%"<<seqfamilies[i].ms1p[0].charge<<","<<max_scan_num<<","<<I2<<",";
						printf("%10.5f\n", seqfamilies[i].ms1p[2].mz_ms1);
						outf01 <<    "I2,"<<seqfamilies[i].familyseq<<"%"<<seqfamilies[i].ms1p[0].rawfname<<"%"<<seqfamilies[i].ms1p[0].charge<<","<<max_scan_num<<","<<I2<<",";
						outf01 << std::fixed << std::setprecision(5) << seqfamilies[i].ms1p[2].mz_ms1 <<endl;
						cout <<"I3 passive" << endl;
						starting_time = starting_time_i1;
						end_time = end_time_i1;
						max_R_time= max_R_time_i1;
						max_scan_num= max_scan_num_i1;
						light_max_scan_num=0;
						cout << "B4 calling PPinte for I3 scannum="<<seqfamilies[i].ms1p[1].scannum << " seqfamilies[i].ms1p[1].mz_ms1=" << seqfamilies[i].ms1p[1].mz_ms1 << endl;
						cout << "    fname="<<seqfamilies[i].ms1p[1].rawfname <<endl;
						theXMLfname = ffolder; theXMLfname += seqfamilies[i].ms1p[1].rawfname;
						theXMLfname += tail;
						strcpy(XMLfname, theXMLfname.c_str());	     
						I3 = PPintegratorB(XMLfname, max_scan_num, seqfamilies[i].ms1p[1].mz_ms1, 0,0, &starting_time, &end_time, &max_R_time, &light_max_scan_num,mz_error_calibrated_peak,num_of_KK,&real_maxx_scan_num,&real_maxx_inten, &max_s_inten, 2*mass_dif_3DH, seqfamilies[i].ms1p[0].charge, Q1);

						negligibleI3 = false;
						if (I3 < 0.0001) {
							if ((I3 < -0.999) && (I3 > -1.001)){
								cout << "The peak I3 (with given scannum) was not found. LN 1202" <<endl ;
								negligibleI3 = true;
							} else if ((I3 < -1.999) && (I3 > -8.001)) {
								continue; // peak is there but cannot get the value! dump!                                                                                                     
							}
						}
						if (negligibleI3 == false) {
							cout << "Time of I3 " << starting_time <<" "<< max_R_time <<"  "<< end_time << endl;
							cout << "afterI3 beforethres, max_scan_num= " << max_scan_num<<"   light_max_scan_num= " << light_max_scan_num <<endl;
							cout << "real_maxx_scan_num for background test is "<< real_maxx_scan_num << endl;
							threshold= 3 * noise_level(XMLfname, real_maxx_scan_num);
							cout << "threshold=" <<threshold<<"  real_maxx_inten=" << real_maxx_inten <<endl;
							if ( real_maxx_inten > threshold) {
								cout << "I3 apex larger than background noise but sequence is not in MS2 dictionary. dump." << endl;
								continue;
							} else {
								negligibleI3 = true;
							}
						}
						sh[1].max_R_time = max_R_time;
						sh[1].max_s_inten= max_s_inten;
						sh[1].starting_time = starting_time;
						sh[1].end_time= end_time;

						if (negligibleI3 == true) {
							I3=0.000000;
							cout << "GGGG,I3,"<<seqfamilies[i].familyseq<<"%"<<seqfamilies[i].ms1p[0].rawfname<<"%"<<seqfamilies[i].ms1p[0].charge<<","<<max_scan_num<<","<<I3<<",";
							printf("%10.5f\n", seqfamilies[i].ms1p[1].mz_ms1);
							outf01 <<    "I3,"<<seqfamilies[i].familyseq<<"%"<<seqfamilies[i].ms1p[0].rawfname<<"%"<<seqfamilies[i].ms1p[0].charge<<","<<max_scan_num<<","<<I3<<",";
							outf01 << std::fixed << std::setprecision(5) << seqfamilies[i].ms1p[1].mz_ms1 <<endl;
							cout <<"I4 passive" << endl;
							starting_time = starting_time_i1;
							end_time = end_time_i1;
							max_R_time= max_R_time_i1;
							max_scan_num= max_scan_num_i1;
							light_max_scan_num=0;
							cout << "B4 calling PPinte for I4 scannum="<<seqfamilies[i].ms1p[0].scannum << "   seqfamilies[i].ms1p[0].mz_ms1=" << seqfamilies[i].ms1p[0].mz_ms1 << endl;
							cout << "    fname="<<seqfamilies[i].ms1p[0].rawfname <<endl;
							theXMLfname = ffolder; theXMLfname += seqfamilies[i].ms1p[0].rawfname;
							theXMLfname += tail;
							strcpy(XMLfname, theXMLfname.c_str());
							I4 = PPintegratorB(XMLfname, max_scan_num, seqfamilies[i].ms1p[0].mz_ms1, 0,0, &starting_time, &end_time, &max_R_time, &light_max_scan_num,mz_error_calibrated_peak,num_of_KK,&real_maxx_scan_num,&real_maxx_inten, &max_s_inten, 3*mass_dif_3DH, seqfamilies[i].ms1p[0].charge, Q1);

							if (I4 < 0.0001) {
								if ((I4 < -0.999) && (I4 > -1.001)){
									cout << "The peak I4 (with given scannum) was not found. LN 1238" <<endl ;
									I4 = 0.0000;
								} else if ((I4 < -1.999) && (I4 > -8.001)) {
									continue; // peak is there but cannot get the value! dump!                                                                                               
								}
							}
							sh[0].max_R_time = max_R_time;
							sh[0].max_s_inten= max_s_inten;
							sh[0].starting_time = starting_time;
							sh[0].end_time= end_time;
							cout << "GGGG,I4,"<<seqfamilies[i].familyseq<<"%"<<seqfamilies[i].ms1p[0].rawfname<<"%"<<seqfamilies[i].ms1p[0].charge<<","<<max_scan_num<<","<<I4<<",";
							printf("%10.5f\n", seqfamilies[i].ms1p[0].mz_ms1);
							outf01 <<    "I4,"<<seqfamilies[i].familyseq<<"%"<<seqfamilies[i].ms1p[0].rawfname<<"%"<<seqfamilies[i].ms1p[0].charge<<","<<max_scan_num<<","<<I4<<",";
							outf01 << std::fixed << std::setprecision(5) << seqfamilies[i].ms1p[0].mz_ms1 <<endl;
							cout << "Time of I4 " << starting_time <<" "<< max_R_time <<"  "<< end_time << endl;
							cout << "afterI4, max_scan_num= " << max_scan_num<<"   light_max_scan_num= " << light_max_scan_num <<endl;
						}//if (negligibleI3 == true)      
					}
				} else { // end of else if (seqfamilies[i].ms1p[3].scannum != 1)
					continue; //(0,0,0,0) impossible case
				}
			} //end of if ((seqfamilies[i].ms1p[1].MS2exist_indicator== 0) && (seqfamilies[i].ms1p[1].scannum ==-1 ))  

			//HALF of 3K
			if ((seqfamilies[i].ms1p[1].MS2exist_indicator== 1) && (seqfamilies[i].ms1p[1].scannum !=-1 )) {
				//active cal I3
				cout << "B4 calling PPinte for I3 scannum="<<seqfamilies[i].ms1p[1].scannum << "   seqfamilies[i].ms1p[1].mz_ms1=" << seqfamilies[i].ms1p[1].mz_ms1 << endl;
				cout <<" fname="<<seqfamilies[i].ms1p[1].rawfname <<endl;
				theXMLfname = ffolder; theXMLfname += seqfamilies[i].ms1p[1].rawfname;
				theXMLfname += tail;
				strcpy(XMLfname, theXMLfname.c_str());
				I3 =PPintegratorA(XMLfname, seqfamilies[i].ms1p[1].scannum, seqfamilies[i].ms1p[1].mz_ms1, 1,1, &starting_time, &end_time, &max_R_time, &max_scan_num,mz_error_calibrating_peak,num_of_KK,&real_maxx_scan_num,&real_maxx_inten, &max_s_inten, Q3);

				if (I3 < 0.0001) {
					if ((I3 < -0.999) && (I3 > -1.001)){
						cout << "The peak I3 (with given scannum) was not found. LN 1653" <<endl ;
						I3 = 0.0000;
					} else if ((I3 < -1.999) && (I3 > -8.001)) {
						continue; // peak is there but cannot get the value! dump!
					}
				}
				sh[1].max_R_time = max_R_time;
				sh[1].max_s_inten= max_s_inten;
				sh[1].starting_time = starting_time;
				sh[1].end_time= end_time;
				cout << "GGGG,I3,"<<seqfamilies[i].familyseq<<"%"<<seqfamilies[i].ms1p[0].rawfname<<"%"<<seqfamilies[i].ms1p[0].charge<<","<<max_scan_num<<","<<I3<<",";
				printf("%10.5f\n", seqfamilies[i].ms1p[1].mz_ms1);
				outf01 <<    "I3,"<<seqfamilies[i].familyseq<<"%"<<seqfamilies[i].ms1p[0].rawfname<<"%"<<seqfamilies[i].ms1p[0].charge<<","<<max_scan_num<<","<<I3<<",";
				outf01 << std::fixed << std::setprecision(5) << seqfamilies[i].ms1p[1].mz_ms1 <<endl;

				cout << "Time of I3 " << starting_time <<" "<< max_R_time <<"  "<< end_time << endl;
				cout << "afterI3 beforethres, max_scan_num= " << max_scan_num<<"   light_max_scan_num= " << light_max_scan_num <<endl;
				starting_time = starting_time_i3;
				end_time = end_time_i3;
				max_R_time= max_R_time_i3;
				max_scan_num= max_scan_num_i3;	
				//active and passive cal I4
				if (seqfamilies[i].ms1p[0].scannum !=-1) {
					cout << "B4 calling PPinte for I4 scannum="<<seqfamilies[i].ms1p[0].scannum << " seqfamilies[i].ms1p[0].mz_ms1=" << seqfamilies[i].ms1p[0].mz_ms1 << endl;
					cout <<" fname="<<seqfamilies[i].ms1p[0].rawfname <<endl;
					theXMLfname = ffolder; theXMLfname += seqfamilies[i].ms1p[0].rawfname;
					theXMLfname += tail;
					strcpy(XMLfname, theXMLfname.c_str());
					I4 = PPintegratorA(XMLfname, seqfamilies[i].ms1p[0].scannum, seqfamilies[i].ms1p[0].mz_ms1, 1,1,&starting_time, &end_time, &max_R_time, &max_scan_num,mz_error_calibrating_peak,num_of_KK,&real_maxx_scan_num,&real_maxx_inten, &max_s_inten, Q4); 
				} else {
					light_max_scan_num=0;
					cout << "B4 calling PPinte for I4 scannum="<<seqfamilies[i].ms1p[0].scannum << " seqfamilies[i].ms1p[0].mz_ms1=" << seqfamilies[i].ms1p[0].mz_ms1 << endl;
					cout <<" fname="<<seqfamilies[i].ms1p[0].rawfname <<endl;
					theXMLfname = ffolder; theXMLfname += seqfamilies[i].ms1p[0].rawfname;
					theXMLfname += tail;
					strcpy(XMLfname, theXMLfname.c_str());
					I4 = PPintegratorB(XMLfname, max_scan_num, seqfamilies[i].ms1p[0].mz_ms1, 0,0, &starting_time, &end_time, &max_R_time, &light_max_scan_num,mz_error_calibrated_peak,num_of_KK,&real_maxx_scan_num,&real_maxx_inten, &max_s_inten, mass_dif_3DH, seqfamilies[i].ms1p[0].charge, Q3);
				}
				if (I4 < 0.0001) {
					if ((I4 < -0.999) && (I4 > -1.001)){
						cout << "The peak I4 (with given scannum) was not found. LN 1300" <<endl ;
						I4 = 0.0000;
					} else if ((I4 < -1.999) && (I4 > -8.001)) {
						continue; // peak is there but cannot get the value! dump!
					}
				}
				sh[0].max_R_time = max_R_time;
				sh[0].max_s_inten= max_s_inten;
				sh[0].starting_time = starting_time;
				sh[0].end_time= end_time;
				if (seqfamilies[i].ms1p[0].scannum !=-1) {
					cout << "GGGG,I4,"<<seqfamilies[i].familyseq<<"%"<<seqfamilies[i].ms1p[0].rawfname<<"%"<<seqfamilies[i].ms1p[0].charge<<","<<max_scan_num<<","<<I4<<",";
					printf("%10.5f\n", seqfamilies[i].ms1p[0].mz_ms1);
					outf01 <<    "I4,"<<seqfamilies[i].familyseq<<"%"<<seqfamilies[i].ms1p[0].rawfname<<"%"<<seqfamilies[i].ms1p[0].charge<<","<<max_scan_num<<","<<I4<<",";
					outf01 << std::fixed << std::setprecision(5) << seqfamilies[i].ms1p[0].mz_ms1 <<endl;
					cout << "Time of I4 " << starting_time <<" "<< max_R_time <<"  "<< end_time << endl;
					cout << "afterI4, max_scan_num= " << max_scan_num<<endl;
				} else {
					cout << "GGGG,I4,"<<seqfamilies[i].familyseq<<"%"<<seqfamilies[i].ms1p[0].rawfname<<"%"<<seqfamilies[i].ms1p[0].charge<<","<<light_max_scan_num<<","<<I4<<",";
					printf("%10.5f\n", seqfamilies[i].ms1p[0].mz_ms1);
					outf01 <<    "I4,"<<seqfamilies[i].familyseq<<"%"<<seqfamilies[i].ms1p[0].rawfname<<"%"<<seqfamilies[i].ms1p[0].charge<<","<<light_max_scan_num<<","<<I4<<",";
					outf01 << std::fixed << std::setprecision(5) << seqfamilies[i].ms1p[0].mz_ms1 <<endl;
					cout << "Time of I4 " << starting_time <<" "<< max_R_time <<"  "<< end_time << endl;
					cout << "afterI4, max_scan_num= " << max_scan_num<<"   light_max_scan_num= " << light_max_scan_num <<endl;
				}
				
				if ((seqfamilies[i].ms1p[2].MS2exist_indicator== 1) && (seqfamilies[i].ms1p[2].scannum !=-1 )) {// (I2 ms2 ==1 && I2 ms1 ==1 ) {
					//active cal I2
					cout << "I2 active" << endl;
					cout << "B4 calling PPinte for I2 scannum="<<seqfamilies[i].ms1p[2].scannum << " seqfamilies[i].ms1p[2].mz_ms1=" << seqfamilies[i].ms1p[2].mz_ms1 << endl;
					cout <<" fname="<<seqfamilies[i].ms1p[2].rawfname <<endl;
					theXMLfname = ffolder; theXMLfname += seqfamilies[i].ms1p[2].rawfname;
					theXMLfname += tail;
					strcpy(XMLfname, theXMLfname.c_str());
					I2 = PPintegratorA(XMLfname, seqfamilies[i].ms1p[2].scannum, seqfamilies[i].ms1p[2].mz_ms1, 1,1, &starting_time, &end_time, &max_R_time, &max_scan_num,mz_error_calibrating_peak,num_of_KK,&real_maxx_scan_num,&real_maxx_inten, &max_s_inten, Q2);

					if (I2 < 0.0001) {
						if ((I2 < -0.999) && (I2 > -1.001)){
							cout << "The peak I2 (with given scannum) was not found. LN 1827" <<endl;
							I2 = 0.0000;
						} else if ((I2 < -1.999) && (I2 > -8.001)) {
							continue; // peak is there but cannot get the value! dump!
						}
					}
					sh[2].max_R_time = max_R_time;
					sh[2].max_s_inten= max_s_inten;
					sh[2].starting_time = starting_time;
					sh[2].end_time= end_time;

					cout << "GGGG,I2,"<<seqfamilies[i].familyseq<<"%"<<seqfamilies[i].ms1p[0].rawfname<<"%"<<seqfamilies[i].ms1p[0].charge<<","<<max_scan_num<<","<<I2<<",";
					printf("%10.5f\n", seqfamilies[i].ms1p[2].mz_ms1);
					outf01 <<    "I2,"<<seqfamilies[i].familyseq<<"%"<<seqfamilies[i].ms1p[0].rawfname<<"%"<<seqfamilies[i].ms1p[0].charge<<","<<max_scan_num<<","<<I2<<",";
					outf01 << std::fixed << std::setprecision(5) << seqfamilies[i].ms1p[2].mz_ms1 <<endl;

					cout << "Time of I2 " << starting_time <<" "<< max_R_time <<"  "<< end_time << endl;
					cout << "afterI2, max_scan_num= " << max_scan_num<<endl;
					//active and passive cal I1
					if (seqfamilies[i].ms1p[3].scannum !=-1) {
						cout << "I1 active" << endl;
						cout << "B4 calling PPinte for I1 scannum="<<seqfamilies[i].ms1p[3].scannum << " seqfamilies[i].ms1p[3].mz_ms1=" << seqfamilies[i].ms1p[3].mz_ms1 << endl;
						cout <<" fname="<<seqfamilies[i].ms1p[3].rawfname <<endl;
						theXMLfname = ffolder; theXMLfname += seqfamilies[i].ms1p[3].rawfname;
						theXMLfname += tail;
						strcpy(XMLfname, theXMLfname.c_str());	    
						I1 = PPintegratorA(XMLfname, seqfamilies[i].ms1p[3].scannum, seqfamilies[i].ms1p[3].mz_ms1, 1,1, &starting_time, &end_time, &max_R_time, &max_scan_num,mz_error_calibrating_peak,num_of_KK,&real_maxx_scan_num,&real_maxx_inten, &max_s_inten, Q1);

						if (I1 < 0.0001) {
							if ((I1 < -0.999) && (I1 > -1.001)){
								cout << "The peak I1 (with given scannum) was not found. LN 1862" <<endl ;
								I1 = 0.0000;
							} else if ((I1 < -1.999) && (I1 > -8.001)) {
								continue; // peak is there but cannot get the value! dump!
							}
						}
						sh[3].max_R_time = max_R_time;
						sh[3].max_s_inten= max_s_inten;
						sh[3].starting_time = starting_time;
						sh[3].end_time= end_time;
						cout << "GGGG,I1,"<<seqfamilies[i].familyseq<<"%"<<seqfamilies[i].ms1p[0].rawfname<<"%"<<seqfamilies[i].ms1p[0].charge<<","<<max_scan_num<<","<<I1<<",";
						printf("%10.5f\n", seqfamilies[i].ms1p[3].mz_ms1);
						outf01 <<    "I1,"<<seqfamilies[i].familyseq<<"%"<<seqfamilies[i].ms1p[0].rawfname<<"%"<<seqfamilies[i].ms1p[0].charge<<","<<max_scan_num<<","<<I1<<",";
						outf01 << std::fixed << std::setprecision(5) << seqfamilies[i].ms1p[3].mz_ms1 <<endl;
						cout << "Time of I1 " << starting_time <<" "<< max_R_time <<"  "<< end_time << endl;
						cout << "afterI1, max_scan_num= " << max_scan_num<<endl;
					} else {
						cout << "I1 passive" << endl;
						// If peak I3 is more than twice of peak I2, then Use peak I3 as reference for I1 finding (need to reset parameters, such as 
						// 1. Q3 as the last arguement of PPintegr*rB(), 2. max_scan_num= max_scan_num_i3); 
						// Otherwise, use peak I2,... that means no need to reset parameter got in previous step(active I2 finding).   
						if (I3 > (2*I2)) { 
							starting_time = starting_time_i3;
							end_time = end_time_i3;
							max_R_time= max_R_time_i3;
							max_scan_num= max_scan_num_i3;
							cout << "using I3 result to set up I1's time limits or calibrate I1" <<endl;
							light_max_scan_num =0;
							cout << "B4 calling PPinte for I1 scannum="<<seqfamilies[i].ms1p[3].scannum << " seqfamilies[i].ms1p[3].mz_ms1=" << seqfamilies[i].ms1p[3].mz_ms1;
							cout << "    fname="<<seqfamilies[i].ms1p[3].rawfname <<endl;
							theXMLfname = ffolder; theXMLfname += seqfamilies[i].ms1p[3].rawfname;
							theXMLfname += tail;
							strcpy(XMLfname, theXMLfname.c_str());
							I1 = PPintegratorB(XMLfname, max_scan_num, seqfamilies[i].ms1p[3].mz_ms1, 0,1, &starting_time, &end_time, &max_R_time, &light_max_scan_num,mz_error_calibrated_peak,num_of_KK,&real_maxx_scan_num,&real_maxx_inten, &max_s_inten,2*mass_dif_3DH, seqfamilies[i].ms1p[0].charge, Q3); //use Q3 to search I1 so use 2*mass_dif_3DH
						} else {
							light_max_scan_num=0;
							cout << "B4 calling PPinte for I1 scannum="<<seqfamilies[i].ms1p[3].scannum << " seqfamilies[i].ms1p[3].mz_ms1=" << seqfamilies[i].ms1p[3].mz_ms1 << endl;
							cout <<" fname="<<seqfamilies[i].ms1p[3].rawfname <<endl;
							theXMLfname = ffolder; theXMLfname += seqfamilies[i].ms1p[3].rawfname;
							theXMLfname += tail;
							strcpy(XMLfname, theXMLfname.c_str());	    
							I1 = PPintegratorB(XMLfname, max_scan_num, seqfamilies[i].ms1p[3].mz_ms1, 0,1, &starting_time, &end_time, &max_R_time, &light_max_scan_num,mz_error_calibrated_peak,num_of_KK,&real_maxx_scan_num,&real_maxx_inten, &max_s_inten, mass_dif_3DH, seqfamilies[i].ms1p[0].charge, Q2);
						}

						if (I1 < 0.0001) {
							if ((I1 < -0.999) && (I1 > -1.001)){
								cout << "The peak I1 (with given scannum) was not found. LN 1903" <<endl ;
								I1 = 0.0000;
							} else if ((I1 < -1.999) && (I1 > -8.001)) {
								continue; // peak is there but cannot get the value! dump!
							}
						}
						sh[3].max_R_time = max_R_time;
						sh[3].max_s_inten= max_s_inten;
						sh[3].starting_time = starting_time;
						sh[3].end_time= end_time;
						cout << "GGGG,I1,"<<seqfamilies[i].familyseq<<"%"<<seqfamilies[i].ms1p[0].rawfname<<"%"<<seqfamilies[i].ms1p[0].charge<<","<<light_max_scan_num<<","<<I1<<",";
						printf("%10.5f\n", seqfamilies[i].ms1p[3].mz_ms1);
						outf01 <<    "I1,"<<seqfamilies[i].familyseq<<"%"<<seqfamilies[i].ms1p[0].rawfname<<"%"<<seqfamilies[i].ms1p[0].charge<<","<<light_max_scan_num<<","<<I1<<",";
						outf01 << std::fixed << std::setprecision(5) << seqfamilies[i].ms1p[3].mz_ms1 <<endl;
						cout << "Time of I1 " << starting_time <<" "<< max_R_time <<"  "<< end_time << endl;
						cout << "afterI1, max_scan_num= " << max_scan_num<<"   light_max_scan_num= " << light_max_scan_num <<endl;
					}

				} else { //if ((seqfamilies[i].ms1p[2].MS2exist_indicator== 1) && (seqfamilies[i].ms1p[2].scannum !=-1 )) {// (I2 ms2 ==1 && I2 ms1 ==1 ) {
					//passive cal I2
					starting_time = starting_time_i3;
					end_time = end_time_i3;
					max_R_time= max_R_time_i3;
					max_scan_num= max_scan_num_i3;
					light_max_scan_num=0;
					cout << "B4 calling PPinte for I2 scannum="<<seqfamilies[i].ms1p[2].scannum << " seqfamilies[i].ms1p[2].mz_ms1=" << seqfamilies[i].ms1p[2].mz_ms1 << endl;
					cout <<" fname="<<seqfamilies[i].ms1p[2].rawfname <<endl;
					theXMLfname = ffolder; theXMLfname += seqfamilies[i].ms1p[2].rawfname;
					theXMLfname += tail;
					strcpy(XMLfname, theXMLfname.c_str());	  
					I2 = PPintegratorB(XMLfname, max_scan_num, seqfamilies[i].ms1p[2].mz_ms1, 0,1, &starting_time, &end_time, &max_R_time, &light_max_scan_num,mz_error_calibrated_peak,num_of_KK,&real_maxx_scan_num,&real_maxx_inten, &max_s_inten, mass_dif_3DH, seqfamilies[i].ms1p[0].charge, Q3); //Q is Q3

					negligibleI2 = false;
					if (I2 < 0.0001) {
						if ((I2 < -0.999) && (I2 > -1.001)){
							cout << "The peak I2 (with given scannum) was not found. LN 1938" <<endl ;
							negligibleI2 = true;
						} else if ((I2 < -1.999) && (I2 > -8.001)) {
							continue; // peak is there but cannot get the value! dump!
						}
					}
					if (negligibleI2 == false) {
						cout << "Time of I2 " << starting_time <<" "<< max_R_time <<"  "<< end_time << endl;
						cout << "afterI2, max_scan_num= " << max_scan_num<<"   light_max_scan_num= " << light_max_scan_num <<endl;
						cout << "real_maxx_scan_num for background test is "<< real_maxx_scan_num << endl;
						threshold= 3 * noise_level(XMLfname, real_maxx_scan_num);
						cout << "threshold=" <<threshold<<"  real_maxx_inten=" << real_maxx_inten <<endl;
						if ( real_maxx_inten > threshold) {
							cout << "I2 apex larger than background noise but sequence is not in MS2 dictionary. dump." << endl;
							continue;
						} else {
							negligibleI2 = true;
						}
					}
					sh[2].max_R_time = max_R_time;
					sh[2].max_s_inten= max_s_inten;
					sh[2].starting_time = starting_time;
					sh[2].end_time= end_time;
					
					if (negligibleI2 == true) {
						I2=0.000000;
						cout << "GGGG,I2,"<<seqfamilies[i].familyseq<<"%"<<seqfamilies[i].ms1p[0].rawfname<<"%"<<seqfamilies[i].ms1p[0].charge<<","<<max_scan_num<<","<<I2<<","; //As it is negligible, max_scan_num or light_max_scan_num does not matter
						printf("%10.5f\n", seqfamilies[i].ms1p[2].mz_ms1);
						outf01 <<    "I2,"<<seqfamilies[i].familyseq<<"%"<<seqfamilies[i].ms1p[0].rawfname<<"%"<<seqfamilies[i].ms1p[0].charge<<","<<max_scan_num<<","<<I2<<",";
						outf01 << std::fixed << std::setprecision(5) << seqfamilies[i].ms1p[2].mz_ms1 <<endl;

						//cal active and passive I1
						if (seqfamilies[i].ms1p[3].scannum !=-1) {
							cout << "B4 calling PPinte for I1 scannum="<<seqfamilies[i].ms1p[3].scannum << " seqfamilies[i].ms1p[3].mz_ms1=" << seqfamilies[i].ms1p[3].mz_ms1 << endl;
							cout <<" fname="<<seqfamilies[i].ms1p[3].rawfname <<endl;
							theXMLfname = ffolder; theXMLfname += seqfamilies[i].ms1p[3].rawfname;
							theXMLfname += tail;
							strcpy(XMLfname, theXMLfname.c_str());
							I1 = PPintegratorA(XMLfname, seqfamilies[i].ms1p[3].scannum, seqfamilies[i].ms1p[3].mz_ms1, 1,1, &starting_time, &end_time, &max_R_time, &max_scan_num,mz_error_calibrating_peak,num_of_KK,&real_maxx_scan_num,&real_maxx_inten, &max_s_inten, Q1);

							if (I1 < 0.0001) {
								if ((I1 < -0.999) && (I1 > -1.001)){
									cout << "The peak I1 (with given scannum) was not found. LN 1423" <<endl ;
									I1 = 0.0000;
								} else if ((I1 < -1.999) && (I1 > -8.001)) {
									continue; // peak is there but cannot get the value! dump!
								}
							}
							sh[3].max_R_time = max_R_time;
							sh[3].max_s_inten= max_s_inten;
							sh[3].starting_time = starting_time;
							sh[3].end_time= end_time;
							cout << "GGGG,I1,"<<seqfamilies[i].familyseq<<"%"<<seqfamilies[i].ms1p[0].rawfname<<"%"<<seqfamilies[i].ms1p[0].charge<<","<<max_scan_num<<","<<I1<<",";
							printf("%10.5f\n", seqfamilies[i].ms1p[3].mz_ms1);
							outf01 <<    "I1,"<<seqfamilies[i].familyseq<<"%"<<seqfamilies[i].ms1p[0].rawfname<<"%"<<seqfamilies[i].ms1p[0].charge<<","<<max_scan_num<<","<<I1<<",";
							outf01 << std::fixed << std::setprecision(5) << seqfamilies[i].ms1p[3].mz_ms1 <<endl;

							cout << "Time of I1 " << starting_time <<" "<< max_R_time <<"  "<< end_time << endl;
							cout << "afterI1, max_scan_num= " << max_scan_num <<endl;
						} else {
							starting_time = starting_time_i3;
							end_time = end_time_i3;
							max_R_time= max_R_time_i3;
							max_scan_num= max_scan_num_i3;
							light_max_scan_num=0;
							cout << "B4 calling PPinte for I1 scannum="<<seqfamilies[i].ms1p[3].scannum << " seqfamilies[i].ms1p[3].mz_ms1=" << seqfamilies[i].ms1p[3].mz_ms1 << endl;
							cout <<" fname="<<seqfamilies[i].ms1p[3].rawfname <<endl;
							theXMLfname = ffolder; theXMLfname += seqfamilies[i].ms1p[3].rawfname;
							theXMLfname += tail;
							strcpy(XMLfname, theXMLfname.c_str());
							I1 = PPintegratorB(XMLfname, max_scan_num, seqfamilies[i].ms1p[3].mz_ms1, 0,1, &starting_time, &end_time, &max_R_time, &light_max_scan_num,mz_error_calibrated_peak,num_of_KK,&real_maxx_scan_num,&real_maxx_inten, &max_s_inten, 2*mass_dif_3DH, seqfamilies[i].ms1p[0].charge, Q3);

							if (I1 < 0.0001) {
								if ((I1 < -0.999) && (I1 > -1.001)){
									cout << "The peak I1 (with given scannum) was not found. LN 1895" <<endl ;
									I1 = 0.0000;
								} else if ((I1 < -1.999) && (I1 > -8.001)) {
									continue; // peak is there but cannot get the value! dump!
								}
							}
							sh[3].max_R_time = max_R_time;
							sh[3].max_s_inten= max_s_inten;
							sh[3].starting_time = starting_time;
							sh[3].end_time= end_time;
							cout << "GGGG,I1,"<<seqfamilies[i].familyseq<<"%"<<seqfamilies[i].ms1p[0].rawfname<<"%"<<seqfamilies[i].ms1p[0].charge<<","<<light_max_scan_num<<","<<I1<<",";
							printf("%10.5f\n", seqfamilies[i].ms1p[3].mz_ms1);
							outf01 <<    "I1,"<<seqfamilies[i].familyseq<<"%"<<seqfamilies[i].ms1p[0].rawfname<<"%"<<seqfamilies[i].ms1p[0].charge<<","<<light_max_scan_num<<","<<I1<<",";
							outf01 << std::fixed << std::setprecision(5) << seqfamilies[i].ms1p[3].mz_ms1 <<endl;
							cout << "Time of I1 " << starting_time <<" "<< max_R_time <<"  "<< end_time << endl;
							cout << "afterI1, max_scan_num= " << max_scan_num<<"   light_max_scan_num= " << light_max_scan_num <<endl;
						}	    
					}//end of if (negligible == true) 
				}// end of I2 active/passive	
			} // end of if ((seqfamilies[i].ms1p[1].MS2exist_indicator== 1) && (seqfamilies[i].ms1p[1].scannum !=-1 )) 
			
			alphaL_frac[0]=0.000;
			betaL_frac[0]=0.000;
			gammaL_frac[0]=0.000;
			alphaL_frac[1]=0.000;
			betaL_frac[1]=0.000;
			gammaL_frac[1]=0.000;
			for (j=0; j<dictionary.size(); j++) {
				if (seqfamilies[i].familyseq.compare(dictionary[j].familyseq)==0){
					if (seqfamilies[i].ms1p[2].MS2exist_indicator== 1){//I2
						for (jj=0; jj<dictionary[j].peak.size(); jj++) {
							if ( dictionary[j].peak[jj].ms1peak_order == 2 ) { //looking for I2
								//for (k=0; k<dictionary[j].peak[jj].GreekL_frac.size(); k++){
								alphaL_frac[0] = dictionary[j].peak[jj].GreekL_frac[0];
								betaL_frac[0]  = dictionary[j].peak[jj].GreekL_frac[1];
								gammaL_frac[0] = dictionary[j].peak[jj].GreekL_frac[2];
								//}
								break;
							}
						}//for jj
					}
					if (seqfamilies[i].ms1p[1].MS2exist_indicator== 1){ //I3
						for (jj=0; jj<dictionary[j].peak.size(); jj++) {
							if ( dictionary[j].peak[jj].ms1peak_order == 3 ) { //looking for I3
								//for (k=0; k<dictionary[j].peak[jj].GreekL_frac.size(); k++){
								alphaL_frac[1] = dictionary[j].peak[jj].GreekL_frac[0];
								betaL_frac[1]  = dictionary[j].peak[jj].GreekL_frac[1];
								gammaL_frac[1] = dictionary[j].peak[jj].GreekL_frac[2];
								//}
								break;
							}
						}//for jj
					}
					break;
				}// if familyseq are the same
			}//for j
			
			cout << "I1=" << I1<<"     I2="<< I2 << "     I3=" << I3 << "     I4=" << I4 << "  beta"<<endl;
			cout << "alphaL_frac[0]=" << alphaL_frac[0] << "       betaL_frac[0]=" << betaL_frac[0] << endl;
			cout << "alphaL_frac[1]=" << alphaL_frac[1] << "       betaL_frac[1]=" << betaL_frac[1] << endl;
			if (I1==-1) {I1=0.0000;}
			if (I2==-1) {I2=0.0000;}
			if (I3==-1) {I3=0.0000;}
			if (I4==-1) {I4=0.0000;}
			total_alphaL=(I1 +I2*alphaL_frac[0] +I3*alphaL_frac[1])/(I1+I2+I3+I4);
			total_betaL= (I1 +I2*betaL_frac[0]  +I3*betaL_frac[1]) /(I1+I2+I3+I4);
			total_gammaL=(I1 +I2*gammaL_frac[0] +I3*gammaL_frac[1])/(I1+I2+I3+I4);
			cout << "total_alphaL= " << total_alphaL <<"  total_betaL= " << total_betaL <<"  total_gammaL= " << total_gammaL; 
			cout << "     seqfamilies[i].familyseq=" <<seqfamilies[i].familyseq<<"   fname="<<seqfamilies[i].ms1p[0].rawfname<<endl << endl;
			outf02 << "total_alphaL= " << total_alphaL <<"  total_betaL= " << total_betaL <<"  total_gammaL= " << total_gammaL;
			outf02 << "     seqfamilies[i].familyseq=" <<seqfamilies[i].familyseq<<"   fname="<<seqfamilies[i].ms1p[0].rawfname<<endl;

			if ((total_alphaL > 0.00000) || (total_betaL > 0.00000)  || (total_gammaL > 0.00000) ) {
				if (((total_alphaL - total_betaL) < 0.00001) && ((total_alphaL - total_betaL) > -0.00001)) {
					// in the below the index of the array is consistent with code in 2K, that is the ii for II[ii]; but different from 1K which has sh[0] as light one.
					// Here sh[0] represents heavy peak.
					cout << "utal_alpha,"<<total_alphaL<<","<<total_betaL<<","<<total_gammaL<<",,"<<seqfamilies[i].familyseq<<","<<seqfamilies[i].ms1p[0].rawfname;
					cout << ",heavy,"<< sh[0].max_R_time << "," << sh[0].max_s_inten << "," << sh[0].starting_time << "," << sh[0].end_time;
					cout << ",light,"<< sh[3].max_R_time << "," << sh[3].max_s_inten << "," << sh[3].starting_time << "," << sh[3].end_time;
					cout << ",middle1,,,,middle2,,,,"<<endl<<endl;
				} else {
					cout << "utal_alpha,"<<total_alphaL<<","<<total_betaL<<","<<total_gammaL<<",,"<<seqfamilies[i].familyseq<<","<<seqfamilies[i].ms1p[0].rawfname;
					cout << ",heavy,"<< sh[0].max_R_time << "," << sh[0].max_s_inten << "," << sh[0].starting_time << "," << sh[0].end_time;
					cout << ",light,"<< sh[3].max_R_time << "," << sh[3].max_s_inten << "," << sh[3].starting_time << "," << sh[3].end_time;
					cout << ",middle1,"<< sh[1].max_R_time << "," << sh[1].max_s_inten << "," << sh[1].starting_time << "," << sh[1].end_time;
					cout << ",middle2,"<< sh[2].max_R_time << "," << sh[2].max_s_inten << "," << sh[2].starting_time << "," << sh[2].end_time <<endl<<endl;
				}
			}

		}// end of if (seqfamilies[i].num_of_K == 3) 


		if (seqfamilies[i].num_of_K == 4) {
			cout <<"4Kcase   ms1psize=" <<  seqfamilies[i].ms1p.size() << endl;
			num_of_KK =4;
			if ((seqfamilies[i].ms1p[1].MS2exist_indicator== 0) && (seqfamilies[i].ms1p[1].scannum !=-1 )) {
				cout << "middle peak I4 larger than background noise; supposed, because scannum of middle peak is given. dump." <<endl;
				continue;
			}
			if ((seqfamilies[i].ms1p[2].MS2exist_indicator== 0) && (seqfamilies[i].ms1p[2].scannum !=-1 )) {
				cout << "middle peak I3 larger than background noise; supposed, because scannum of middle peak is given. dump." <<endl;
				continue;
			}
			if ((seqfamilies[i].ms1p[3].MS2exist_indicator== 0) && (seqfamilies[i].ms1p[3].scannum !=-1 )) {
				cout << "middle peak I2 larger than background noise; supposed, because scannum of middle peak is given. dump." <<endl;
				continue;
			}

			//if (( seqfamilies[i].ms1p[1].scannum !=-1 ) &&  (seqfamilies[i].ms1p[2].scannum ==-1 )) {
			// continue;
			//}
			//if (( seqfamilies[i].ms1p[1].scannum ==-1 ) &&  (seqfamilies[i].ms1p[2].scannum !=-1 )) {
			// continue;
			//}
			if ((seqfamilies[i].ms1p[1].MS2exist_indicator== 0) && (seqfamilies[i].ms1p[1].scannum ==-1 )) { // (if_sured_mz[1] == 0)

				if (seqfamilies[i].ms1p[0].scannum !=-1){ // (if_sured_mz[0] == 1)
					cout << "B4 calling PPinte for I5 scannum="<<seqfamilies[i].ms1p[0].scannum << "   seqfamilies[i].ms1p[0].mz_ms1=" << seqfamilies[i].ms1p[0].mz_ms1;  
					cout <<" fname="<<seqfamilies[i].ms1p[0].rawfname <<endl;
					theXMLfname = ffolder; theXMLfname += seqfamilies[i].ms1p[0].rawfname;
					theXMLfname += tail;
					strcpy(XMLfname, theXMLfname.c_str());
					I5 = PPintegratorA(XMLfname, seqfamilies[i].ms1p[0].scannum, seqfamilies[i].ms1p[0].mz_ms1, 1,1,&starting_time, &end_time, &max_R_time, &max_scan_num,mz_error_calibrating_peak,num_of_KK,&real_maxx_scan_num,&real_maxx_inten, &max_s_inten, Q5);

					//print out some stuff to check
					if (I5 < 0.0001) {
						if ((I5 < -0.999) && (I5 > -1.001)){
							cout << "The peak I5 (with given scannum) was not found. LN 1562" <<endl ;
							I5 = 0.0000;
							continue;
						} else if ((I5 < -1.999) && (I5 > -8.001)) {
							continue;
						} else if ((I5 < -19.999)&& (I5 > -20.001)) {
							return 0; //cannot open the file. exit                                                                                                                                                  
						}
					}
					cout << "Time of I5 " << starting_time <<" "<< max_R_time <<"  "<< end_time << endl;
					cout << "afterI5, max_scan_num= " << max_scan_num <<endl;
					starting_time_i5 = starting_time;
					end_time_i5 = end_time;
					max_R_time_i5= max_R_time;
					max_scan_num_i5= max_scan_num;
					//###################  Good extra screening? Yes.
					if (I5 <= 0.000) {
						cout << "Oh, my code cannot find the peak I5 (with given scannum) properly." <<endl ;
						continue;
					}
					//###################
					cout << "GGGG,I5,"<<seqfamilies[i].familyseq<<"%"<<seqfamilies[i].ms1p[0].rawfname<<"%"<<seqfamilies[i].ms1p[0].charge<<","<<max_scan_num<<","<<I5<<",";
					printf("%10.5f\n", seqfamilies[i].ms1p[0].mz_ms1);

					sh[0].max_R_time = max_R_time;
					sh[0].max_s_inten= max_s_inten;
					sh[0].starting_time = starting_time;
					sh[0].end_time= end_time;
					light_max_scan_num = 0;
					cout << "passive I4" << endl;
					cout << "B4 calling PPinte for I4 scannum="<<seqfamilies[i].ms1p[1].scannum << " seqfamilies[i].ms1p[1].mz_ms1=" << seqfamilies[i].ms1p[1].mz_ms1;
					cout << "    fname="<<seqfamilies[i].ms1p[1].rawfname <<endl;
					theXMLfname = ffolder; theXMLfname += seqfamilies[i].ms1p[1].rawfname;
					theXMLfname += tail;
					strcpy(XMLfname, theXMLfname.c_str());
					I4 = PPintegratorB(XMLfname, max_scan_num, seqfamilies[i].ms1p[1].mz_ms1, 0,1, &starting_time, &end_time, &max_R_time, &light_max_scan_num,mz_error_calibrated_peak,num_of_KK,&real_maxx_scan_num,&real_maxx_inten, &max_s_inten, mass_dif_3DH, seqfamilies[i].ms1p[0].charge, Q5);

					negligibleI4 = false;
					if (I4 < 0.0001) {
						if ((I4 < -0.999) && (I4 > -1.001)) {
							cout << "The peak I4 (with given scannum) was not found. LN 845" <<endl ;
							negligibleI4 = true;
						} else if ((I4 < -1.999) && (I4 > -8.001)) {
							continue; // peak is there but cannot get the value! dump!
						}
					}
					if (negligibleI4 == false) {
						cout << "Time of I4 " << starting_time <<" "<< max_R_time <<"  "<< end_time << endl;
						cout << "afterI4, max_scan_num= " << max_scan_num<<"   light_max_scan_num= " << light_max_scan_num <<endl;
						cout << "real_maxx_scan_num for background test is "<< real_maxx_scan_num << endl;
						threshold= 3 * noise_level(XMLfname, real_maxx_scan_num);
						cout << "threshold=" <<threshold<<"  real_maxx_inten=" << real_maxx_inten <<endl;
						if (real_maxx_inten > threshold) {
							cout << "I4 apex larger than background noise but sequence is not in MS2 dictionary. dump." << endl;
							continue;
						} else {
							negligibleI4 = true;
						}
					} 
					sh[1].max_R_time = max_R_time;
					sh[1].max_s_inten= max_s_inten;
					sh[1].starting_time = starting_time;
					sh[1].end_time= end_time;

					if (negligibleI4 == true) {
						I4=0.00000; //alphaL_frac[0]=0.000; betaL_frac[0] =0.000;  ///?? CHECK with
						if (seqfamilies[i].ms1p[2].MS2exist_indicator == 0) {// if I3, ms2=0
							//passive cal I3
							cout << "I3 passive" << endl;
							starting_time = starting_time_i5;
							end_time= end_time_i5;
							max_R_time = max_R_time_i5;
							max_scan_num = max_scan_num_i5;
							light_max_scan_num =0;
							cout << "GGGG,I4,"<<seqfamilies[i].familyseq<<"%"<<seqfamilies[i].ms1p[0].rawfname<<"%"<<seqfamilies[i].ms1p[0].charge<<","<<max_scan_num<<","<<0.000<<",";
							printf("%10.5f\n", seqfamilies[i].ms1p[1].mz_ms1);

							cout << "B4 calling PPinte for I3 scannum="<<seqfamilies[i].ms1p[2].scannum << " seqfamilies[i].ms1p[2].mz_ms1=" << seqfamilies[i].ms1p[2].mz_ms1;
							cout << "    fname="<<seqfamilies[i].ms1p[2].rawfname <<endl;
							theXMLfname = ffolder; theXMLfname += seqfamilies[i].ms1p[2].rawfname;
							theXMLfname += tail;
							strcpy(XMLfname, theXMLfname.c_str());
							I3 = PPintegratorB(XMLfname, max_scan_num, seqfamilies[i].ms1p[2].mz_ms1, 0,1, &starting_time, &end_time, &max_R_time, &light_max_scan_num,mz_error_calibrated_peak,num_of_KK,&real_maxx_scan_num,&real_maxx_inten, &max_s_inten, 2*mass_dif_3DH, seqfamilies[i].ms1p[0].charge, Q5);

							negligibleI3 = false;
							if (I3 < 0.0001) {
								if ((I3 < -0.999) && (I3 > -1.001)) {
									cout << "The peak I3 (with given scannum) was not found. LN 1633" <<endl ;
									negligibleI3 = true;
								} else if ((I3 < -1.999) && (I3 > -8.001)) {
									continue; // peak is there but cannot get the value! dump!
								}
							}
							if (negligibleI3 == false) {
								cout << "Time of I3 " << starting_time <<" "<< max_R_time <<"  "<< end_time << endl;
								cout << "afterI3, max_scan_num= " << max_scan_num<<"   light_max_scan_num= " << light_max_scan_num <<endl;
								cout << "real_maxx_scan_num for background test is "<< real_maxx_scan_num << endl;
								threshold= 3 * noise_level(XMLfname, real_maxx_scan_num);
								cout << "threshold=" <<threshold<<"  real_maxx_inten=" << real_maxx_inten <<endl;
								if (real_maxx_inten > threshold) {
									cout << "I3 apex larger than background noise but sequence is not in MS2 dictionary. dump." << endl;
									continue;
								} else {
									negligibleI3 = true;
								}
							}
							sh[2].max_R_time = max_R_time;
							sh[2].max_s_inten= max_s_inten;
							sh[2].starting_time = starting_time;
							sh[2].end_time= end_time;

							if (negligibleI3 == true) {
								I3=0.00000; //alphaL_frac[0]=0.000; betaL_frac[0] =0.000;  ///?? CHECK with
								if (seqfamilies[i].ms1p[3].MS2exist_indicator == 0) {
									//passive cal I2
									cout << "I2 passive" << endl;
									starting_time = starting_time_i5;
									end_time= end_time_i5;
									max_R_time = max_R_time_i5;
									max_scan_num = max_scan_num_i5;
									light_max_scan_num =0;
									cout << "GGGG,I3,"<<seqfamilies[i].familyseq<<"%"<<seqfamilies[i].ms1p[0].rawfname<<"%"<<seqfamilies[i].ms1p[0].charge<<","<<light_max_scan_num<<","<<0.000<<",";
									printf("%10.5f\n", seqfamilies[i].ms1p[2].mz_ms1);

									cout << "B4 calling PPinte for I2 scannum="<<seqfamilies[i].ms1p[3].scannum << " seqfamilies[i].ms1p[3].mz_ms1=" << seqfamilies[i].ms1p[3].mz_ms1;
									cout << "    fname="<<seqfamilies[i].ms1p[3].rawfname <<endl;
									theXMLfname = ffolder; theXMLfname += seqfamilies[i].ms1p[3].rawfname;
									theXMLfname += tail;
									strcpy(XMLfname, theXMLfname.c_str());
									I2 = PPintegratorB(XMLfname, max_scan_num, seqfamilies[i].ms1p[3].mz_ms1, 0,1, &starting_time, &end_time, &max_R_time, &light_max_scan_num,mz_error_calibrated_peak,num_of_KK,&real_maxx_scan_num,&real_maxx_inten, &max_s_inten, 3*mass_dif_3DH, seqfamilies[i].ms1p[0].charge, Q5); 

									negligibleI2 = false;
									if (I2 < 0.0001) {
										if ((I2 < -0.999) && (I2 > -1.001)) {
											cout << "The peak I2 (with given scannum) was not found. LN 1674" <<endl ;
											negligibleI2 = true;
										} else if ((I2 < -1.999) && (I2 > -8.001)) {
											continue; // peak is there but cannot get the value! dump!
										}
									}
									

									if (negligibleI2 == false) {
										cout << "Time of I2 " << starting_time <<" "<< max_R_time <<"  "<< end_time << endl;
										cout << "afterI2,    max_scan_num= " << max_scan_num <<"   light_max_scan_num= " << light_max_scan_num << endl;
										cout << "real_maxx_scan_num for background test is "<< real_maxx_scan_num << endl;
										threshold= 3 * noise_level(XMLfname, real_maxx_scan_num);
										cout << "threshold=" <<threshold<<"  real_maxx_inten=" << real_maxx_inten <<endl;
										if (real_maxx_inten > threshold) {
											cout << "I2 apex larger than background noise but sequence is not in MS2 dictionary. dump." << endl;
											continue;
										} else {
											negligibleI2 = true;
										}
									}
									sh[3].max_R_time = max_R_time;
									sh[3].max_s_inten= max_s_inten;
									sh[3].starting_time = starting_time;
									sh[3].end_time= end_time;

									if (negligibleI2 == true) {//if ( (I2 == 0.00) || (I2 <= threshold) ) {
										I2 = 0.000000;
										cout << "GGGG,I2,"<<seqfamilies[i].familyseq<<"%"<<seqfamilies[i].ms1p[0].rawfname<<"%"<<seqfamilies[i].ms1p[0].charge<<","<<light_max_scan_num<<","<<0.000<<",";
										printf("%10.5f\n", seqfamilies[i].ms1p[3].mz_ms1);

										//cal I1
										if (seqfamilies[i].ms1p[4].scannum !=-1) {
											cout << "I1 active" << endl;
											cout << "B4 calling PPinte for I1 scannum="<<seqfamilies[i].ms1p[4].scannum << " seqfamilies[i].ms1p[4].mz_ms1=" << seqfamilies[i].ms1p[4].mz_ms1;
											cout << "   fname="<<seqfamilies[i].ms1p[4].rawfname <<endl;
											theXMLfname = ffolder; theXMLfname += seqfamilies[i].ms1p[4].rawfname;
											theXMLfname += tail;
											strcpy(XMLfname, theXMLfname.c_str());
											I1 = PPintegratorA(XMLfname, seqfamilies[i].ms1p[4].scannum, seqfamilies[i].ms1p[4].mz_ms1, 1,1,&starting_time, &end_time, &max_R_time, &max_scan_num,mz_error_calibrating_peak,num_of_KK,&real_maxx_scan_num,&real_maxx_inten, &max_s_inten, Q1);

										} else {
											cout << "I1 passive" << endl;
											starting_time = starting_time_i5;
											end_time= end_time_i5;
											max_R_time = max_R_time_i5;
											max_scan_num = max_scan_num_i5;
											light_max_scan_num =0;
											cout << "B4 calling PPinte for I1 scannum="<<seqfamilies[i].ms1p[4].scannum << " seqfamilies[i].ms1p[4].mz_ms1=" << seqfamilies[i].ms1p[4].mz_ms1;
											cout << "    fname="<<seqfamilies[i].ms1p[4].rawfname <<endl;
											theXMLfname = ffolder; theXMLfname += seqfamilies[i].ms1p[4].rawfname;
											theXMLfname += tail;
											strcpy(XMLfname, theXMLfname.c_str());
											I1 = PPintegratorB(XMLfname, max_scan_num, seqfamilies[i].ms1p[4].mz_ms1, 0,1, &starting_time, &end_time, &max_R_time, &light_max_scan_num,mz_error_calibrated_peak,num_of_KK,&real_maxx_scan_num,&real_maxx_inten, &max_s_inten, 4*mass_dif_3DH, seqfamilies[i].ms1p[0].charge, Q5);

										}
										if (I1 < 0.0001) {
											if ((I1 < -0.999) && (I1 > -1.001)){
												cout << "The peak I1 (with given scannum) was not found. LN 1724" <<endl ;
												I1 = 0.000000;
											} else if ((I1 < -1.999) && (I1 > -8.001)) {
												continue;
											}
										}
										sh[4].max_R_time = max_R_time;
										sh[4].max_s_inten= max_s_inten;
										sh[4].starting_time = starting_time;
										sh[4].end_time= end_time;
										if (seqfamilies[i].ms1p[4].scannum !=-1) {
											cout << "GGGG,I1,"<<seqfamilies[i].familyseq<<"%"<<seqfamilies[i].ms1p[0].rawfname<<"%"<<seqfamilies[i].ms1p[0].charge<<","<<max_scan_num<<","<<I1<<",";
											printf("%10.5f\n", seqfamilies[i].ms1p[4].mz_ms1);
										} else {
											cout << "GGGG,I1,"<<seqfamilies[i].familyseq<<"%"<<seqfamilies[i].ms1p[0].rawfname<<"%"<<seqfamilies[i].ms1p[0].charge<<","<<light_max_scan_num<<","<<I1<<",";
											printf("%10.5f\n", seqfamilies[i].ms1p[4].mz_ms1);
										}
										cout << "Time of I1 " << starting_time <<" "<< max_R_time <<"  "<< end_time << endl;
										if (seqfamilies[i].ms1p[4].scannum !=-1) {
											cout << "afterI1,    max_scan_num= " << max_scan_num << endl;
										} else {
											cout << "afterI1,    max_scan_num= " << max_scan_num <<"    light_max_scan_num= " << light_max_scan_num<< endl;
										}
									}//end of if (negligibleI2 == true)
								} else { //active cal I2, then I1 //assume: if it is in dictionary, it should be given scannum.
									if (seqfamilies[i].ms1p[3].scannum ==-1) { cout << "WRONG ASSUMPTION HERE.YOU SHOULD CORRECT YOU CODE.";
										cout << "You need to consider case in which scannum is not given for I2 LN 1737-1800" << endl; return 0;
									}
									cout << "I2 active" << endl;
									cout << "B4 calling PPinte for I2 scannum="<< seqfamilies[i].ms1p[3].scannum << " seqfamilies[i].ms1p[3].mz_ms1=" << seqfamilies[i].ms1p[3].mz_ms1;
									cout << "    fname="<<seqfamilies[i].ms1p[3].rawfname <<endl;
									theXMLfname = ffolder; theXMLfname += seqfamilies[i].ms1p[3].rawfname;
									theXMLfname += tail;
									strcpy(XMLfname, theXMLfname.c_str());
									I2 = PPintegratorA(XMLfname, seqfamilies[i].ms1p[3].scannum, seqfamilies[i].ms1p[3].mz_ms1, 1,1,&starting_time, &end_time, &max_R_time, &max_scan_num,mz_error_calibrating_peak,num_of_KK,&real_maxx_scan_num,&real_maxx_inten, &max_s_inten, Q2);

									if (I2 < 0.0001) {
										if ((I2 < -0.999) && (I2 > -1.001)){
											cout << "The peak I2 (with given scannum) was not found. LN 1749" <<endl ;
											I2 = 0.0000;
										} else if ((I2 < -1.999) && (I2 > -8.001)) {
											continue; // peak is there but cannot get the value! dump!
										}
									}
									sh[3].max_R_time = max_R_time;
									sh[3].max_s_inten= max_s_inten;
									sh[3].starting_time = starting_time;
									sh[3].end_time= end_time;
									cout << "GGGG,I2,"<<seqfamilies[i].familyseq<<"%"<<seqfamilies[i].ms1p[0].rawfname<<"%"<<seqfamilies[i].ms1p[0].charge<<","<<max_scan_num<<","<<I2<<",";
									printf("%10.5f\n", seqfamilies[i].ms1p[3].mz_ms1);
									cout << "Time of I2 " << starting_time <<" "<< max_R_time <<"  "<< end_time << endl;
									cout << "afterI2,    max_scan_num= " << max_scan_num << endl;
									if (seqfamilies[i].ms1p[4].scannum !=-1) {
										cout << "I1 active" << endl;
										cout << "B4 calling PPinte for I1 scannum="<<seqfamilies[i].ms1p[4].scannum << " seqfamilies[i].ms1p[4].mz_ms1=" << seqfamilies[i].ms1p[4].mz_ms1;
										cout << "   fname="<<seqfamilies[i].ms1p[4].rawfname <<endl;
										theXMLfname = ffolder; theXMLfname += seqfamilies[i].ms1p[4].rawfname;
										theXMLfname += tail;
										strcpy(XMLfname, theXMLfname.c_str());
										I1 = PPintegratorA(XMLfname, seqfamilies[i].ms1p[4].scannum, seqfamilies[i].ms1p[4].mz_ms1, 1,1,&starting_time, &end_time, &max_R_time, &max_scan_num,mz_error_calibrating_peak,num_of_KK,&real_maxx_scan_num,&real_maxx_inten, &max_s_inten, Q1);

									} else {
										cout << "I1 passive" << endl;
										cout << "B4 calling PPinte for I1 scannum="<<seqfamilies[i].ms1p[4].scannum << " seqfamilies[i].ms1p[4].mz_ms1=" << seqfamilies[i].ms1p[4].mz_ms1;
										cout << "    fname="<<seqfamilies[i].ms1p[4].rawfname <<endl;
										theXMLfname = ffolder; theXMLfname += seqfamilies[i].ms1p[4].rawfname;
										theXMLfname += tail;
										strcpy(XMLfname, theXMLfname.c_str());

										if ( I5 > (2*I2) ) {
											starting_time = starting_time_i5;
											end_time= end_time_i5;
											max_R_time = max_R_time_i5;
											max_scan_num = max_scan_num_i5;
											cout << "using I5 result to set up I1's time limits" <<endl;
											light_max_scan_num =0;
											I1 = PPintegratorB(XMLfname, max_scan_num, seqfamilies[i].ms1p[4].mz_ms1, 0,1, &starting_time, &end_time, &max_R_time, &light_max_scan_num,mz_error_calibrated_peak,num_of_KK,&real_maxx_scan_num,&real_maxx_inten, &max_s_inten, 4*mass_dif_3DH, seqfamilies[i].ms1p[0].charge, Q5);
										} else {
											cout << "using I2 result to set up I1's time limits" <<endl;
											light_max_scan_num =0;
											I1 = PPintegratorB(XMLfname, max_scan_num, seqfamilies[i].ms1p[4].mz_ms1, 0,1, &starting_time, &end_time, &max_R_time, &light_max_scan_num,mz_error_calibrated_peak,num_of_KK,&real_maxx_scan_num,&real_maxx_inten, &max_s_inten, mass_dif_3DH, seqfamilies[i].ms1p[0].charge, Q2);
										}
									}
									if (I1 < 0.0001) {
										if ((I1 < -0.999) && (I1 > -1.001)){
											cout << "The peak I1 (with given scannum) was not found. LN 1781" <<endl ;
											I1 = 0.000000;
										} else if ((I1 < -1.999) && (I1 > -8.001)) {
											continue;
										}
									}
									sh[4].max_R_time = max_R_time;
									sh[4].max_s_inten= max_s_inten;
									sh[4].starting_time = starting_time;
									sh[4].end_time= end_time;			
									if (seqfamilies[i].ms1p[4].scannum !=-1) {
										cout << "GGGG,I1,"<<seqfamilies[i].familyseq<<"%"<<seqfamilies[i].ms1p[0].rawfname<<"%"<<seqfamilies[i].ms1p[0].charge<<","<<max_scan_num<<","<<I1<<",";
										printf("%10.5f\n", seqfamilies[i].ms1p[4].mz_ms1);
									} else {
										cout << "GGGG,I1,"<<seqfamilies[i].familyseq<<"%"<<seqfamilies[i].ms1p[0].rawfname<<"%"<<seqfamilies[i].ms1p[0].charge<<","<<light_max_scan_num<<","<<I1<<",";
										printf("%10.5f\n", seqfamilies[i].ms1p[4].mz_ms1);
									}
									cout << "Time of I1 " << starting_time <<" "<< max_R_time <<"  "<< end_time << endl;
									if (seqfamilies[i].ms1p[4].scannum !=-1) {
										cout << "afterI1,    max_scan_num= " << max_scan_num << endl;
									} else {
										cout << "afterI1,    max_scan_num= " << max_scan_num <<"    light_max_scan_num= " << light_max_scan_num<< endl;
									}
								}// match LN1735 if (I2 ms2 ==0){} else {
							} // if (negligibleI3 == true)
						} else { //if (I3 ms2 ==0){
							cout << "I3 active" << endl;
							cout << "B4 calling PPinte for I3 scannum="<<seqfamilies[i].ms1p[2].scannum << " seqfamilies[i].ms1p[2].mz_ms1=" << seqfamilies[i].ms1p[2].mz_ms1;
							cout << "   fname="<<seqfamilies[i].ms1p[2].rawfname <<endl;
							theXMLfname = ffolder; theXMLfname += seqfamilies[i].ms1p[2].rawfname;
							theXMLfname += tail;
							strcpy(XMLfname, theXMLfname.c_str());
							I3 = PPintegratorA(XMLfname, seqfamilies[i].ms1p[2].scannum, seqfamilies[i].ms1p[2].mz_ms1, 1,1,&starting_time, &end_time, &max_R_time, &max_scan_num,mz_error_calibrating_peak,num_of_KK,&real_maxx_scan_num,&real_maxx_inten, &max_s_inten, Q3);

							if (I3 < 0.0001) {
								if ((I3 < -0.999) && (I3 > -1.001)){
									cout << "The peak I3 (with given scannum) was not found. LN 1806" <<endl ;
									I3 = 0.0000;
								} else if ((I3 < -1.999) && (I3 > -8.001)) {
									continue;
								}
							}
							sh[2].max_R_time = max_R_time;
							sh[2].max_s_inten= max_s_inten;
							sh[2].starting_time = starting_time;
							sh[2].end_time= end_time;
							cout << "GGGG,I3,"<<seqfamilies[i].familyseq<<"%"<<seqfamilies[i].ms1p[0].rawfname<<"%"<<seqfamilies[i].ms1p[0].charge<<","<<max_scan_num<<","<<I3<<",";
							printf("%10.5f\n", seqfamilies[i].ms1p[2].mz_ms1);
							cout << "Time of I3 " << starting_time <<" "<< max_R_time <<"  "<< end_time << endl;
							cout << "afterI3,    max_scan_num= " << max_scan_num << endl;
							starting_time_i3 = starting_time;
							end_time_i3 = end_time;
							max_R_time_i3 = max_R_time;
							max_scan_num_i3 = max_scan_num;
							//BLOCK_I2I1
							if (seqfamilies[i].ms1p[3].MS2exist_indicator == 0) {
								//passive cal I2
								cout << "I2 passive" << endl;
								light_max_scan_num =0;
								cout << "B4 calling PPinte for I2 scannum="<<seqfamilies[i].ms1p[3].scannum << " seqfamilies[i].ms1p[3].mz_ms1=" << seqfamilies[i].ms1p[3].mz_ms1;
								cout << "    fname="<<seqfamilies[i].ms1p[3].rawfname <<endl;
								theXMLfname = ffolder; theXMLfname += seqfamilies[i].ms1p[3].rawfname;
								theXMLfname += tail;
								strcpy(XMLfname, theXMLfname.c_str());
								
								if ( I5 > (2*I3) ) {
									starting_time = starting_time_i5;
									end_time= end_time_i5;
									max_R_time = max_R_time_i5;
									max_scan_num = max_scan_num_i5;
									cout << "using I5 result to set up I2's time limits" <<endl;
									light_max_scan_num =0;
									I2 = PPintegratorB(XMLfname, max_scan_num, seqfamilies[i].ms1p[3].mz_ms1, 0,1, &starting_time, &end_time, &max_R_time, &light_max_scan_num,mz_error_calibrated_peak,num_of_KK,&real_maxx_scan_num,&real_maxx_inten, &max_s_inten, 3*mass_dif_3DH, seqfamilies[i].ms1p[0].charge, Q5);
								} else {
									cout << "using I3 result to set up I2's time limits" <<endl;
									light_max_scan_num =0;
									I2 = PPintegratorB(XMLfname, max_scan_num, seqfamilies[i].ms1p[3].mz_ms1, 0,1, &starting_time, &end_time, &max_R_time, &light_max_scan_num,mz_error_calibrated_peak,num_of_KK,&real_maxx_scan_num,&real_maxx_inten, &max_s_inten, mass_dif_3DH, seqfamilies[i].ms1p[0].charge, Q3);
								}
								
								negligibleI2 = false;
								if (I2 < 0.0001) {
									if ((I2 < -0.999) && (I2 > -1.001)) {
										cout << "The peak I2 (with given scannum) was not found. LN 1674" <<endl ;
										negligibleI2 = true;
									} else if ((I2 < -1.999) && (I2 > -8.001)) {
										continue; // peak is there but cannot get the value! dump!
									}
								}
								if (negligibleI2 == false) {
									cout << "Time of I2 " << starting_time <<" "<< max_R_time <<"  "<< end_time << endl;
									cout << "afterI2,    max_scan_num= " << max_scan_num <<"   light_max_scan_num= " << light_max_scan_num << endl;
									cout << "real_maxx_scan_num for background test is "<< real_maxx_scan_num << endl;
									threshold= 3 * noise_level(XMLfname, real_maxx_scan_num);
									cout << "threshold=" <<threshold<<"  real_maxx_inten=" << real_maxx_inten <<endl;
									if (real_maxx_inten > threshold) {
										cout << "I2 apex larger than background noise but sequence is not in MS2 dictionary. dump." << endl;
										continue;
									} else {
										negligibleI2 = true;
									}
								}
								sh[3].max_R_time = max_R_time;
								sh[3].max_s_inten= max_s_inten;
								sh[3].starting_time = starting_time;
								sh[3].end_time= end_time;

								if (negligibleI2 == true) {//if ( (I2 == 0.00) || (I2 <= threshold) ) {
									I2=0.0000000;
									//cal I1
									cout << "GGGG,I2,"<<seqfamilies[i].familyseq<<"%"<<seqfamilies[i].ms1p[0].rawfname<<"%"<<seqfamilies[i].ms1p[0].charge<<","<<light_max_scan_num<<","<<0.000<<",";
									printf("%10.5f\n", seqfamilies[i].ms1p[3].mz_ms1);
									
									if (seqfamilies[i].ms1p[4].scannum !=-1) {
										cout << "I1 active" << endl;
										cout << "B4 calling PPinte for I1 scannum="<<seqfamilies[i].ms1p[4].scannum << " seqfamilies[i].ms1p[4].mz_ms1=" << seqfamilies[i].ms1p[4].mz_ms1;
										cout << "   fname="<<seqfamilies[i].ms1p[4].rawfname <<endl;
										theXMLfname = ffolder; theXMLfname += seqfamilies[i].ms1p[4].rawfname;
										theXMLfname += tail;
										strcpy(XMLfname, theXMLfname.c_str());
										I1 = PPintegratorA(XMLfname, seqfamilies[i].ms1p[4].scannum, seqfamilies[i].ms1p[4].mz_ms1, 1,1,&starting_time, &end_time, &max_R_time, &max_scan_num,mz_error_calibrating_peak,num_of_KK,&real_maxx_scan_num,&real_maxx_inten, &max_s_inten, Q1);
									} else {
										cout << "I1 passive" << endl;
										cout << "B4 calling PPinte for I1 scannum="<<seqfamilies[i].ms1p[4].scannum << " seqfamilies[i].ms1p[4].mz_ms1=" << seqfamilies[i].ms1p[4].mz_ms1;
										cout << "    fname="<<seqfamilies[i].ms1p[4].rawfname <<endl;
										theXMLfname = ffolder; theXMLfname += seqfamilies[i].ms1p[4].rawfname;
										theXMLfname += tail;
										strcpy(XMLfname, theXMLfname.c_str());
										
										if ( I5 > (2*I3) ) {
											starting_time = starting_time_i5;
											end_time= end_time_i5;
											max_R_time = max_R_time_i5;
											max_scan_num = max_scan_num_i5;
											cout << "using I5 result to set up I1's time limits" <<endl;
											light_max_scan_num =0;
											I1 = PPintegratorB(XMLfname, max_scan_num, seqfamilies[i].ms1p[4].mz_ms1, 0,1, &starting_time, &end_time, &max_R_time, &light_max_scan_num,mz_error_calibrated_peak,num_of_KK,&real_maxx_scan_num,&real_maxx_inten, &max_s_inten, 4*mass_dif_3DH, seqfamilies[i].ms1p[0].charge, Q5);

										} else {
											starting_time = starting_time_i3;
											end_time= end_time_i3;
											max_R_time = max_R_time_i3;
											max_scan_num = max_scan_num_i3;
											cout << "using I3 result to set up I1's time limits" <<endl;
											light_max_scan_num =0;
											I1 = PPintegratorB(XMLfname, max_scan_num, seqfamilies[i].ms1p[4].mz_ms1, 0,1, &starting_time, &end_time, &max_R_time, &light_max_scan_num,mz_error_calibrated_peak,num_of_KK,&real_maxx_scan_num,&real_maxx_inten, &max_s_inten, 2*mass_dif_3DH, seqfamilies[i].ms1p[0].charge, Q3);
										}
									}
									if (I1 < 0.0001) {
										if ((I1 < -0.999) && (I1 > -1.001)){
											cout << "The peak I1 (with given scannum) was not found. LN 1895" <<endl ;
											I1 = 0.000000;
										} else if ((I1 < -1.999) && (I1 > -8.001)) {
											continue;
										}
									}
									sh[4].max_R_time = max_R_time;
									sh[4].max_s_inten= max_s_inten;
									sh[4].starting_time = starting_time;
									sh[4].end_time= end_time;
									if (seqfamilies[i].ms1p[4].scannum !=-1) {
										cout << "GGGG,I1,"<<seqfamilies[i].familyseq<<"%"<<seqfamilies[i].ms1p[0].rawfname<<"%"<<seqfamilies[i].ms1p[0].charge<<","<<max_scan_num<<","<<I1<<",";
										printf("%10.5f\n", seqfamilies[i].ms1p[4].mz_ms1);
									} else {
										cout << "GGGG,I1,"<<seqfamilies[i].familyseq<<"%"<<seqfamilies[i].ms1p[0].rawfname<<"%"<<seqfamilies[i].ms1p[0].charge<<","<<light_max_scan_num<<","<<I1<<",";
										printf("%10.5f\n", seqfamilies[i].ms1p[4].mz_ms1);
									}
									cout << "Time of I1 " << starting_time <<" "<< max_R_time <<"  "<< end_time << endl;
									if (seqfamilies[i].ms1p[4].scannum !=-1) {
										cout << "afterI1,    max_scan_num= " << max_scan_num << endl;
									} else {
										cout << "afterI1,    max_scan_num= " << max_scan_num <<"    light_max_scan_num= " << light_max_scan_num<< endl;
									}			  

								}//end of if (negligibleI2 == true)
								//The middle point of BLOCK_I2I1
							} else { //active cal I2, then I1 //assume: if it is in dictionary, it should be given scannum.
								if (seqfamilies[i].ms1p[3].scannum ==-1) { cout << "WRONG ASSUMPTION HERE.YOU SHOULD CORRECT YOU CODE.";
									cout << "You need to consider case in which scannum is not given for I2 LN 1737-1800" << endl; return 0;
								}
								cout << "I2 active" << endl;
								cout << "B4 calling PPinte for I2 scannum="<< seqfamilies[i].ms1p[3].scannum << " seqfamilies[i].ms1p[3].mz_ms1=" << seqfamilies[i].ms1p[3].mz_ms1;
								cout << "    fname="<<seqfamilies[i].ms1p[3].rawfname <<endl;
								theXMLfname = ffolder; theXMLfname += seqfamilies[i].ms1p[3].rawfname;
								theXMLfname += tail;
								strcpy(XMLfname, theXMLfname.c_str());
								I2 = PPintegratorA(XMLfname, seqfamilies[i].ms1p[3].scannum, seqfamilies[i].ms1p[3].mz_ms1, 1,1,&starting_time, &end_time, &max_R_time, &max_scan_num,mz_error_calibrating_peak,num_of_KK,&real_maxx_scan_num,&real_maxx_inten, &max_s_inten, Q2);

								if (I2 < 0.0001) {
									if ((I2 < -0.999) && (I2 > -1.001)){
										cout << "The peak I2 (with given scannum) was not found. LN 1748" <<endl ;
										I2 = 0.0000;
									} else if ((I2 < -1.999) && (I2 > -8.001)) {
										continue; // peak is there but cannot get the value! dump!
									}
								}
								sh[3].max_R_time = max_R_time;
								sh[3].max_s_inten= max_s_inten;
								sh[3].starting_time = starting_time;
								sh[3].end_time= end_time;
								cout << "GGGG,I2,"<<seqfamilies[i].familyseq<<"%"<<seqfamilies[i].ms1p[0].rawfname<<"%"<<seqfamilies[i].ms1p[0].charge<<","<<max_scan_num<<","<<I2<<",";
								printf("%10.5f\n", seqfamilies[i].ms1p[3].mz_ms1);

								cout << "Time of I2 " << starting_time <<" "<< max_R_time <<"  "<< end_time << endl;
								cout << "afterI2,    max_scan_num= " << max_scan_num << endl;
								if (seqfamilies[i].ms1p[4].scannum !=-1) {
									cout << "I1 active" << endl;
									cout << "B4 calling PPinte for I1 scannum="<<seqfamilies[i].ms1p[4].scannum << " seqfamilies[i].ms1p[4].mz_ms1=" << seqfamilies[i].ms1p[4].mz_ms1;
									cout << "   fname="<<seqfamilies[i].ms1p[4].rawfname <<endl;
									theXMLfname = ffolder; theXMLfname += seqfamilies[i].ms1p[4].rawfname;
									theXMLfname += tail;
									strcpy(XMLfname, theXMLfname.c_str());
									I1 = PPintegratorA(XMLfname, seqfamilies[i].ms1p[4].scannum, seqfamilies[i].ms1p[4].mz_ms1, 1,1,&starting_time, &end_time, &max_R_time, &max_scan_num,mz_error_calibrating_peak,num_of_KK,&real_maxx_scan_num,&real_maxx_inten, &max_s_inten, Q1);
									
								} else {
									cout << "I1 passive" << endl;
									cout << "B4 calling PPinte for I1 scannum="<<seqfamilies[i].ms1p[4].scannum << " seqfamilies[i].ms1p[4].mz_ms1=" << seqfamilies[i].ms1p[4].mz_ms1;
									cout << "    fname="<<seqfamilies[i].ms1p[4].rawfname <<endl;
									theXMLfname = ffolder; theXMLfname += seqfamilies[i].ms1p[4].rawfname;
									theXMLfname += tail;
									strcpy(XMLfname, theXMLfname.c_str());
									light_max_scan_num =0;

									if ((I5 > 2*I3) && (I5 > 2*I2)) {
										cout << "using I5 result to set up I1's time limits" <<endl;
										starting_time = starting_time_i5;
										end_time= end_time_i5;
										max_R_time = max_R_time_i5;
										max_scan_num = max_scan_num_i5;
										I1 = PPintegratorB(XMLfname, max_scan_num, seqfamilies[i].ms1p[4].mz_ms1, 0,1, &starting_time, &end_time, &max_R_time, &light_max_scan_num,mz_error_calibrated_peak,num_of_KK,&real_maxx_scan_num,&real_maxx_inten, &max_s_inten, 4*mass_dif_3DH, seqfamilies[i].ms1p[0].charge, Q5);
									} else if (I3>I2) {
										cout << "using I3 result to set up I1's time limits" <<endl;
										starting_time = starting_time_i3;
										end_time= end_time_i3;
										max_R_time = max_R_time_i3;
										max_scan_num = max_scan_num_i3;
										I1 = PPintegratorB(XMLfname, max_scan_num, seqfamilies[i].ms1p[4].mz_ms1, 0,1, &starting_time, &end_time, &max_R_time, &light_max_scan_num,mz_error_calibrated_peak,num_of_KK,&real_maxx_scan_num,&real_maxx_inten, &max_s_inten, 2*mass_dif_3DH, seqfamilies[i].ms1p[0].charge, Q3);
									} else{
										cout << "using I2 result to set up I1's time limits" <<endl;
										I1 = PPintegratorB(XMLfname, max_scan_num, seqfamilies[i].ms1p[4].mz_ms1, 0,1, &starting_time, &end_time, &max_R_time, &light_max_scan_num,mz_error_calibrated_peak,num_of_KK,&real_maxx_scan_num,&real_maxx_inten, &max_s_inten, mass_dif_3DH, seqfamilies[i].ms1p[0].charge, Q2);
									}
									
								}
								if (I1 < 0.0001) {
									if ((I1 < -0.999) && (I1 > -1.001)){
										cout << "The peak I1 (with given scannum) was not found. LN 1722" <<endl ;
										I1 = 0.000000;
									} else if ((I1 < -1.999) && (I1 > -8.001)) {
										continue;
									}
								}
								sh[4].max_R_time = max_R_time;
								sh[4].max_s_inten= max_s_inten;
								sh[4].starting_time = starting_time;
								sh[4].end_time= end_time;

								if (seqfamilies[i].ms1p[4].scannum !=-1) {
									cout << "GGGG,I1,"<<seqfamilies[i].familyseq<<"%"<<seqfamilies[i].ms1p[0].rawfname<<"%"<<seqfamilies[i].ms1p[0].charge<<","<<max_scan_num<<","<<I1<<",";
									printf("%10.5f\n", seqfamilies[i].ms1p[4].mz_ms1);
								} else {
									cout << "GGGG,I1,"<<seqfamilies[i].familyseq<<"%"<<seqfamilies[i].ms1p[0].rawfname<<"%"<<seqfamilies[i].ms1p[0].charge<<","<<light_max_scan_num<<","<<I1<<",";
									printf("%10.5f\n", seqfamilies[i].ms1p[4].mz_ms1);
								}

								cout << "Time of I1 " << starting_time <<" "<< max_R_time <<"  "<< end_time << endl;
								if (seqfamilies[i].ms1p[4].scannum !=-1) {
									cout << "afterI1,    max_scan_num= " << max_scan_num << endl;
								} else {
									cout << "afterI1,    max_scan_num= " << max_scan_num <<"    light_max_scan_num= " << light_max_scan_num<< endl;
								}
							}
							//END OF BLOCK_I2I1 
						} ////end of if (I3 ms2 ==0){}else{
					}//end of if (negligibleI4 == true){
				} else if ((seqfamilies[i].ms1p[2].MS2exist_indicator== 1) && (seqfamilies[i].ms1p[2].scannum !=-1)){  // end of I5 ms1==1   // (I3 ms2 ==1 && I3 ms1 ==1 ) { 
					//active cal I3 
					cout << "active I3" << endl;
					cout << "B4 calling PPinte for I3 scannum="<<seqfamilies[i].ms1p[2].scannum << " mz_ms1=" << seqfamilies[i].ms1p[2].mz_ms1;                         
					cout << " fname="<<seqfamilies[i].ms1p[2].rawfname <<endl;
					theXMLfname = ffolder; theXMLfname += seqfamilies[i].ms1p[2].rawfname;
					theXMLfname += tail;
					strcpy(XMLfname, theXMLfname.c_str());              
					I3 = PPintegratorA(XMLfname, seqfamilies[i].ms1p[2].scannum, seqfamilies[i].ms1p[2].mz_ms1, 1,1,&starting_time, &end_time, &max_R_time, &max_scan_num,mz_error_calibrating_peak,num_of_KK,&real_maxx_scan_num,&real_maxx_inten, &max_s_inten, Q3);

					//print out some stuff to check
					if (I3 < 0.0001) {
						if ((I3 < -0.999) && (I3 > -1.001)){
							cout << "The peak I3 (with given scannum) was not found. LN 1562" <<endl ;
							I3 = 0.0000;
						} else if ((I3 < -1.999) && (I3 > -8.001)) {
							continue;
						}
					}
					sh[2].max_R_time = max_R_time;
					sh[2].max_s_inten= max_s_inten;
					sh[2].starting_time = starting_time;
					sh[2].end_time= end_time;
					cout << "GGGG,I3,"<<seqfamilies[i].familyseq<<"%"<<seqfamilies[i].ms1p[0].rawfname<<"%"<<seqfamilies[i].ms1p[0].charge<<","<<max_scan_num<<","<<I3<<",";
					printf("%10.5f\n", seqfamilies[i].ms1p[2].mz_ms1);
					cout << "Time of I3 " << starting_time <<" "<< max_R_time <<"  "<< end_time << endl;
					cout << "afterI3, max_scan_num= " << max_scan_num <<endl;
					starting_time_i3 = starting_time;
					end_time_i3= end_time;
					max_R_time_i3 = max_R_time;
					max_scan_num_i3 = max_scan_num;
					
					light_max_scan_num = 0;
					cout << "passive I4" << endl;
					cout << "B4 calling PPinte for I4 scannum="<<seqfamilies[i].ms1p[1].scannum << " seqfamilies[i].ms1p[1].mz_ms1=" << seqfamilies[i].ms1p[1].mz_ms1;
					cout << "    fname="<<seqfamilies[i].ms1p[1].rawfname <<endl;
					theXMLfname = ffolder; theXMLfname += seqfamilies[i].ms1p[1].rawfname;
					theXMLfname += tail;
					strcpy(XMLfname, theXMLfname.c_str());
					cout << "using I3 result to set up I4's time limits" <<endl;
					I4 = PPintegratorB(XMLfname, max_scan_num, seqfamilies[i].ms1p[1].mz_ms1, 0,0, &starting_time, &end_time, &max_R_time, &light_max_scan_num,mz_error_calibrated_peak,num_of_KK,&real_maxx_scan_num,&real_maxx_inten, &max_s_inten, mass_dif_3DH, seqfamilies[i].ms1p[0].charge, Q3);
					
					negligibleI4 = false;
					if (I4 < 0.0001) {
						if ((I4 < -0.999) && (I4 > -1.001)) {
							cout << "The peak I4 (with given scannum) was not found. LN 845" <<endl ;
							negligibleI4 = true;
						} else if ((I4 < -1.999) && (I4 > -8.001)) {
							continue; // peak is there but cannot get the value! dump!
						}
					}
					if (negligibleI4 == false) {
						cout << "Time of I4 " << starting_time <<" "<< max_R_time <<"  "<< end_time << endl;
						cout << "afterI4, max_scan_num= " << max_scan_num<<"   light_max_scan_num= " << light_max_scan_num <<endl;
						cout << "real_maxx_scan_num for background test is "<< real_maxx_scan_num << endl;
						threshold= 3 * noise_level(XMLfname, real_maxx_scan_num);
						cout << "threshold=" <<threshold<<"  real_maxx_inten=" << real_maxx_inten <<endl;
						if (real_maxx_inten > threshold) {
							cout << "I4 apex larger than background noise but sequence is not in MS2 dictionary. dump." << endl;
							continue;
						} else {
							negligibleI4 = true;
						}
					}
					sh[1].max_R_time = max_R_time;
					sh[1].max_s_inten= max_s_inten;
					sh[1].starting_time = starting_time;
					sh[1].end_time= end_time;

					if (negligibleI4 == true) {
						I4=0.00000; //alphaL_frac[0]=0.000; betaL_frac[0] =0.000;  ///?? CHECK with
						cout << "GGGG,I4,"<<seqfamilies[i].familyseq<<"%"<<seqfamilies[i].ms1p[0].rawfname<<"%"<<seqfamilies[i].ms1p[0].charge<<","<<light_max_scan_num<<","<<0.000<<",";
						printf("%10.5f\n", seqfamilies[i].ms1p[1].mz_ms1);
						cout << "passive I5" << endl;
						starting_time = starting_time_i3;
						end_time= end_time_i3;
						max_R_time = max_R_time_i3;
						max_scan_num = max_scan_num_i3;
						light_max_scan_num =0;
						cout << "B4 calling PPinte for I5 scannum="<<seqfamilies[i].ms1p[0].scannum << " seqfamilies[i].ms1p[0].mz_ms1=" << seqfamilies[i].ms1p[0].mz_ms1;
						cout << "    fname="<<seqfamilies[i].ms1p[0].rawfname <<endl;
						theXMLfname = ffolder; theXMLfname += seqfamilies[i].ms1p[0].rawfname;
						theXMLfname += tail;
						strcpy(XMLfname, theXMLfname.c_str());
						I5 = PPintegratorB(XMLfname, max_scan_num, seqfamilies[i].ms1p[0].mz_ms1, 0,0, &starting_time, &end_time, &max_R_time, &light_max_scan_num,mz_error_calibrated_peak,num_of_KK,&real_maxx_scan_num,&real_maxx_inten, &max_s_inten, 2*mass_dif_3DH, seqfamilies[i].ms1p[0].charge, Q3);

						if (I5 < 0.0001) {
							if ((I5 < -0.999) && (I5 > -1.001)){
								cout << "The peak I5 (with given scannum) was not found. LN 1562" <<endl ;
								I5 = 0.0000;
							} else if ((I5 < -1.999) && (I5 > -8.001)) {
								continue;
							}
						}
						sh[0].max_R_time = max_R_time;
						sh[0].max_s_inten= max_s_inten;
						sh[0].starting_time = starting_time;
						sh[0].end_time= end_time;
						cout << "GGGG,I5,"<<seqfamilies[i].familyseq<<"%"<<seqfamilies[i].ms1p[0].rawfname<<"%"<<seqfamilies[i].ms1p[0].charge<<","<<light_max_scan_num<<","<<I5<<",";
						printf("%10.5f\n", seqfamilies[i].ms1p[0].mz_ms1);
						
						cout << "Time of I5 " << starting_time <<" "<< max_R_time <<"  "<< end_time << endl;
						cout << "afterI5, light_max_scan_num= " << light_max_scan_num <<endl;

						//BLOCK_I2I1
						if (seqfamilies[i].ms1p[3].MS2exist_indicator == 0) {
							//passive cal I2
							cout << "I2 passive" << endl;
							starting_time = starting_time_i3;
							end_time= end_time_i3;
							max_R_time = max_R_time_i3;
							max_scan_num = max_scan_num_i3;

							light_max_scan_num =0;
							cout << "B4 calling PPinte for I2 scannum="<<seqfamilies[i].ms1p[3].scannum << " seqfamilies[i].ms1p[3].mz_ms1=" << seqfamilies[i].ms1p[3].mz_ms1;
							cout << "    fname="<<seqfamilies[i].ms1p[3].rawfname <<endl;
							theXMLfname = ffolder; theXMLfname += seqfamilies[i].ms1p[3].rawfname;
							theXMLfname += tail;
							strcpy(XMLfname, theXMLfname.c_str());
							I2 = PPintegratorB(XMLfname, max_scan_num, seqfamilies[i].ms1p[3].mz_ms1, 0,1, &starting_time, &end_time, &max_R_time, &light_max_scan_num,mz_error_calibrated_peak,num_of_KK,&real_maxx_scan_num,&real_maxx_inten, &max_s_inten, mass_dif_3DH, seqfamilies[i].ms1p[0].charge, Q3);

							negligibleI2 = false;
							if (I2 < 0.0001) {
								if ((I2 < -0.999) && (I2 > -1.001)) {
									cout << "The peak I2 (with given scannum) was not found. LN 1674" <<endl ;
									negligibleI2 = true;
								} else if ((I2 < -1.999) && (I2 > -8.001)) {
									continue; // peak is there but cannot get the value! dump!
								}
							}
							if (negligibleI2 == false) {
								cout << "Time of I2 " << starting_time <<" "<< max_R_time <<"  "<< end_time << endl;
								cout << "afterI2,    max_scan_num= " << max_scan_num <<"   light_max_scan_num= " << light_max_scan_num << endl;
								cout << "real_maxx_scan_num for background test is "<< real_maxx_scan_num << endl;
								threshold= 3 * noise_level(XMLfname, real_maxx_scan_num);
								cout << "threshold=" <<threshold<<"  real_maxx_inten=" << real_maxx_inten <<endl;
								if (real_maxx_inten > threshold) {
									cout << "I2 apex larger than background noise but sequence is not in MS2 dictionary. dump." << endl;
									continue;
								} else {
									negligibleI2 = true;
								}
							}
							sh[3].max_R_time = max_R_time;
							sh[3].max_s_inten= max_s_inten;
							sh[3].starting_time = starting_time;
							sh[3].end_time= end_time;

							if (negligibleI2 == true) {//if ( (I2 == 0.00) || (I2 <= threshold) ) {
								I2=0.0000000;
								cout << "GGGG,I2,"<<seqfamilies[i].familyseq<<"%"<<seqfamilies[i].ms1p[0].rawfname<<"%"<<seqfamilies[i].ms1p[0].charge<<","<<light_max_scan_num<<","<<0.000<<",";
								printf("%10.5f\n", seqfamilies[i].ms1p[3].mz_ms1);
								//cal I1
								if (seqfamilies[i].ms1p[4].scannum !=-1) {
									cout << "I1 active" << endl;
									cout << "B4 calling PPinte for I1 scannum="<<seqfamilies[i].ms1p[4].scannum << " seqfamilies[i].ms1p[4].mz_ms1=" << seqfamilies[i].ms1p[4].mz_ms1;
									cout << "   fname="<<seqfamilies[i].ms1p[4].rawfname <<endl;
									theXMLfname = ffolder; theXMLfname += seqfamilies[i].ms1p[4].rawfname;
									theXMLfname += tail;
									strcpy(XMLfname, theXMLfname.c_str());
									I1 = PPintegratorA(XMLfname, seqfamilies[i].ms1p[4].scannum, seqfamilies[i].ms1p[4].mz_ms1, 1,1,&starting_time, &end_time, &max_R_time, &max_scan_num,mz_error_calibrating_peak,num_of_KK,&real_maxx_scan_num,&real_maxx_inten, &max_s_inten, Q1);

								} else {
									cout << "I1 passive" << endl;
									starting_time = starting_time_i3;
									end_time= end_time_i3;
									max_R_time = max_R_time_i3;
									max_scan_num = max_scan_num_i3;
									light_max_scan_num =0;
									cout << "B4 calling PPinte for I1 scannum="<<seqfamilies[i].ms1p[4].scannum << " seqfamilies[i].ms1p[4].mz_ms1=" << seqfamilies[i].ms1p[4].mz_ms1;
									cout << "    fname="<<seqfamilies[i].ms1p[4].rawfname <<endl;
									theXMLfname = ffolder; theXMLfname += seqfamilies[i].ms1p[4].rawfname;
									theXMLfname += tail;
									strcpy(XMLfname, theXMLfname.c_str());
									I1 = PPintegratorB(XMLfname, max_scan_num, seqfamilies[i].ms1p[4].mz_ms1, 0,1, &starting_time, &end_time, &max_R_time, &light_max_scan_num,mz_error_calibrated_peak,num_of_KK,&real_maxx_scan_num,&real_maxx_inten, &max_s_inten, 2*mass_dif_3DH, seqfamilies[i].ms1p[0].charge, Q3);

								}
								if (I1 < 0.0001) {
									if ((I1 < -0.999) && (I1 > -1.001)){
										cout << "The peak I1 (with given scannum) was not found. LN 2128" <<endl ;
										I1 = 0.000000;
									} else if ((I1 < -1.999) && (I1 > -8.001)) {
										continue;
									}
								}
								sh[4].max_R_time = max_R_time;
								sh[4].max_s_inten= max_s_inten;
								sh[4].starting_time = starting_time;
								sh[4].end_time= end_time;
								if (seqfamilies[i].ms1p[4].scannum !=-1) {
									cout << "GGGG,I1,"<<seqfamilies[i].familyseq<<"%"<<seqfamilies[i].ms1p[0].rawfname<<"%"<<seqfamilies[i].ms1p[0].charge<<","<<max_scan_num<<","<<I1<<",";
									printf("%10.5f\n", seqfamilies[i].ms1p[4].mz_ms1);
								} else {
									cout << "GGGG,I1,"<<seqfamilies[i].familyseq<<"%"<<seqfamilies[i].ms1p[0].rawfname<<"%"<<seqfamilies[i].ms1p[0].charge<<","<<light_max_scan_num<<","<<I1<<",";
									printf("%10.5f\n", seqfamilies[i].ms1p[4].mz_ms1);
								}
								cout << "Time of I1 " << starting_time <<" "<< max_R_time <<"  "<< end_time << endl;
								if (seqfamilies[i].ms1p[4].scannum !=-1) {
									cout << "afterI1,    max_scan_num= " << max_scan_num << endl;
								} else {
									cout << "afterI1,    max_scan_num= " << max_scan_num <<"    light_max_scan_num= " << light_max_scan_num<< endl;
								}
							}//end of if (negligibleI2 == true)
						} else { //active cal I2, then I1 //assume: if it is in dictionary, it should be given scannum.
							if (seqfamilies[i].ms1p[3].scannum ==-1) { cout << "WRONG ASSUMPTION HERE.YOU SHOULD CORRECT YOU CODE.";
								cout << "You need to consider case in which scannum is not given for I2 LN 1737-1800" << endl; return 0;
							}
							cout << "I2 active" << endl;
							cout << "B4 calling PPinte for I2 scannum="<< seqfamilies[i].ms1p[3].scannum << " seqfamilies[i].ms1p[3].mz_ms1=" << seqfamilies[i].ms1p[3].mz_ms1;
							cout << "    fname="<<seqfamilies[i].ms1p[3].rawfname <<endl;
							theXMLfname = ffolder; theXMLfname += seqfamilies[i].ms1p[3].rawfname;
							theXMLfname += tail;
							strcpy(XMLfname, theXMLfname.c_str());
							I2 = PPintegratorA(XMLfname, seqfamilies[i].ms1p[3].scannum, seqfamilies[i].ms1p[3].mz_ms1, 1,1,&starting_time, &end_time, &max_R_time, &max_scan_num,mz_error_calibrating_peak,num_of_KK,&real_maxx_scan_num,&real_maxx_inten, &max_s_inten, Q2);

							if (I2 < 0.0001) {
								if ((I2 < -0.999) && (I2 > -1.001)){
									cout << "The peak I2 (with given scannum) was not found. LN 1748" <<endl ;
									I2 = 0.0000;
								} else if ((I2 < -1.999) && (I2 > -8.001)) {
									continue; // peak is there but cannot get the value! dump!
								}
							}
							sh[3].max_R_time = max_R_time;
							sh[3].max_s_inten= max_s_inten;
							sh[3].starting_time = starting_time;
							sh[3].end_time= end_time;
							cout << "GGGG,I2,"<<seqfamilies[i].familyseq<<"%"<<seqfamilies[i].ms1p[0].rawfname<<"%"<<seqfamilies[i].ms1p[0].charge<<","<<max_scan_num<<","<<I2<<",";
							printf("%10.5f\n", seqfamilies[i].ms1p[3].mz_ms1);

							cout << "Time of I2 " << starting_time <<" "<< max_R_time <<"  "<< end_time << endl;
							cout << "afterI2,    max_scan_num= " << max_scan_num << endl;
							if (seqfamilies[i].ms1p[4].scannum !=-1) {
								cout << "I1 active" << endl;
								cout << "B4 calling PPinte for I1 scannum="<<seqfamilies[i].ms1p[4].scannum << " seqfamilies[i].ms1p[4].mz_ms1=" << seqfamilies[i].ms1p[4].mz_ms1;
								cout << "   fname="<<seqfamilies[i].ms1p[4].rawfname <<endl;
								theXMLfname = ffolder; theXMLfname += seqfamilies[i].ms1p[4].rawfname;
								theXMLfname += tail;
								strcpy(XMLfname, theXMLfname.c_str());
								//I1 = PPintegrator(XMLfname, seqfamilies[i].ms1p[4].scannum, seqfamilies[i].ms1p[4].mz_ms1, 1, 1, &starting_time, &end_time, &max_R_time, &max_scan_num,mz_error, num_of_KK,&real_maxx_scan_num,&real_maxx_inten, &max_s_inten, &array_starting_time, &array_end_time);//heavy        
								I1 = PPintegratorA(XMLfname, seqfamilies[i].ms1p[4].scannum, seqfamilies[i].ms1p[4].mz_ms1, 1,1,&starting_time, &end_time, &max_R_time, &max_scan_num,mz_error_calibrating_peak,num_of_KK,&real_maxx_scan_num,&real_maxx_inten, &max_s_inten, Q1);
							} else { //blah02
								cout << "I1 passive" << endl;
								cout << "B4 calling PPinte for I1 scannum="<<seqfamilies[i].ms1p[4].scannum << " seqfamilies[i].ms1p[4].mz_ms1=" << seqfamilies[i].ms1p[4].mz_ms1;
								cout << "    fname="<<seqfamilies[i].ms1p[4].rawfname <<endl;
								theXMLfname = ffolder; theXMLfname += seqfamilies[i].ms1p[4].rawfname;
								theXMLfname += tail;
								strcpy(XMLfname, theXMLfname.c_str());

								if (I3 > (2*I2)){
									cout << "using I3 result to set up I1's time limits" <<endl;
									starting_time = starting_time_i3;
									end_time= end_time_i3;
									max_R_time = max_R_time_i3;
									max_scan_num = max_scan_num_i3;
									light_max_scan_num =0;
									I1 = PPintegratorB(XMLfname, max_scan_num, seqfamilies[i].ms1p[4].mz_ms1, 0,1, &starting_time, &end_time, &max_R_time, &light_max_scan_num,mz_error_calibrated_peak,num_of_KK,&real_maxx_scan_num,&real_maxx_inten, &max_s_inten, 2*mass_dif_3DH, seqfamilies[i].ms1p[0].charge, Q3);
								} else {
									cout << "using I2 result to set up I1's time limits" <<endl;
									I1 = PPintegratorB(XMLfname, max_scan_num, seqfamilies[i].ms1p[4].mz_ms1, 0,1, &starting_time, &end_time, &max_R_time, &light_max_scan_num,mz_error_calibrated_peak,num_of_KK,&real_maxx_scan_num,&real_maxx_inten, &max_s_inten, mass_dif_3DH, seqfamilies[i].ms1p[0].charge, Q2);
								}
							} //blah02
							if (I1 < 0.0001) {
								if ((I1 < -0.999) && (I1 > -1.001)){
									cout << "The peak I1 (with given scannum) was not found. LN 2189" <<endl ;
									I1 = 0.000000;
								} else if ((I1 < -1.999) && (I1 > -8.001)) {
									continue;
								}
							}
							sh[4].max_R_time = max_R_time;
							sh[4].max_s_inten= max_s_inten;
							sh[4].starting_time = starting_time;
							sh[4].end_time= end_time;
							if (seqfamilies[i].ms1p[4].scannum !=-1) {
								cout << "GGGG,I1,"<<seqfamilies[i].familyseq<<"%"<<seqfamilies[i].ms1p[0].rawfname<<"%"<<seqfamilies[i].ms1p[0].charge<<","<<max_scan_num<<","<<I1<<",";
								printf("%10.5f\n", seqfamilies[i].ms1p[4].mz_ms1);
							} else {
								cout << "GGGG,I1,"<<seqfamilies[i].familyseq<<"%"<<seqfamilies[i].ms1p[0].rawfname<<"%"<<seqfamilies[i].ms1p[0].charge<<","<<light_max_scan_num<<","<<I1<<",";
								printf("%10.5f\n", seqfamilies[i].ms1p[4].mz_ms1);
							}

							cout << "Time of I1 " << starting_time <<" "<< max_R_time <<"  "<< end_time << endl;
							if (seqfamilies[i].ms1p[4].scannum !=-1) {
								cout << "afterI1,    max_scan_num= " << max_scan_num << endl;
							} else {
								cout << "afterI1,    max_scan_num= " << max_scan_num <<"    light_max_scan_num= " << light_max_scan_num<< endl;
							}
							
						} //end of I2 is in MS2 dictionary 

						//END OF BLOCK_I2I1    
					}//end of if (negligibleI4 = true)


				} else if ((seqfamilies[i].ms1p[3].MS2exist_indicator== 1) && (seqfamilies[i].ms1p[3].scannum !=-1)){
					cout << "I2 active" << endl;
					cout << "B4 calling PPinte for I2 scannum="<< seqfamilies[i].ms1p[3].scannum << " seqfamilies[i].ms1p[3].mz_ms1=" << seqfamilies[i].ms1p[3].mz_ms1;
					cout << "    fname="<<seqfamilies[i].ms1p[3].rawfname <<endl;
					theXMLfname = ffolder; theXMLfname += seqfamilies[i].ms1p[3].rawfname;    theXMLfname += tail;
					strcpy(XMLfname, theXMLfname.c_str());
					I2 = PPintegratorA(XMLfname, seqfamilies[i].ms1p[3].scannum, seqfamilies[i].ms1p[3].mz_ms1, 1,1,&starting_time, &end_time, &max_R_time, &max_scan_num,mz_error_calibrating_peak,num_of_KK,&real_maxx_scan_num,&real_maxx_inten, &max_s_inten, Q2);

					if (I2 < 0.0001) {
						if ((I2 < -0.999) && (I2 > -1.001)){
							cout << "The peak I2 (with given scannum) was not found." <<endl ;
							I2 = 0.0000;
						} else if ((I2 < -1.999) && (I2 > -8.001)) {
							continue; // peak is there but cannot get the value! dump!
						}
					}
					sh[3].max_R_time = max_R_time;
					sh[3].max_s_inten= max_s_inten;
					sh[3].starting_time = starting_time;
					sh[3].end_time= end_time;
					cout << "GGGG,I2,"<<seqfamilies[i].familyseq<<"%"<<seqfamilies[i].ms1p[0].rawfname<<"%"<<seqfamilies[i].ms1p[0].charge<<","<<max_scan_num<<","<<I2<<",";
					printf("%10.5f\n", seqfamilies[i].ms1p[3].mz_ms1);
					cout << "Time of I2 " << starting_time <<" "<< max_R_time <<"  "<< end_time << endl;
					cout << "afterI2,    max_scan_num= " << max_scan_num << endl;
					starting_time_i2 = starting_time;
					end_time_i2= end_time;
					max_R_time_i2 = max_R_time;
					max_scan_num_i2 = max_scan_num;

					light_max_scan_num =0;
					cout << "I3 passive" << endl;
					light_max_scan_num =0;
					cout << "B4 calling PPinte for I3 scannum="<<seqfamilies[i].ms1p[2].scannum << " seqfamilies[i].ms1p[2].mz_ms1=" << seqfamilies[i].ms1p[2].mz_ms1;
					cout << "    fname="<<seqfamilies[i].ms1p[2].rawfname <<endl;
					theXMLfname = ffolder; theXMLfname += seqfamilies[i].ms1p[2].rawfname;
					theXMLfname += tail;
					strcpy(XMLfname, theXMLfname.c_str());
					I3 = PPintegratorB(XMLfname, max_scan_num, seqfamilies[i].ms1p[2].mz_ms1, 0,0, &starting_time, &end_time, &max_R_time, &light_max_scan_num,mz_error_calibrated_peak,num_of_KK,&real_maxx_scan_num,&real_maxx_inten, &max_s_inten, mass_dif_3DH, seqfamilies[i].ms1p[0].charge, Q2);

					negligibleI3 = false;
					if (I3 < 0.0001) {
						if ((I3 < -0.999) && (I3 > -1.001)) {
							cout << "The peak I3 (with given scannum) was not found. LN 1633" <<endl ;
							negligibleI3 = true;
						} else if ((I3 < -1.999) && (I3 > -8.001)) {
							continue; // peak is there but cannot get the value! dump!
						}
					}
					if (negligibleI3 == false) {
						cout << "Time of I3 " << starting_time <<" "<< max_R_time <<"  "<< end_time << endl;
						cout << "afterI3, max_scan_num= " << max_scan_num<<"   light_max_scan_num= " << light_max_scan_num <<endl;
						cout << "real_maxx_scan_num for background test is "<< real_maxx_scan_num << endl;
						threshold= 3 * noise_level(XMLfname, real_maxx_scan_num);
						cout << "threshold=" <<threshold<<"  real_maxx_inten=" << real_maxx_inten <<endl;
						if (real_maxx_inten > threshold) {
							cout << "I3 apex larger than background noise but sequence is not in MS2 dictionary. dump." << endl;
							continue;
						} else {
							negligibleI3 = true;
						}
					}
					sh[2].max_R_time = max_R_time;
					sh[2].max_s_inten= max_s_inten;
					sh[2].starting_time = starting_time;
					sh[2].end_time= end_time;
					
					if (negligibleI3 == true) {
						I3=0.00000; //alphaL_frac[0]=0.000; betaL_frac[0] =0.000;  ///?? CHECK with
						cout << "GGGG,I3,"<<seqfamilies[i].familyseq<<"%"<<seqfamilies[i].ms1p[0].rawfname<<"%"<<seqfamilies[i].ms1p[0].charge<<","<<light_max_scan_num<<","<<0.000<<",";
						printf("%10.5f\n", seqfamilies[i].ms1p[2].mz_ms1);
						starting_time = starting_time_i2;
						end_time= end_time_i2;
						max_R_time = max_R_time_i2;
						max_scan_num = max_scan_num_i2;
						light_max_scan_num = 0;
						cout << "passive I4" << endl;
						cout << "B4 calling PPinte for I4 scannum="<<seqfamilies[i].ms1p[1].scannum << " seqfamilies[i].ms1p[1].mz_ms1=" << seqfamilies[i].ms1p[1].mz_ms1;
						cout << "    fname="<<seqfamilies[i].ms1p[1].rawfname <<endl;
						theXMLfname = ffolder; theXMLfname += seqfamilies[i].ms1p[1].rawfname;
						theXMLfname += tail;
						strcpy(XMLfname, theXMLfname.c_str());
						I4 = PPintegratorB(XMLfname, max_scan_num, seqfamilies[i].ms1p[1].mz_ms1, 0,0, &starting_time, &end_time, &max_R_time, &light_max_scan_num,mz_error_calibrated_peak,num_of_KK,&real_maxx_scan_num,&real_maxx_inten, &max_s_inten, 2*mass_dif_3DH, seqfamilies[i].ms1p[0].charge, Q2);

						negligibleI4 = false;
						if (I4 < 0.0001) {
							if ((I4 < -0.999) && (I4 > -1.001)) {
								cout << "The peak I4 (with given scannum) was not found. LN 845" <<endl ;
								negligibleI4 = true;
							} else if ((I4 < -1.999) && (I4 > -8.001)) {
								continue; // peak is there but cannot get the value! dump!
							}
						}
						if (negligibleI4 == false) {
							cout << "Time of I4 " << starting_time <<" "<< max_R_time <<"  "<< end_time << endl;
							cout << "afterI4, max_scan_num= " << max_scan_num<<"   light_max_scan_num= " << light_max_scan_num <<endl;
							cout << "real_maxx_scan_num for background test is "<< real_maxx_scan_num << endl;
							threshold= 3 * noise_level(XMLfname, real_maxx_scan_num);
							cout << "threshold=" <<threshold<<"  real_maxx_inten=" << real_maxx_inten <<endl;
							if (real_maxx_inten > threshold) {
								cout << "I4 apex larger than background noise but sequence is not in MS2 dictionary. dump." << endl;
								continue;
							} else {
								negligibleI4 = true;
							}
						}
						sh[1].max_R_time = max_R_time;
						sh[1].max_s_inten= max_s_inten;
						sh[1].starting_time = starting_time;
						sh[1].end_time= end_time;

						if (negligibleI4 == true) {
							I4=0.00000; //alphaL_frac[0]=0.000; betaL_frac[0] =0.000;  ///?? CHECK with
							cout << "GGGG,I4,"<<seqfamilies[i].familyseq<<"%"<<seqfamilies[i].ms1p[0].rawfname<<"%"<<seqfamilies[i].ms1p[0].charge<<","<<light_max_scan_num<<","<<0.000<<",";
							printf("%10.5f\n", seqfamilies[i].ms1p[1].mz_ms1);
							starting_time = starting_time_i2;
							end_time= end_time_i2;
							max_R_time = max_R_time_i2;
							max_scan_num = max_scan_num_i2;
							light_max_scan_num = 0;
							cout << "passive I5" << endl;
							cout << "B4 calling PPinte for I5 scannum="<<seqfamilies[i].ms1p[0].scannum << " seqfamilies[i].ms1p[0].mz_ms1=" << seqfamilies[i].ms1p[0].mz_ms1;
							cout << "    fname="<<seqfamilies[i].ms1p[0].rawfname <<endl;
							theXMLfname = ffolder; theXMLfname += seqfamilies[i].ms1p[0].rawfname;
							theXMLfname += tail;
							strcpy(XMLfname, theXMLfname.c_str());
							I5 = PPintegratorB(XMLfname, max_scan_num, seqfamilies[i].ms1p[0].mz_ms1, 0,0, &starting_time, &end_time, &max_R_time, &light_max_scan_num,mz_error_calibrated_peak,num_of_KK,&real_maxx_scan_num,&real_maxx_inten, &max_s_inten, 3*mass_dif_3DH, seqfamilies[i].ms1p[0].charge, Q2);

							if (I5 < 0.0001) {
								if ((I5 < -0.999) && (I5 > -1.001)){
									cout << "The peak I5 (with given scannum) was not found. LN 1562" <<endl ;
									I5 = 0.0000;
								} else if ((I5 < -1.999) && (I5 > -8.001)) {
									continue;
								}
							}
							sh[0].max_R_time = max_R_time;
							sh[0].max_s_inten= max_s_inten;
							sh[0].starting_time = starting_time;
							sh[0].end_time= end_time;
							cout << "GGGG,I5,"<<seqfamilies[i].familyseq<<"%"<<seqfamilies[i].ms1p[0].rawfname<<"%"<<seqfamilies[i].ms1p[0].charge<<","<<light_max_scan_num<<","<<I5<<",";
							printf("%10.5f\n", seqfamilies[i].ms1p[0].mz_ms1);

							cout << "Time of I5 " << starting_time <<" "<< max_R_time <<"  "<< end_time << endl;
							cout << "afterI5, max_scan_num= " << max_scan_num <<endl;
							//cal I1
							if (seqfamilies[i].ms1p[4].scannum !=-1) {
								cout << "I1 active" << endl;
								cout << "B4 calling PPinte for I1 scannum="<<seqfamilies[i].ms1p[4].scannum << " seqfamilies[i].ms1p[4].mz_ms1=" << seqfamilies[i].ms1p[4].mz_ms1;
								cout << "   fname="<<seqfamilies[i].ms1p[4].rawfname <<endl;
								theXMLfname = ffolder; theXMLfname += seqfamilies[i].ms1p[4].rawfname;
								theXMLfname += tail;
								strcpy(XMLfname, theXMLfname.c_str());
								I1 = PPintegratorA(XMLfname, seqfamilies[i].ms1p[4].scannum, seqfamilies[i].ms1p[4].mz_ms1, 1,1,&starting_time, &end_time, &max_R_time, &max_scan_num,mz_error_calibrating_peak,num_of_KK,&real_maxx_scan_num,&real_maxx_inten, &max_s_inten, Q1);
							} else {
								cout << "I1 passive" << endl;
								starting_time = starting_time_i2;
								end_time= end_time_i2;
								max_R_time = max_R_time_i2;
								max_scan_num = max_scan_num_i2;
								light_max_scan_num =0;
								cout << "B4 calling PPinte for I1 scannum="<<seqfamilies[i].ms1p[4].scannum << " seqfamilies[i].ms1p[4].mz_ms1=" << seqfamilies[i].ms1p[4].mz_ms1;
								cout << "    fname="<<seqfamilies[i].ms1p[4].rawfname <<endl;
								theXMLfname = ffolder; theXMLfname += seqfamilies[i].ms1p[4].rawfname;
								theXMLfname += tail;
								strcpy(XMLfname, theXMLfname.c_str());
								I1 = PPintegratorB(XMLfname, max_scan_num, seqfamilies[i].ms1p[4].mz_ms1, 0,1, &starting_time, &end_time, &max_R_time, &light_max_scan_num,mz_error_calibrated_peak,num_of_KK,&real_maxx_scan_num,&real_maxx_inten, &max_s_inten, mass_dif_3DH, seqfamilies[i].ms1p[0].charge, Q2);
							}
							if (I1 < 0.0001) {
								if ((I1 < -0.999) && (I1 > -1.001)){
									cout << "The peak I1 (with given scannum) was not found. LN 2391" <<endl ;
									I1 = 0.000000;
								} else if ((I1 < -1.999) && (I1 > -8.001)) {
									continue;
								}
							}
							sh[4].max_R_time = max_R_time;
							sh[4].max_s_inten= max_s_inten;
							sh[4].starting_time = starting_time;
							sh[4].end_time= end_time;
							if (seqfamilies[i].ms1p[4].scannum !=-1) {
								cout << "GGGG,I1,"<<seqfamilies[i].familyseq<<"%"<<seqfamilies[i].ms1p[0].rawfname<<"%"<<seqfamilies[i].ms1p[0].charge<<","<<max_scan_num<<","<<I1<<",";
								printf("%10.5f\n", seqfamilies[i].ms1p[4].mz_ms1);
							} else {
								cout << "GGGG,I1,"<<seqfamilies[i].familyseq<<"%"<<seqfamilies[i].ms1p[0].rawfname<<"%"<<seqfamilies[i].ms1p[0].charge<<","<<light_max_scan_num<<","<<I1<<",";
								printf("%10.5f\n", seqfamilies[i].ms1p[4].mz_ms1);
							}
							cout << "Time of I1 " << starting_time <<" "<< max_R_time <<"  "<< end_time << endl;
							if (seqfamilies[i].ms1p[4].scannum !=-1) {
								cout << "afterI1,    max_scan_num= " << max_scan_num << endl;
							} else {
								cout << "afterI1,    max_scan_num= " << max_scan_num <<"    light_max_scan_num= " << light_max_scan_num<< endl;
							}	
						}//end of if (negligibleI4 = true)
					}//end of if (negligibleI3 = true)
				} else if ((seqfamilies[i].ms1p[4].MS2exist_indicator== 1) && (seqfamilies[i].ms1p[4].scannum !=-1)){ // I1:LN2802 , I2:2638, I3:2390  I5:1897
					//I1 ms2 =1, I1 ms1=1
					cout << "it is impossible. I quit!" << endl;
					continue;
				} // I1:LN2802 , I2:2638, I3:2390  I5:1897
				
			}///end of if ((seqfamilies[i].ms1p[1].MS2exist_indicator== 0) && (seqfamilies[i].ms1p[1].scannum ==-1 ))

			

			if ((seqfamilies[i].ms1p[1].MS2exist_indicator== 1) && (seqfamilies[i].ms1p[1].scannum !=-1 )) {
				//I4 active
				cout << "active I4" << endl;
				cout << "B4 calling PPinte for I4 scannum="<<seqfamilies[i].ms1p[1].scannum << " mz_ms1=" << seqfamilies[i].ms1p[1].mz_ms1;                         
				cout << " fname="<<seqfamilies[i].ms1p[1].rawfname <<endl;
				theXMLfname = ffolder; theXMLfname += seqfamilies[i].ms1p[1].rawfname;
				theXMLfname += tail;
				strcpy(XMLfname, theXMLfname.c_str());
				I4 = PPintegratorA(XMLfname, seqfamilies[i].ms1p[1].scannum, seqfamilies[i].ms1p[1].mz_ms1, 1,1,&starting_time, &end_time, &max_R_time, &max_scan_num,mz_error_calibrating_peak,num_of_KK,&real_maxx_scan_num,&real_maxx_inten, &max_s_inten, Q4);

				if (I4 < 0.0001) {
					if ((I4 < -0.999) && (I4 > -1.001)){
						cout << "The peak I4 (with given scannum) was not found. LN 2378" <<endl ;
						I4 = 0.0000;
					} else if ((I4 < -1.999) && (I4 > -8.001)) {
						continue;
					}
				}
				sh[1].max_R_time = max_R_time;
				sh[1].max_s_inten= max_s_inten;
				sh[1].starting_time = starting_time;
				sh[1].end_time= end_time;
				cout << "GGGG,I4,"<<seqfamilies[i].familyseq<<"%"<<seqfamilies[i].ms1p[0].rawfname<<"%"<<seqfamilies[i].ms1p[0].charge<<","<<max_scan_num<<","<<I4<<",";
				printf("%10.5f\n", seqfamilies[i].ms1p[1].mz_ms1);
				cout << "Time of I4 " << starting_time <<" "<< max_R_time <<"  "<< end_time << endl;
				cout << "afterI4, max_scan_num= " << max_scan_num <<endl;
				starting_time_i4 = starting_time;
				end_time_i4 = end_time;
				max_R_time_i4= max_R_time;
				max_scan_num_i4= max_scan_num;
				
				if ((seqfamilies[i].ms1p[2].MS2exist_indicator== 1) && (seqfamilies[i].ms1p[2].scannum !=-1)){  // end of I5 ms1==1   // (I3 ms2 ==1 && I3 ms1 ==1 ) {
					cout << "active I3" << endl;
					cout << "B4 calling PPinte for I3 scannum="<<seqfamilies[i].ms1p[2].scannum << " mz_ms1=" << seqfamilies[i].ms1p[2].mz_ms1;                         
					cout << " fname="<<seqfamilies[i].ms1p[2].rawfname <<endl;
					theXMLfname = ffolder; theXMLfname += seqfamilies[i].ms1p[2].rawfname;
					theXMLfname += tail;
					strcpy(XMLfname, theXMLfname.c_str());              
					I3 = PPintegratorA(XMLfname, seqfamilies[i].ms1p[2].scannum, seqfamilies[i].ms1p[2].mz_ms1, 1,1,&starting_time, &end_time, &max_R_time, &max_scan_num,mz_error_calibrating_peak,num_of_KK,&real_maxx_scan_num,&real_maxx_inten, &max_s_inten, Q3);

					if (I3 < 0.0001) {
						if ((I3 < -0.999) && (I3 > -1.001)){
							cout << "The peak I3 (with given scannum) was not found. LN 2403" <<endl ;
							I3 = 0.0000;
						} else if ((I3 < -1.999) && (I3 > -8.001)) {
							continue;
						} else if ((I3 < -19.999)&& (I3 > -20.001)) {
							return 0; //cannot open the file. exit                                                                                                                                                  
						}
					}
					sh[2].max_R_time = max_R_time;
					sh[2].max_s_inten= max_s_inten;
					sh[2].starting_time = starting_time;
					sh[2].end_time= end_time;
					cout << "GGGG,I3,"<<seqfamilies[i].familyseq<<"%"<<seqfamilies[i].ms1p[0].rawfname<<"%"<<seqfamilies[i].ms1p[0].charge<<","<<max_scan_num<<","<<I3<<",";
					printf("%10.5f\n", seqfamilies[i].ms1p[2].mz_ms1);

					cout << "Time of I3 " << starting_time <<" "<< max_R_time <<"  "<< end_time << endl;
					cout << "afterI3, max_scan_num= " << max_scan_num <<endl;
					starting_time_i3 = starting_time;
					end_time_i3 = end_time;
					max_R_time_i3= max_R_time;
					max_scan_num_i3= max_scan_num;

					//BLOCK_I2I1
					if (seqfamilies[i].ms1p[3].MS2exist_indicator == 0) {
						//passive cal I2
						cout << "I2 passive" << endl;
						cout << "B4 calling PPinte for I2 scannum="<<seqfamilies[i].ms1p[3].scannum << " seqfamilies[i].ms1p[3].mz_ms1=" << seqfamilies[i].ms1p[3].mz_ms1;
						cout << "    fname="<<seqfamilies[i].ms1p[3].rawfname <<endl;
						theXMLfname = ffolder; theXMLfname += seqfamilies[i].ms1p[3].rawfname;
						theXMLfname += tail;
						strcpy(XMLfname, theXMLfname.c_str());
						light_max_scan_num =0;
						if (I4 > 2*I3) {
							cout << "using I4 result to set up I2's time limits" <<endl;
							starting_time = starting_time_i4;
							end_time= end_time_i4;
							max_R_time = max_R_time_i4;
							max_scan_num = max_scan_num_i4;
							I2 = PPintegratorB(XMLfname, max_scan_num, seqfamilies[i].ms1p[3].mz_ms1, 0,1, &starting_time, &end_time, &max_R_time, &light_max_scan_num,mz_error_calibrated_peak,num_of_KK,&real_maxx_scan_num,&real_maxx_inten, &max_s_inten, 2*mass_dif_3DH, seqfamilies[i].ms1p[0].charge, Q4);
						} else {
							cout << "using I3 result to set up I2's time limits" <<endl;
							light_max_scan_num =0;
							I2 = PPintegratorB(XMLfname, max_scan_num, seqfamilies[i].ms1p[3].mz_ms1, 0,1, &starting_time, &end_time, &max_R_time, &light_max_scan_num,mz_error_calibrated_peak,num_of_KK,&real_maxx_scan_num,&real_maxx_inten, &max_s_inten, mass_dif_3DH, seqfamilies[i].ms1p[0].charge, Q3);
						}

						negligibleI2 = false;
						if (I2 < 0.0001) {
							if ((I2 < -0.999) && (I2 > -1.001)) {
								cout << "The peak I2 (with given scannum) was not found. LN 2434" <<endl ;
								negligibleI2 = true;
							} else if ((I2 < -1.999) && (I2 > -8.001)) {
								continue; // peak is there but cannot get the value! dump!
							}
						}
						if (negligibleI2 == false) {
							cout << "Time of I2 " << starting_time <<" "<< max_R_time <<"  "<< end_time << endl;
							cout << "afterI2,    max_scan_num= " << max_scan_num <<"   light_max_scan_num= " << light_max_scan_num << endl;
							cout << "real_maxx_scan_num for background test is "<< real_maxx_scan_num << endl;
							threshold= 3 * noise_level(XMLfname, real_maxx_scan_num);
							cout << "threshold=" <<threshold<<"  real_maxx_inten=" << real_maxx_inten <<endl;
							if (real_maxx_inten > threshold) {
								cout << "I2 apex larger than background noise but sequence is not in MS2 dictionary. dump." << endl;
								continue;
							} else {
								negligibleI2 = true;
							}
						}
						sh[3].max_R_time = max_R_time;
						sh[3].max_s_inten= max_s_inten;
						sh[3].starting_time = starting_time;
						sh[3].end_time= end_time;

						if (negligibleI2 == true) {//if ( (I2 == 0.00) || (I2 <= threshold) ) {
							I2=0.000000;
							cout << "GGGG,I2,"<<seqfamilies[i].familyseq<<"%"<<seqfamilies[i].ms1p[0].rawfname<<"%"<<seqfamilies[i].ms1p[0].charge<<","<<light_max_scan_num<<","<<0.000<<",";
							printf("%10.5f\n", seqfamilies[i].ms1p[3].mz_ms1);
							//cal I1
							if (seqfamilies[i].ms1p[4].scannum !=-1) {
								cout << "I1 active" << endl;
								cout << "B4 calling PPinte for I1 scannum="<<seqfamilies[i].ms1p[4].scannum << " seqfamilies[i].ms1p[4].mz_ms1=" << seqfamilies[i].ms1p[4].mz_ms1;
								cout << "   fname="<<seqfamilies[i].ms1p[4].rawfname <<endl;
								theXMLfname = ffolder; theXMLfname += seqfamilies[i].ms1p[4].rawfname;
								theXMLfname += tail;
								strcpy(XMLfname, theXMLfname.c_str());			    
								I1 = PPintegratorA(XMLfname, seqfamilies[i].ms1p[4].scannum, seqfamilies[i].ms1p[4].mz_ms1, 1,1,&starting_time, &end_time, &max_R_time, &max_scan_num,mz_error_calibrating_peak,num_of_KK,&real_maxx_scan_num,&real_maxx_inten, &max_s_inten, Q1);

							} else {
								cout << "I1 passive" << endl;
								light_max_scan_num =0;
								cout << "B4 calling PPinte for I1 scannum="<<seqfamilies[i].ms1p[4].scannum << " seqfamilies[i].ms1p[4].mz_ms1=" << seqfamilies[i].ms1p[4].mz_ms1;
								cout << "    fname="<<seqfamilies[i].ms1p[4].rawfname <<endl;
								theXMLfname = ffolder; theXMLfname += seqfamilies[i].ms1p[4].rawfname;
								theXMLfname += tail;
								strcpy(XMLfname, theXMLfname.c_str());
								if (I4 > 2*I3) {
									cout << "using I4 result to set up I1's time limits" <<endl;
									starting_time = starting_time_i4;
									end_time= end_time_i4;
									max_R_time = max_R_time_i4;
									max_scan_num = max_scan_num_i4;
									I1 = PPintegratorB(XMLfname, max_scan_num, seqfamilies[i].ms1p[4].mz_ms1, 0,1, &starting_time, &end_time, &max_R_time, &light_max_scan_num,mz_error_calibrated_peak,num_of_KK,&real_maxx_scan_num,&real_maxx_inten, &max_s_inten, 3*mass_dif_3DH, seqfamilies[i].ms1p[0].charge, Q4);
								} else {
									cout << "using I3 result to set up I1's time limits" <<endl;
									starting_time = starting_time_i3;
									end_time= end_time_i3;
									max_R_time = max_R_time_i3;
									max_scan_num = max_scan_num_i3;
									I1 = PPintegratorB(XMLfname, max_scan_num, seqfamilies[i].ms1p[4].mz_ms1, 0,1, &starting_time, &end_time, &max_R_time, &light_max_scan_num,mz_error_calibrated_peak,num_of_KK,&real_maxx_scan_num,&real_maxx_inten, &max_s_inten, 2*mass_dif_3DH, seqfamilies[i].ms1p[0].charge, Q3);
								}

							}
							if (I1 < 0.0001) {
								if ((I1 < -0.999) && (I1 > -1.001)){
									cout << "The peak I1 (with given scannum) was not found. LN 2596" <<endl ;
									I1 = 0.000000;
								} else if ((I1 < -1.999) && (I1 > -8.001)) {
									continue;
								}
							}
							sh[4].max_R_time = max_R_time;
							sh[4].max_s_inten= max_s_inten;
							sh[4].starting_time = starting_time;
							sh[4].end_time= end_time;
							if (seqfamilies[i].ms1p[4].scannum !=-1) {
								cout << "GGGG,I1,"<<seqfamilies[i].familyseq<<"%"<<seqfamilies[i].ms1p[0].rawfname<<"%"<<seqfamilies[i].ms1p[0].charge<<","<<max_scan_num<<","<<I1<<",";
								printf("%10.5f\n", seqfamilies[i].ms1p[4].mz_ms1);
							} else {
								cout << "GGGG,I1,"<<seqfamilies[i].familyseq<<"%"<<seqfamilies[i].ms1p[0].rawfname<<"%"<<seqfamilies[i].ms1p[0].charge<<","<<light_max_scan_num<<","<<I1<<",";
								printf("%10.5f\n", seqfamilies[i].ms1p[4].mz_ms1);
							}
							cout << "Time of I1 " << starting_time <<" "<< max_R_time <<"  "<< end_time << endl;
							if (seqfamilies[i].ms1p[4].scannum !=-1) {
								cout << "afterI1,    max_scan_num= " << max_scan_num << endl;
							} else {
								cout << "afterI1,    max_scan_num= " << max_scan_num <<"    light_max_scan_num= " << light_max_scan_num<< endl;
							}
						}//end of if (negligibleI2 == true)
					} else { //active cal I2, then I1 //assume: if it is in dictionary, it should be given scannum.
						if (seqfamilies[i].ms1p[3].scannum ==-1) { cout << "WRONG ASSUMPTION HERE.YOU SHOULD CORRECT YOU CODE.";
							cout << "You need to consider case in which scannum is not given for I2 LN 2611-2630" << endl; return 0;
						}
						cout << "I2 active" << endl;
						cout << "B4 calling PPinte for I2 scannum="<< seqfamilies[i].ms1p[3].scannum << " seqfamilies[i].ms1p[3].mz_ms1=" << seqfamilies[i].ms1p[3].mz_ms1;
						cout << "    fname="<<seqfamilies[i].ms1p[3].rawfname <<endl;
						theXMLfname = ffolder; theXMLfname += seqfamilies[i].ms1p[3].rawfname;
						theXMLfname += tail;
						strcpy(XMLfname, theXMLfname.c_str());
						I2 = PPintegratorA(XMLfname, seqfamilies[i].ms1p[3].scannum, seqfamilies[i].ms1p[3].mz_ms1, 1,1,&starting_time, &end_time, &max_R_time, &max_scan_num,mz_error_calibrating_peak,num_of_KK,&real_maxx_scan_num,&real_maxx_inten, &max_s_inten, Q2);

						if (I2 < 0.0001) {
							if ((I2 < -0.999) && (I2 > -1.001)){
								cout << "The peak I2 (with given scannum) was not found. LN 1748" <<endl ;
								I2 = 0.0000;
							} else if ((I2 < -1.999) && (I2 > -8.001)) {
								continue; // peak is there but cannot get the value! dump!
							}
						}
						sh[3].max_R_time = max_R_time;
						sh[3].max_s_inten= max_s_inten;
						sh[3].starting_time = starting_time;
						sh[3].end_time= end_time;
						cout << "GGGG,I2,"<<seqfamilies[i].familyseq<<"%"<<seqfamilies[i].ms1p[0].rawfname<<"%"<<seqfamilies[i].ms1p[0].charge<<","<<max_scan_num<<","<<I2<<",";
						printf("%10.5f\n", seqfamilies[i].ms1p[3].mz_ms1);
						cout << "Time of I2 " << starting_time <<" "<< max_R_time <<"  "<< end_time << endl;
						cout << "afterI2,    max_scan_num= " << max_scan_num << endl;
						if (seqfamilies[i].ms1p[4].scannum !=-1) {
							cout << "I1 active" << endl;
							cout << "B4 calling PPinte for I1 scannum="<<seqfamilies[i].ms1p[4].scannum << " seqfamilies[i].ms1p[4].mz_ms1=" << seqfamilies[i].ms1p[4].mz_ms1;
							cout << "   fname="<<seqfamilies[i].ms1p[4].rawfname <<endl;
							theXMLfname = ffolder; theXMLfname += seqfamilies[i].ms1p[4].rawfname;
							theXMLfname += tail;
							strcpy(XMLfname, theXMLfname.c_str());
							I1 = PPintegratorA(XMLfname, seqfamilies[i].ms1p[4].scannum, seqfamilies[i].ms1p[4].mz_ms1, 1,1,&starting_time, &end_time, &max_R_time, &max_scan_num,mz_error_calibrating_peak,num_of_KK,&real_maxx_scan_num,&real_maxx_inten, &max_s_inten, Q1);
							
						} else {
							cout << "I1 passive" << endl;
							light_max_scan_num =0;
							cout << "B4 calling PPinte for I1 scannum="<<seqfamilies[i].ms1p[4].scannum << " seqfamilies[i].ms1p[4].mz_ms1=" << seqfamilies[i].ms1p[4].mz_ms1;
							cout << "    fname="<<seqfamilies[i].ms1p[4].rawfname <<endl;
							theXMLfname = ffolder; theXMLfname += seqfamilies[i].ms1p[4].rawfname;
							theXMLfname += tail;
							strcpy(XMLfname, theXMLfname.c_str());
							if ((I4 > 2*I3) && (I4 > 2*I2)) {
								cout << "using I4 result to set up I1's time limits" <<endl;
								starting_time = starting_time_i4;
								end_time= end_time_i4;
								max_R_time = max_R_time_i4;
								max_scan_num = max_scan_num_i4;
								I1 = PPintegratorB(XMLfname, max_scan_num, seqfamilies[i].ms1p[4].mz_ms1, 0,1, &starting_time, &end_time, &max_R_time, &light_max_scan_num,mz_error_calibrated_peak,num_of_KK,&real_maxx_scan_num,&real_maxx_inten, &max_s_inten, 3*mass_dif_3DH, seqfamilies[i].ms1p[0].charge, Q4);
							} else if (I3 > I2) {
								cout << "using I3 result to set up I1's time limits" <<endl;
								starting_time = starting_time_i3;
								end_time= end_time_i3;
								max_R_time = max_R_time_i3;
								max_scan_num = max_scan_num_i3;
								I1 = PPintegratorB(XMLfname, max_scan_num, seqfamilies[i].ms1p[4].mz_ms1, 0,1, &starting_time, &end_time, &max_R_time, &light_max_scan_num,mz_error_calibrated_peak,num_of_KK,&real_maxx_scan_num,&real_maxx_inten, &max_s_inten, 2*mass_dif_3DH, seqfamilies[i].ms1p[0].charge, Q3);
							} else { 
								cout << "using I2 result to set up I1's time limits" <<endl;
								I1 = PPintegratorB(XMLfname, max_scan_num, seqfamilies[i].ms1p[4].mz_ms1, 0,1, &starting_time, &end_time, &max_R_time, &light_max_scan_num,mz_error_calibrated_peak,num_of_KK,&real_maxx_scan_num,&real_maxx_inten, &max_s_inten, mass_dif_3DH, seqfamilies[i].ms1p[0].charge, Q2);
								
							}
						}
						if (I1 < 0.0001) {
							if ((I1 < -0.999) && (I1 > -1.001)){
								cout << "The peak I1 (with given scannum) was not found. LN 2662" <<endl ;
								I1 = 0.000000;
							} else if ((I1 < -1.999) && (I1 > -8.001)) {			    
								continue;
							}
						}
						sh[4].max_R_time = max_R_time;
						sh[4].max_s_inten= max_s_inten;
						sh[4].starting_time = starting_time;
						sh[4].end_time= end_time;
						if (seqfamilies[i].ms1p[4].scannum !=-1) {
							cout << "GGGG,I1,"<<seqfamilies[i].familyseq<<"%"<<seqfamilies[i].ms1p[0].rawfname<<"%"<<seqfamilies[i].ms1p[0].charge<<","<<max_scan_num<<","<<I1<<",";
							printf("%10.5f\n", seqfamilies[i].ms1p[4].mz_ms1);
						} else {
							cout << "GGGG,I1,"<<seqfamilies[i].familyseq<<"%"<<seqfamilies[i].ms1p[0].rawfname<<"%"<<seqfamilies[i].ms1p[0].charge<<","<<light_max_scan_num<<","<<I1<<",";
							printf("%10.5f\n", seqfamilies[i].ms1p[4].mz_ms1);
						}
						cout << "Time of I1 " << starting_time <<" "<< max_R_time <<"  "<< end_time << endl;
						if (seqfamilies[i].ms1p[4].scannum !=-1) {
							cout << "afterI1,    max_scan_num= " << max_scan_num << endl;
						} else {
							cout << "afterI1,    max_scan_num= " << max_scan_num <<"    light_max_scan_num= " << light_max_scan_num<< endl;
						}
					}
					//END OF BLOCK_I2I1 

				} else { //I3 active/passive
					cout << "I3 passive" << endl;
					starting_time = starting_time_i4;
					end_time= end_time_i4;
					max_R_time = max_R_time_i4;
					max_scan_num = max_scan_num_i4;
					light_max_scan_num =0;
					cout << "B4 calling PPinte for I3 scannum="<<seqfamilies[i].ms1p[2].scannum << " seqfamilies[i].ms1p[2].mz_ms1=" << seqfamilies[i].ms1p[2].mz_ms1;
					cout << "    fname="<<seqfamilies[i].ms1p[2].rawfname <<endl;
					theXMLfname = ffolder; theXMLfname += seqfamilies[i].ms1p[2].rawfname;
					theXMLfname += tail;
					strcpy(XMLfname, theXMLfname.c_str());
					cout << "using I4 result to set up I3's time limits" <<endl;
					I3 = PPintegratorB(XMLfname, max_scan_num, seqfamilies[i].ms1p[2].mz_ms1, 0,1, &starting_time, &end_time, &max_R_time, &light_max_scan_num,mz_error_calibrated_peak,num_of_KK,&real_maxx_scan_num,&real_maxx_inten, &max_s_inten, mass_dif_3DH, seqfamilies[i].ms1p[0].charge, Q4);

					negligibleI3 = false;
					if (I3 < 0.0001) {
						if ((I3 < -0.999) && (I3 > -1.001)) {
							cout << "The peak I3 (with given scannum) was not found. LN 1633" <<endl ;
							negligibleI3 = true;
						} else if ((I3 < -1.999) && (I3 > -8.001)) {
							continue; // peak is there but cannot get the value! dump!
						}
					}
					if (negligibleI3 == false) {
						cout << "Time of I3 " << starting_time <<" "<< max_R_time <<"  "<< end_time << endl;
						cout << "afterI3, max_scan_num= " << max_scan_num<<"   light_max_scan_num= " << light_max_scan_num <<endl;
						cout << "real_maxx_scan_num for background test is "<< real_maxx_scan_num << endl;
						threshold= 3 * noise_level(XMLfname, real_maxx_scan_num);
						cout << "threshold=" <<threshold<<"  real_maxx_inten=" << real_maxx_inten <<endl;
						if (real_maxx_inten > threshold) {
							cout << "I3 apex larger than background noise but sequence is not in MS2 dictionary. dump." << endl;
							continue;
						} else {
							negligibleI3 = true;
						}
					}
					sh[2].max_R_time = max_R_time;
					sh[2].max_s_inten= max_s_inten;
					sh[2].starting_time = starting_time;
					sh[2].end_time= end_time;

					if (negligibleI3 == true) {
						I3 = 0.000000;
						cout << "GGGG,I3,"<<seqfamilies[i].familyseq<<"%"<<seqfamilies[i].ms1p[0].rawfname<<"%"<<seqfamilies[i].ms1p[0].charge<<","<<light_max_scan_num<<","<<0.00<<",";
						printf("%10.5f\n", seqfamilies[i].ms1p[2].mz_ms1);
						//BLOCK_I2I1
						if (seqfamilies[i].ms1p[3].MS2exist_indicator == 0) {
							//passive cal I2
							cout << "I2 passive" << endl;
							starting_time = starting_time_i4;
							end_time= end_time_i4;
							max_R_time = max_R_time_i4;
							max_scan_num = max_scan_num_i4;
							light_max_scan_num =0;
							cout << "B4 calling PPinte for I2 scannum="<<seqfamilies[i].ms1p[3].scannum << " seqfamilies[i].ms1p[3].mz_ms1=" << seqfamilies[i].ms1p[3].mz_ms1;
							cout << "    fname="<<seqfamilies[i].ms1p[3].rawfname <<endl;
							theXMLfname = ffolder; theXMLfname += seqfamilies[i].ms1p[3].rawfname;
							theXMLfname += tail;
							strcpy(XMLfname, theXMLfname.c_str());
							cout << "using I4 result to set up I2's time limits" <<endl;
							I2 = PPintegratorB(XMLfname, max_scan_num, seqfamilies[i].ms1p[3].mz_ms1, 0,1, &starting_time, &end_time, &max_R_time, &light_max_scan_num,mz_error_calibrated_peak,num_of_KK,&real_maxx_scan_num,&real_maxx_inten, &max_s_inten, 2*mass_dif_3DH, seqfamilies[i].ms1p[0].charge, Q4);

							negligibleI2 = false;
							if (I2 < 0.0001) {
								if ((I2 < -0.999) && (I2 > -1.001)) {
									cout << "The peak I2 (with given scannum) was not found. LN 1674" <<endl ;
									negligibleI2 = true;
								} else if ((I2 < -1.999) && (I2 > -8.001)) {
									continue; // peak is there but cannot get the value! dump!
								}
							}
							if (negligible == false) {
								cout << "Time of I2 " << starting_time <<" "<< max_R_time <<"  "<< end_time << endl;
								cout << "afterI2,    max_scan_num= " << max_scan_num <<"   light_max_scan_num= " << light_max_scan_num << endl;
								cout << "real_maxx_scan_num for background test is "<< real_maxx_scan_num << endl;
								threshold= 3 * noise_level(XMLfname, real_maxx_scan_num);
								cout << "threshold=" <<threshold<<"  real_maxx_inten=" << real_maxx_inten <<endl;
								if (real_maxx_inten > threshold) {
									cout << "I2 apex larger than background noise but sequence is not in MS2 dictionary. dump." << endl;
									continue;
								} else {
									negligibleI2 = true;
								}
							}
							sh[3].max_R_time = max_R_time;
							sh[3].max_s_inten= max_s_inten;
							sh[3].starting_time = starting_time;
							sh[3].end_time= end_time;

							if (negligibleI2 == true) {//if ( (I2 == 0.00) || (I2 <= threshold) ) {
								I2=0.000000;
								cout << "GGGG,I2,"<<seqfamilies[i].familyseq<<"%"<<seqfamilies[i].ms1p[0].rawfname<<"%"<<seqfamilies[i].ms1p[0].charge<<","<<light_max_scan_num<<","<<0.000<<",";
								printf("%10.5f\n", seqfamilies[i].ms1p[3].mz_ms1);
								//cal I1
								if (seqfamilies[i].ms1p[4].scannum !=-1) {
									cout << "I1 active" << endl;
									cout << "B4 calling PPinte for I1 scannum="<<seqfamilies[i].ms1p[4].scannum << " seqfamilies[i].ms1p[4].mz_ms1=" << seqfamilies[i].ms1p[4].mz_ms1;
									cout << "   fname="<<seqfamilies[i].ms1p[4].rawfname <<endl;
									theXMLfname = ffolder; theXMLfname += seqfamilies[i].ms1p[4].rawfname;
									theXMLfname += tail;
									strcpy(XMLfname, theXMLfname.c_str());
									I1 = PPintegratorA(XMLfname, seqfamilies[i].ms1p[4].scannum, seqfamilies[i].ms1p[4].mz_ms1, 1,1,&starting_time, &end_time, &max_R_time, &max_scan_num,mz_error_calibrating_peak,num_of_KK,&real_maxx_scan_num,&real_maxx_inten, &max_s_inten, Q1);

								} else {
									cout << "I1 passive" << endl;
									starting_time = starting_time_i4;
									end_time= end_time_i4;
									max_R_time = max_R_time_i4;
									max_scan_num = max_scan_num_i4;
									light_max_scan_num =0;
									cout << "B4 calling PPinte for I1 scannum="<<seqfamilies[i].ms1p[4].scannum << " seqfamilies[i].ms1p[4].mz_ms1=" << seqfamilies[i].ms1p[4].mz_ms1;
									cout << "    fname="<<seqfamilies[i].ms1p[4].rawfname <<endl;
									theXMLfname = ffolder; theXMLfname += seqfamilies[i].ms1p[4].rawfname;
									theXMLfname += tail;
									strcpy(XMLfname, theXMLfname.c_str());
									cout << "using I4 result to set up I2's time limits" <<endl;
									I1 = PPintegratorB(XMLfname, max_scan_num, seqfamilies[i].ms1p[4].mz_ms1, 0,1, &starting_time, &end_time, &max_R_time, &light_max_scan_num,mz_error_calibrated_peak,num_of_KK,&real_maxx_scan_num,&real_maxx_inten, &max_s_inten, 3*mass_dif_3DH, seqfamilies[i].ms1p[0].charge, Q4);

								}
								if (I1 < 0.0001) {
									if ((I1 < -0.999) && (I1 > -1.001)){
										cout << "The peak I1 (with given scannum) was not found. LN 2785" <<endl ;
										I1 = 0.000000;
									} else if ((I1 < -1.999) && (I1 > -8.001)) {
										continue;
									}
								}
								sh[4].max_R_time = max_R_time;
								sh[4].max_s_inten= max_s_inten;
								sh[4].starting_time = starting_time;
								sh[4].end_time= end_time;
								if (seqfamilies[i].ms1p[4].scannum !=-1) {
									cout << "GGGG,I1,"<<seqfamilies[i].familyseq<<"%"<<seqfamilies[i].ms1p[0].rawfname<<"%"<<seqfamilies[i].ms1p[0].charge<<","<<max_scan_num<<","<<I1<<",";
									printf("%10.5f\n", seqfamilies[i].ms1p[4].mz_ms1);
								} else {
									cout << "GGGG,I1,"<<seqfamilies[i].familyseq<<"%"<<seqfamilies[i].ms1p[0].rawfname<<"%"<<seqfamilies[i].ms1p[0].charge<<","<<light_max_scan_num<<","<<I1<<",";
									printf("%10.5f\n", seqfamilies[i].ms1p[4].mz_ms1);
								}
								cout << "Time of I1 " << starting_time <<" "<< max_R_time <<"  "<< end_time << endl;
								if (seqfamilies[i].ms1p[4].scannum !=-1) {
									cout << "afterI1,    max_scan_num= " << max_scan_num << endl;
								} else {
									cout << "afterI1,    max_scan_num= " << max_scan_num <<"    light_max_scan_num= " << light_max_scan_num<< endl;
								}
							}//end of if (negligibleI2 == true)
						} else { //active cal I2, then I1 //assume: if it is in dictionary, it should be given scannum.
							if (seqfamilies[i].ms1p[3].scannum ==-1) { cout << "WRONG ASSUMPTION HERE.YOU SHOULD CORRECT YOU CODE.";
								cout << "You need to consider case in which scannum is not given for I2 LN 1737-1800" << endl; return 0;
							}
							cout << "I2 active" << endl;
							cout << "B4 calling PPinte for I2 scannum="<< seqfamilies[i].ms1p[3].scannum << " seqfamilies[i].ms1p[3].mz_ms1=" << seqfamilies[i].ms1p[3].mz_ms1;
							cout << "    fname="<<seqfamilies[i].ms1p[3].rawfname <<endl;
							theXMLfname = ffolder; theXMLfname += seqfamilies[i].ms1p[3].rawfname;
							theXMLfname += tail;
							strcpy(XMLfname, theXMLfname.c_str());
							I2 = PPintegratorA(XMLfname, seqfamilies[i].ms1p[3].scannum, seqfamilies[i].ms1p[3].mz_ms1, 1,1,&starting_time, &end_time, &max_R_time, &max_scan_num,mz_error_calibrating_peak,num_of_KK,&real_maxx_scan_num,&real_maxx_inten, &max_s_inten, Q2);

							if (I2 < 0.0001) {
								if ((I2 < -0.999) && (I2 > -1.001)){
									cout << "The peak I2 (with given scannum) was not found. LN 1748" <<endl ;
									I2 = 0.0000;
								} else if ((I2 < -1.999) && (I2 > -8.001)) {
									continue; // peak is there but cannot get the value! dump!
								}
							}
							sh[3].max_R_time = max_R_time;
							sh[3].max_s_inten= max_s_inten;
							sh[3].starting_time = starting_time;
							sh[3].end_time= end_time;
							cout << "GGGG,I2,"<<seqfamilies[i].familyseq<<"%"<<seqfamilies[i].ms1p[0].rawfname<<"%"<<seqfamilies[i].ms1p[0].charge<<","<<max_scan_num<<","<<I2<<",";
							printf("%10.5f\n", seqfamilies[i].ms1p[3].mz_ms1);
							cout << "Time of I2 " << starting_time <<" "<< max_R_time <<"  "<< end_time << endl;
							cout << "afterI2,    max_scan_num= " << max_scan_num << endl;
							if (seqfamilies[i].ms1p[4].scannum !=-1) {
								cout << "I1 active" << endl;
								cout << "B4 calling PPinte for I1 scannum="<<seqfamilies[i].ms1p[4].scannum << " seqfamilies[i].ms1p[4].mz_ms1=" << seqfamilies[i].ms1p[4].mz_ms1;
								cout << "   fname="<<seqfamilies[i].ms1p[4].rawfname <<endl;
								theXMLfname = ffolder; theXMLfname += seqfamilies[i].ms1p[4].rawfname;
								theXMLfname += tail;
								strcpy(XMLfname, theXMLfname.c_str());
								I1 = PPintegratorA(XMLfname, seqfamilies[i].ms1p[4].scannum, seqfamilies[i].ms1p[4].mz_ms1, 1,1,&starting_time, &end_time, &max_R_time, &max_scan_num,mz_error_calibrating_peak,num_of_KK,&real_maxx_scan_num,&real_maxx_inten, &max_s_inten, Q1);

							} else {
								cout << "I1 passive" << endl;
								starting_time = starting_time_i4;
								end_time= end_time_i4;
								max_R_time = max_R_time_i4;
								max_scan_num = max_scan_num_i4;
								light_max_scan_num =0;
								cout << "B4 calling PPinte for I1 scannum="<<seqfamilies[i].ms1p[4].scannum << " seqfamilies[i].ms1p[4].mz_ms1=" << seqfamilies[i].ms1p[4].mz_ms1;
								cout << "    fname="<<seqfamilies[i].ms1p[4].rawfname <<endl;
								theXMLfname = ffolder; theXMLfname += seqfamilies[i].ms1p[4].rawfname;
								theXMLfname += tail;
								strcpy(XMLfname, theXMLfname.c_str());
								I1 = PPintegratorB(XMLfname, max_scan_num, seqfamilies[i].ms1p[4].mz_ms1, 0,1, &starting_time, &end_time, &max_R_time, &light_max_scan_num,mz_error_calibrated_peak,num_of_KK,&real_maxx_scan_num,&real_maxx_inten, &max_s_inten, 3*mass_dif_3DH, seqfamilies[i].ms1p[0].charge, Q4);

							}
							if (I1 < 0.0001) {
								if ((I1 < -0.999) && (I1 > -1.001)){
									cout << "The peak I1 (with given scannum) was not found. LN 2843" <<endl ;
									I1 = 0.000000;
								} else if ((I1 < -1.999) && (I1 > -8.001)) {
									continue;
								}
							}
							sh[4].max_R_time = max_R_time;
							sh[4].max_s_inten= max_s_inten;
							sh[4].starting_time = starting_time;
							sh[4].end_time= end_time;
							if (seqfamilies[i].ms1p[4].scannum !=-1) {
								cout << "GGGG,I1,"<<seqfamilies[i].familyseq<<"%"<<seqfamilies[i].ms1p[0].rawfname<<"%"<<seqfamilies[i].ms1p[0].charge<<","<<max_scan_num<<","<<I1<<",";
								printf("%10.5f\n", seqfamilies[i].ms1p[4].mz_ms1);
							} else {
								cout << "GGGG,I1,"<<seqfamilies[i].familyseq<<"%"<<seqfamilies[i].ms1p[0].rawfname<<"%"<<seqfamilies[i].ms1p[0].charge<<","<<light_max_scan_num<<","<<I1<<",";
								printf("%10.5f\n", seqfamilies[i].ms1p[4].mz_ms1);
							}
							cout << "Time of I1 " << starting_time <<" "<< max_R_time <<"  "<< end_time << endl;
							if (seqfamilies[i].ms1p[4].scannum !=-1) {
								cout << "afterI1,    max_scan_num= " << max_scan_num << endl;
							} else {
								cout << "afterI1,    max_scan_num= " << max_scan_num <<"    light_max_scan_num= " << light_max_scan_num<< endl;
							}
						}
						//END OF BLOCK_I2I1
						
					}
				}// I3 active/passive
				if (seqfamilies[i].ms1p[0].scannum !=-1){
					//active I5
					cout << "##active I5" << endl;
					cout << "B4 calling PPinte for I5 scannum="<<seqfamilies[i].ms1p[0].scannum << " mz_ms1=" << seqfamilies[i].ms1p[0].mz_ms1;                         
					cout << " fname="<<seqfamilies[i].ms1p[0].rawfname <<endl;
					theXMLfname = ffolder; theXMLfname += seqfamilies[i].ms1p[0].rawfname;
					theXMLfname += tail;
					strcpy(XMLfname, theXMLfname.c_str());              
					I5 = PPintegratorA(XMLfname, seqfamilies[i].ms1p[0].scannum, seqfamilies[i].ms1p[0].mz_ms1, 1,1,&starting_time, &end_time, &max_R_time, &max_scan_num,mz_error_calibrating_peak,num_of_KK,&real_maxx_scan_num,&real_maxx_inten, &max_s_inten, Q5);

					//print out some stuff to check
					if (I5 < 0.0001) {
						if ((I5 < -0.999) && (I5 > -1.001)){
							cout << "The peak I5 (with given scannum) was not found. LN 1562" <<endl ;
							I5 = 0.0000;
						} else if ((I5 < -1.999) && (I5 > -8.001)) {
							continue;
						} else if ((I5 < -19.999)&& (I5 > -20.001)) {
							return 0; //cannot open the file. exit          
						}
					}

				} else {  //start of I5 passive//if (seqfamilies[i].ms1p[0].scannum !=-1)
					cout << "passive I5" << endl;
					starting_time = starting_time_i4;
					end_time= end_time_i4;
					max_R_time = max_R_time_i4;
					max_scan_num = max_scan_num_i4;
					light_max_scan_num =0;
					cout << "B4 calling PPinte for I5 scannum="<<seqfamilies[i].ms1p[0].scannum << " seqfamilies[i].ms1p[0].mz_ms1=" << seqfamilies[i].ms1p[0].mz_ms1;
					cout << "    fname="<<seqfamilies[i].ms1p[0].rawfname <<endl;
					theXMLfname = ffolder; theXMLfname += seqfamilies[i].ms1p[0].rawfname;
					theXMLfname += tail;
					strcpy(XMLfname, theXMLfname.c_str());
					I5 = PPintegratorB(XMLfname, max_scan_num, seqfamilies[i].ms1p[0].mz_ms1, 0,0, &starting_time, &end_time, &max_R_time, &light_max_scan_num,mz_error_calibrated_peak,num_of_KK,&real_maxx_scan_num,&real_maxx_inten, &max_s_inten, mass_dif_3DH, seqfamilies[i].ms1p[0].charge, Q4);

					if (I5 < 0.0001) {
						if ((I5 < -0.999) && (I5 > -1.001)){
							cout << "The peak I5 (with given scannum) was not found. LN 1562" <<endl ;
							I5 = 0.0000;
						} else if ((I5 < -1.999) && (I5 > -8.001)) {
							continue;
						}
					}
				}  //end of I5 passive

				if (seqfamilies[i].ms1p[0].scannum !=-1) {
					cout << "GGGG,I5,"<<seqfamilies[i].familyseq<<"%"<<seqfamilies[i].ms1p[0].rawfname<<"%"<<seqfamilies[i].ms1p[0].charge<<","<<max_scan_num<<","<<I5<<",";
					printf("%10.5f\n", seqfamilies[i].ms1p[0].mz_ms1);
				} else {
					cout << "GGGG,I5,"<<seqfamilies[i].familyseq<<"%"<<seqfamilies[i].ms1p[0].rawfname<<"%"<<seqfamilies[i].ms1p[0].charge<<","<<light_max_scan_num<<","<<I5<<",";
					printf("%10.5f\n", seqfamilies[i].ms1p[0].mz_ms1);
				}
				sh[0].max_R_time = max_R_time;
				sh[0].max_s_inten= max_s_inten;
				sh[0].starting_time = starting_time;
				sh[0].end_time= end_time;
				cout << "Time of I5 " << starting_time <<" "<< max_R_time <<"  "<< end_time << endl;
				cout << "afterI5,    max_scan_num= " << max_scan_num << endl;

			}// end of else if ((seqfamilies[i].ms1p[1].MS2exist_indicator== 1) && (seqfamilies[i].ms1p[1].scannum !=-1 ))

			alphaL_frac[0]=0.000;
			betaL_frac[0]=0.000;
			gammaL_frac[0]=0.000;
			deltaL_frac[0]=0.000;
			alphaL_frac[1]=0.000;
			betaL_frac[1]=0.000;
			gammaL_frac[1]=0.000;
			deltaL_frac[1]=0.000;
			alphaL_frac[2]=0.000;
			betaL_frac[2]=0.000;
			gammaL_frac[2]=0.000;
			deltaL_frac[2]=0.000;

			for (j=0; j<dictionary.size(); j++) {
				if (seqfamilies[i].familyseq.compare(dictionary[j].familyseq)==0){
					if (seqfamilies[i].ms1p[2].MS2exist_indicator== 1){//I2
						for (jj=0; jj<dictionary[j].peak.size(); jj++) {
							if ( dictionary[j].peak[jj].ms1peak_order == 2 ) { //looking for I2
								//for (k=0; k<dictionary[j].peak[jj].GreekL_frac.size(); k++){
								alphaL_frac[0] = dictionary[j].peak[jj].GreekL_frac[0];
								betaL_frac[0]  = dictionary[j].peak[jj].GreekL_frac[1];
								gammaL_frac[0] = dictionary[j].peak[jj].GreekL_frac[2];
								deltaL_frac[0] = dictionary[j].peak[jj].GreekL_frac[3];
								//}
								break;
							}
						}//for jj
					}
					if (seqfamilies[i].ms1p[1].MS2exist_indicator== 1){ //I3
						for (jj=0; jj<dictionary[j].peak.size(); jj++) {
							if ( dictionary[j].peak[jj].ms1peak_order == 3 ) { //looking for I3
								//for (k=0; k<dictionary[j].peak[jj].GreekL_frac.size(); k++){
								alphaL_frac[1] = dictionary[j].peak[jj].GreekL_frac[0];
								betaL_frac[1]  = dictionary[j].peak[jj].GreekL_frac[1];
								gammaL_frac[1] = dictionary[j].peak[jj].GreekL_frac[2];
								deltaL_frac[1] = dictionary[j].peak[jj].GreekL_frac[3];
								//}
								break;
							}
						}//for jj
					}

					if (seqfamilies[i].ms1p[1].MS2exist_indicator== 1){ //I3
						for (jj=0; jj<dictionary[j].peak.size(); jj++) {
							if ( dictionary[j].peak[jj].ms1peak_order == 4 ) { //looking for I3
								//for (k=0; k<dictionary[j].peak[jj].GreekL_frac.size(); k++){
								alphaL_frac[2] = dictionary[j].peak[jj].GreekL_frac[0];
								betaL_frac[2]  = dictionary[j].peak[jj].GreekL_frac[1];
								gammaL_frac[2] = dictionary[j].peak[jj].GreekL_frac[2];
								deltaL_frac[2] = dictionary[j].peak[jj].GreekL_frac[3];
								//}
								break;
							}
						}//for jj
					}

					break;
				}// if familyseq are the same
			}//for j

			cout << "I1=" << I1 <<"     I2="<< I2 <<"     I3="<< I3 <<"     I4="<< I4 <<"     I5="<< I5 << "  beta"<<endl;
			cout << "alphaL_frac[0]=" << alphaL_frac[0] << "       betaL_frac[0]=" << betaL_frac[0] << endl;
			cout << "alphaL_frac[1]=" << alphaL_frac[1] << "       betaL_frac[1]=" << betaL_frac[1] << endl;
			cout << "alphaL_frac[2]=" << alphaL_frac[2] << "       betaL_frac[2]=" << betaL_frac[2] << endl;
			if (I1==-1) {I1=0.0000;}
			if (I2==-1) {I2=0.0000;}
			if (I3==-1) {I3=0.0000;}
			if (I4==-1) {I4=0.0000;}
			if (I5==-1) {I5=0.0000;}
			total_alphaL=(I1 +I2*alphaL_frac[0] +I3*alphaL_frac[1] +I4*alphaL_frac[2])/(I1+I2+I3+I4+I5);
			total_betaL= (I1 +I2*betaL_frac[0]  +I3*betaL_frac[1]  +I4*betaL_frac[2] )/(I1+I2+I3+I4+I5);
			total_gammaL=(I1 +I2*gammaL_frac[0] +I3*gammaL_frac[1] +I4*gammaL_frac[2])/(I1+I2+I3+I4+I5);
			total_deltaL=(I1 +I2*deltaL_frac[0] +I3*deltaL_frac[1] +I4*deltaL_frac[2])/(I1+I2+I3+I4+I5);
			cout << "total_alphaL= " << total_alphaL << "  total_betaL= " << total_betaL <<"  total_gammaL= " << total_gammaL <<"  total_deltaL= " << total_deltaL;
			cout << "     seqfamilies[i].familyseq=" <<seqfamilies[i].familyseq<<"   fname="<<seqfamilies[i].ms1p[0].rawfname<<endl << endl; 

			if ((total_alphaL > 0.00000) || (total_betaL > 0.00000)  || (total_gammaL > 0.00000) ) {
				if (((total_alphaL - total_betaL) < 0.00001) && ((total_alphaL - total_betaL) > -0.00001)) {
					// in the below the index of the array is consistent with code in 2K, that is the ii for II[ii]; but different from 1K which has sh[0] as light one.
					// Here sh[0] represents heavy peak.
					cout << "utal_alpha,"<<total_alphaL<<","<<total_betaL<<","<<total_gammaL<<","<<total_deltaL<<","<<seqfamilies[i].familyseq<<","<<seqfamilies[i].ms1p[0].rawfname;
					cout << ",heavy,"<< sh[0].max_R_time << "," << sh[0].max_s_inten << "," << sh[0].starting_time << "," << sh[0].end_time;
					cout << ",light,"<< sh[4].max_R_time << "," << sh[4].max_s_inten << "," << sh[4].starting_time << "," << sh[4].end_time;
					cout << ",middle1,,,,middle2,,,,"<<endl<<endl;
				} else {
					cout << "utal_alpha,"<<total_alphaL<<","<<total_betaL<<","<<total_gammaL<<","<<total_deltaL<<","<<seqfamilies[i].familyseq<<","<<seqfamilies[i].ms1p[0].rawfname;
					cout << ",heavy,"<< sh[0].max_R_time << "," << sh[0].max_s_inten << "," << sh[0].starting_time << "," << sh[0].end_time;
					cout << ",light,"<< sh[4].max_R_time << "," << sh[4].max_s_inten << "," << sh[4].starting_time << "," << sh[4].end_time;
					cout << ",middle1,"<< sh[1].max_R_time << "," << sh[1].max_s_inten << "," << sh[1].starting_time << "," << sh[1].end_time;
					cout << ",middle2,"<< sh[2].max_R_time << "," << sh[2].max_s_inten << "," << sh[2].starting_time << "," << sh[2].end_time;
					cout << ",middle3,"<< sh[3].max_R_time << "," << sh[3].max_s_inten << "," << sh[3].starting_time << "," << sh[3].end_time<<endl<<endl;
				}
			}


		}// end of if (seqfamilies[i].num_of_K == 4) 

	} // end of for (i=0; i < seqfamilies.size(); i++){
	return 0;
} // end of of main


