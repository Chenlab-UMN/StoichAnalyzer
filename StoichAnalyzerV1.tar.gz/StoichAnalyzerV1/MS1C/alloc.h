#include <stdlib.h>
#include <iostream>

class Collector {
	char* start;
	char* freebegin;
	int size;
	int freesize;
public:
	Collector(char* stt, int ssz);
	char* i_malloc(int i);
	void i_free(char* pos, int ssz);
};
