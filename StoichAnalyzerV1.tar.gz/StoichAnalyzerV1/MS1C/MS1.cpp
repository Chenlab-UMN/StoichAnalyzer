#include <iostream>
#include <sys/types.h>
#include <math.h>
#include <stdlib.h>
#include <math.h>
#include "base64.h"
#include "ramp.h"
#include "cramp.hpp"
#include "alloc.h"
#include <vector>
#include <iomanip>      // std::setprecision
using namespace std;
//#define	TRACE		 1
//#define	TRACE_detail 1
//#define	TRACE_detail2 1
//#define TRACE_print  1
//#define constSCAN	3542

/******************
March 25 2013

extract max precursor ion intensity, given a precursor m/z and the spectrum number of nearby MS/MS identification.

*******************/


#define MAX_REDUNDANT_NUM	30		// maximum number of redundant protein ids with overlapping pep id in struct protid
#define H_MONO 1.0078246
#define H2O_MONO 18.01056
#define O_MONO 15.99492
#define IA_MONO 57.02146
#define constSINGLEMZ_PERCENT 0.15
#define constMIN_PRECURSORRANGELOWMZ 50
#define constMIN_PRECURSORRANGEHIGHMZ 4
#define constMIN_INTENSITYLOWMZ 0.05
#define constMIN_INTENSITYHIGHMZ 0.05
#define constMIN_INTENSITYPERCENT 0.002
#define constPEAKSCAN_RANGE 60
#define constTopPeakNumNoiseCalc 7
#define constNOISELEVEL_RATIO 4
#define constISOTOPE_GAP 1.5
#define constISOTOPERATIO_CONSTANT1 0	
#define constISOTOPENOISELEVEL_RATIO 0		
#define constISOTOPERATIO_CONSTANT2 0.0006	// = 1/2500, times m/z and plus ISOTOPERATIO_CONSTANT3 to get max level for peak isotope
#define constISOTOPERATIO_CONSTANT3 0.7		// check above
#define constMissHighMZPercent 0.5			// max percent of high mz peaks that cannot be assigned.
#define constHighMZSNRATIO 10				// MIN SN noise level a High Mz peak is considered to be input to highmzpeak list
#define constMIN_PEAKCOUNTS 10

#define constMSpeakrange 100		// number of peaks in precursor MS spectrum around the precursor ion to check for isotope and SILAC peaks
#define constMSerror 15			// number of ppm for MS error to identify isotope and SILAC peaks based on the precursor M/z, including mass correction for unknown element type than averagine
#define constMSMSerror 100			// number of ppm for MS error to identify isotope and SILAC peaks based on the precursor M/z, including mass correction for unknown element type than averagine
#define constIsoVar1 3		// no more than 3 times allowed for intensity ratio to theoretical intensity ratio
#define constIsoVar2 0.30		// at least 30% for intensity ratio to theoretical intensity ratio

//double constIso[5] = {0,1.003262148, 2.001690634, 3.000227919,3.992872695};
double constIso[6] = {0,1.002861318, 2.001671504, 3.010065,4.01342,5.01678};
float constAveragine=111.1254;
float constC=4.9384;
float constCr=0.0107;

double factorial(int n){
	double temp;
	if(n <= 1) return 1;
	temp = (double) n * factorial(n - 1);
	return temp;
}

double combination(int n, int r){
	return ((double) factorial(n)/(factorial(r)*factorial(n-r))); 
}
#include "MS1.hpp"
int assign_the_difference(struct column0 *aa, int b);
float max_array(float a[], int num_elements);
int max_intensiT_search(struct column0 *a, int b);
float average_of_max_3_out_of_7(struct column0 *aa, int b, int c);
int bestscan_search(struct  column0 *a, int size, int b);
int bestscan_search2(struct column0 *a, int size, int b);
int apexcandi_search(struct column0 *a, int size, int ind_best, int* ap1, int* ap2, int* uppt, int* lopt);
float min_of_two(float a,float b);
float max_of_two(float a,float b);
int min_of_two_int(int a,int b);
int max_of_two_int(int a,int b);
float average_of_light_mz_overlapping_zone(struct column0 *aa, int size);
double summatioN(struct column0 *aa, int b, int c);
double summatioNproduct(struct column0 *aa, int b, int c, double* upper_limit);
int low_1_search(struct column0 *aa, int size, int b);
int low_0_search(struct column0 *aa, int size, int b);
//int low_2_search(struct column0 *aa, int size, int b);
int low_2a_search(int a[], int size, int b);
int low_3_search(struct column0 *aa, int size, int b, double threshold);
int upper_1_search(struct column0 *aa, int size, int b);
int upper_0_search(struct column0 *aa, int size, int b);
//int upper_2_search(struct column0 *aa, int size, int b);
int upper_2a_search(int a[], int size, int b);
int upper_3_search(struct column0 *aa, int size, int b, double threshold);
int max_int_array(int a[], int b);
int min_int_array(int a[], int b);
int I1_pre(column0 *aa, int size, float c, float d, int* e, int* f);

struct precursorGroup {
	float elutionStart;
	float elutionEnd;
	int specStart;
	int specEnd;
	float isotopeMz[6];
	double peakintensity;
	float NormMz;

	int isotopeType; // 0= light 1= heavy 2= not determinded when SILAC pair is not detected; spectra with isotopeType=0 or 2 should be put in light peptide cms file and spectra with isotopeType=1 or 2 should be put in heavy peptide cms file
	float normalizedRatio;
	int charge;
	int NumK;
	int NumR;
	int silacdiffType;
	int mcleNum;
	int	maxscan;	// the scan num with the highest precursor intensity

	float silacelutionStart;
	float silacelutionEnd;
	int silacspecStart;
	int silacspecEnd;
	float silacisotopeMz[6];
	double silacpeakintensity;
	float silacNormMz;

	struct precursorGroup *next;
};

struct peakstruct {
	float mz;
	float intensity;
	bool match;
	int pos;
	float snratio;
	float intpercent;
	int charge;		// 0 if charge state cannot be determined
	bool yion;		// true if the ion has a SILAC partner peak and it is a y ion
	bool isotope;   // true if either isotope peak or SILAC partner is identified
};

struct peakscanheader {
	int realpeakscount;				// number of peaks in allpeaks after considering noise reduction
	RAMPREAL* rpeaks;
	struct ScanHeaderStruct scanheader;
	int* highmzrange;		// number of peaks with intensity higher than 5% of max intensity and mz higher than (parent mz+20)
	int highmzpeaknum;
	int* lowmzrange;			// number of peaks with intensity higher than 20% of max intensity and mz lower than (parent mz-20)
	int lowmzpeaknum;
	bool limitedHighions;		// first pass of finding good ions in high mz range to get a number <=2, so the constHighmzint/4 should be applied later on
	int intensitySum_lowmzNum;
	int intensitySum_highmzNum;
	int charge;
	float precbd1;
	float precbd2;
	float lowcut;
	float highcut;
	float precursorlist[25];	// precursor ion candidate list
	float intensitySum_lowmz;	// intensity sum of all significant ions in low mz
	float intensitySum_highmz;	// intensity sum of all significant ions in high mz
	int precursornum;			// precursor ion candidate number
	RAMPREAL* rpeaks0;		// precusor MS scan rpeaks
	struct precursorGroup precursorInfo;
	struct peakstruct allpeaks[4000];	// allpeaks contains all the peaks after noise reduction
};


void quicksort(double* numarray, int len){
	if(len<2) return;
	double array1[100],array2[100], temp;
	int i, j1=0,j2=0;
	temp = numarray[0];
	for(i=1;i<len;i++){
		if(numarray[i]>temp){ array1[j1]=numarray[i]; j1++;}
		else { array2[j2]=numarray[i]; j2++;}
	}
	if(j1>1) quicksort(array1, j1);
	if(j2>1) quicksort(array2, j2);
	for(i=0;i<len;i++){
		if(i<j1) numarray[i]=array1[i];
		else if(i==j1) numarray[i]=temp;
		else if(j2>0) numarray[i]=array2[i-j1-1];
	}
	return;
}

int getprecursorcharge(struct peakscanheader* thescans){
	double tot=0, tothigh=0, precursor;
	int i, count;

	count = thescans->scanheader.peaksCount;
	precursor = thescans->scanheader.precursorMZ;
	for(i=0;i<count;i++){
		tot += thescans->rpeaks[2*i+1];
		if(thescans->rpeaks[2*i] > precursor) tothigh += thescans->rpeaks[2*i+1];
	}
	//	char testline[40];
	//if(thescans->scanheader.seqNum>=14457){ sprintf(testline,"tothigh=%lf, tot=%lf, percent=%lf", tothigh, tot, tothigh/tot); popmessage(testline);}
	if(tothigh / tot <= constSINGLEMZ_PERCENT) return 1;
	else return 2;
}


/******************************
		Precursor manager
*******************************/


class precursorManager {
public:
	int groupnum;
	struct precursorGroup *head;
	struct precursorGroup *tail;

	precursorManager();
	struct precursorGroup* getnewgroup();
	struct precursorGroup* searchgroup(float currmz, int currspec, int currcharge);
	void invertGroup(struct precursorGroup* src,struct precursorGroup* dst);
};

precursorManager::precursorManager(){
	groupnum=0;
	head = NULL;
	tail = NULL;
}

struct precursorGroup* precursorManager::getnewgroup(){
	struct precursorGroup* temp;

	temp = (struct precursorGroup*) calloc(1, sizeof(struct precursorGroup));
	if(tail==NULL) { tail = temp; head = temp;}
	else {
		tail->next = temp;
		tail = temp;
		temp->next = NULL;
	}
	return(temp);
}

struct precursorGroup* precursorManager::searchgroup(float currmz, int currspec, int currcharge){
	struct precursorGroup *temp, *temp0=NULL, *temp1=NULL, *temp2;
	float mserror0=10000, mserror1=10000, temperror0, temperror1;

	temp = head;
	while(temp!=NULL){
		if(currspec>=temp->specStart && currspec<=temp->specEnd){
			temperror0=fabs(currmz-temp->NormMz)/currmz*1000000;
			if( temperror0<= constMSerror){
				if(temperror0<mserror0) { temp0 = temp; mserror0 = temperror0;}
			}
		}
		if(currspec>=temp->silacspecStart && currspec<=temp->silacspecEnd && temp->silacNormMz>0){
			temperror1=fabs(currmz-temp->silacNormMz)/currmz*1000000;
			if(temperror1<= constMSerror){
				if(temperror1<mserror1) { temp1 = temp; mserror1 = temperror1;}
			}
		}
		temp = temp->next;
	}
	if(temp0 == NULL && temp1 == NULL) return (NULL);
	else if(temp0 != NULL && currcharge==temp0->charge) return (temp0);
	else if(temp1 != NULL && currcharge==temp1->charge){
		temp2 = getnewgroup();
		invertGroup(temp1,temp2);
		return (temp2);
	}
	else return (NULL);
}

void precursorManager::invertGroup(struct precursorGroup* src,struct precursorGroup* dst){
	int i;

	dst->silacelutionEnd = src->elutionEnd;
	dst->silacelutionStart = src->elutionStart;
	dst->silacspecEnd = src->specEnd;
	dst->silacspecStart = src->specStart;
	dst->silacpeakintensity = src->peakintensity;

	dst->elutionEnd = src->silacelutionEnd;
	dst->elutionStart = src->silacelutionStart;
	dst->specEnd = src->silacspecEnd;
	dst->specStart = src->silacspecStart;
	dst->peakintensity = src->silacpeakintensity;

	dst->normalizedRatio = src->normalizedRatio;
	dst->maxscan = src->maxscan;

	for(i=0;i<6;i++) {
		dst->isotopeMz[i] = src->silacisotopeMz[i];
		dst->silacisotopeMz[i] = src->isotopeMz[i];
	}
	if(src->isotopeType==0) dst->isotopeType=1;
	else if (src->isotopeType==1) dst->isotopeType=0;
	else dst->isotopeType = src->isotopeType;

	dst->NormMz = src->silacNormMz;
	dst->silacNormMz = src->NormMz;
	dst->NumK = src->NumK;
	dst->NumR = src->NumR;
	dst->mcleNum = src->mcleNum;
	dst->silacdiffType = src->silacdiffType;
	dst->charge = src->charge;
}

int deconvolute(double *rpeaks, int k1, int k2, double *bArray, int *group,int show){
	int i,j,m,n,p,rank; float diff,diff1, intratio, intratioT;
	// copy rpeaks data into bArray
	for(i=k1;i<=k2;i++) {
		bArray[3*(i-k1)]=rpeaks[2*i];
		bArray[3*(i-k1)+1]=rpeaks[2*i+1];
		bArray[3*(i-k1)+2]=0;
		if(show==1){
			cout <<(i-k1)<<"\t"<<bArray[3*(i-k1)] <<"\t"<< bArray[3*(i-k1)+1] << endl;
		}
	} // item 1 and 2 are the same and item 3 is the charge state which is filled later

	// iterate
	for(i=0;i<=(k2-k1);i++){
		// test if i peak is a base peak of an isotope group
		if(bArray[3*i+1]==0) continue; // if i peak has been marked as isotope of previous peaks or i peak is the central precursor which we are looking for its SILAC partner, then continue;
		if(show==1){
			cout<<"deconvolute i="<<i<<" "<<bArray[3*i]<<endl;
		}
		for(m=0;m<5;m++){group[m]=0;}
		for (j=(i+1);j<=(k2-k1);j++){
			if(bArray[3*j+1]==0) continue;
			diff = bArray[3*j]-bArray[3*i];
			if(diff>4) break;	// if peak j is too far away from i then, no longer consider it in isotope group
			for(m=0;m<5;m++){	// m is charge, n is isotope number
				if( (group[m]+1)<5 && fabs(diff*(m+1)-constIso[group[m]+1])/bArray[3*i]*1000000 < 1.0*constMSerror){
					diff1 = (bArray[3*i]*(m+1)/constAveragine)*constC;		// calculate C number based on average formula
					rank=(diff1-(int)diff1)>0.5?((int)diff1+1):(int)diff1;	// record C number as integer in rank
					intratio=bArray[3*j+1]/bArray[3*i+1];	// the exp peak j to peak i intensity ratio
					intratioT = combination(rank,group[m]+1)*pow(constCr,group[m]+1);  // the theo peak j to peak i intensity ratio
					if(show==1){
						cout<<"	isotope maybe removed j="<<j<<" "<<bArray[3*j]<<" m="<<m<<" rank="<<rank<<" group[m]="<<group[m]<<" combi="<<combination(rank,group[m]+1)<<" fac="<<factorial(21)<<" intratio="<<intratio<<" intratioT="<<intratioT<<endl;
					}
					if(intratio/intratioT < constIsoVar1 && intratio/intratioT > constIsoVar2 ){	// if it is within reasonable range of isotope theoretical ratio,then count peak j as isotope
						if(show==1){
							cout<<"		ratio is ok"<<endl;
						}
						group[m]++;
					}
				}
			}
		}
		n=0;p=-1;
		for(m=4;m>=0;m--){if(group[m]>n) {n = group[m];p=m;}} // now charge state is found as p+1, cycle from high charge to low charge is to favor high charge state first, so that all possible isotopes peaks can be removed
		if(p>=0){
			// record charge state
			bArray[3*i+2]=p+1;
			// mark isotopes to 0
			n=0;
			for (j=(i+1);j<=(k2-k1);j++){
				if(bArray[3*j+1]==0) continue;
				diff = bArray[3*j]-bArray[3*i];
				if(diff>4) break;	// if peak j is too far away from i then, no longer consider it in isotope group
				if((n+1)<5 && fabs(diff*(p+1)-constIso[n+1])/bArray[3*i]*1000000 < 1.0*constMSerror){
					diff1 = (bArray[3*i]*(p+1)/constAveragine)*constC;		// calculate C number based on average formula
					rank=(diff1-(int)diff1)>0.5?((int)diff1+1):(int)diff1;	// record C number as integer in rank
					intratio=bArray[3*j+1]/bArray[3*i+1];	// the exp peak j to peak i intensity ratio
					intratioT = combination(rank,n+1)*pow(constCr,n+1);  // the theo peak j to peak i intensity ratio
					if(intratio/intratioT < constIsoVar1 && intratio/intratioT > constIsoVar2){	// if it is within reasonable range of isotope theoretical ratio,then count peak j as isotope
						if(show==1){
							cout<<"	isotope to be removed j="<<j<<" "<<bArray[3*j]<<" n="<<n<<" p="<<p<<endl;
						}
						bArray[3*j+1]=0;n++;
						if(n==4) break;
					}
				}
			}
		}
	}
	return 0;
}


int deconvoluteMSMS(double *rpeaks, int k, struct peakstruct *allpeaks,double baseint, int *group,int show){
	int i,j,m,n,p,rank; float diff;
	// copy rpeaks data into allpeaks struct
	for(i=0;i<=k;i++) {
		allpeaks[i].mz=rpeaks[2*i];allpeaks[i].intensity=rpeaks[2*i+1];allpeaks[i].charge=0;allpeaks[i].isotope=false;
		allpeaks[i].intpercent=allpeaks[i].intensity/baseint;allpeaks[i].match=false;allpeaks[i].pos=i;allpeaks[i].snratio=0;allpeaks[i].yion=false;
	}

	// iterate
	for(i=0;i<k;i++){
		// test if i peak is a base peak of an isotope group
		if(allpeaks[i].intensity==0) continue; // if i peak has been marked as isotope of previous peaks , then continue;
		if(show==1){
			cout<<"deconvoluteMSMS i="<<i<<" "<<allpeaks[i].mz<<endl;
		}
		rank=0;
		for(m=0;m<6;m++){group[m]=0;}
		for (j=(i+1);j<k;j++){
			if(allpeaks[j].intensity==0 || allpeaks[j].intensity/allpeaks[i].intensity > 2) continue;
			diff = allpeaks[j].mz-allpeaks[i].mz;
			if(show==1){
				cout<<"		peak j="<<j<<" "<<allpeaks[j].mz<<" "<<diff<<" "<<constIso[1]<<" "<<fabs(diff-constIso[1])<<" "<<fabs(diff-constIso[1])/allpeaks[i].mz*1000000<<endl;
			}
			if(diff>4.1) break;	// if peak j is too far away from i then, no longer consider it in isotope group
			for(m=0;m<6;m++){	// m is charge, n is isotope number
				if( (group[m]+1)<6 && fabs(diff*(m+1)-constIso[group[m]+1])/allpeaks[i].mz*1000000 < constMSMSerror){group[m]++;}
			}
		}
		n=0;p=-1;
		for(m=0;m<6;m++){
			if(group[m]>n) {n = group[m];p=m;}
			if(show==1){
				cout<<"	group m="<<m<<" "<<group[m]<<endl;
			}
		} // now charge state is found as p+1
		if(p>=0){
			// record charge state
			allpeaks[i].charge=p+1;
			allpeaks[i].isotope=true;		// set to true if the isotope of the peak i can be found or its SILAC partner peak can be found
			// mark isotopes to 0
			n=0;
			for (j=(i+1);j<k;j++){
				if(allpeaks[j].intensity==0 || allpeaks[j].intensity/allpeaks[i].intensity > 2) continue;
				diff = allpeaks[j].mz-allpeaks[i].mz;
				if(diff>4) break;	// if peak j is too far away from i then, no longer consider it in isotope group
				if((n+1)<6 && fabs(diff*(p+1)-constIso[n+1])/allpeaks[i].mz*1000000 < constMSMSerror){
					allpeaks[j].intensity=0;n++;
					if(n==5) break;
				}
			}
		}
		if(show==1){
			cout<<"	charge p= "<<p<<" "<<allpeaks[i].charge<<endl;
		}
	}
	return 0;
}




double noise_level(char* rawfilename, int max_scan_num){

	// WE will use retention_time(best_scan) +- delta_r_time to replace boundary defined as:
	//      upperScan=bestScan+4999;
	//      lowerScan=bestScan-4999;

	/*      int argn=6;
		char argm[6][40];
		strcpy(argm[1],"colA-analysis-1-1.mzXML");
		strcpy(argm[2],"1");
		strcpy(argm[3],"1");
		strcpy(argm[4],"1");
		strcpy(argm[5],"3");
*/

	//Usage: ./extractIntensity  [mzXML file] [The scan_num of the bestscan] [m/z] [1=additional info, 0=none"<<endl;

	RAMPFILE* rawf;
	struct peakscanheader allscans, *thescans;
	ramp_fileoffset_t scanindex;
	int j, lscan;
	int pscan=0, ppeakcount=0; /*PTMap2*/ // the scannum and peakcount of the precursor scan of the MS/MS scan
	char *temp0;
	//  bool CentroidMS;
	precursorManager* pmanager;
	ScanHeaderStruct precHeader;    // precursor scan header;
	//YingHua's modification begin here
	//
	double intensiT[3000], temp;
	double low_ave, sum_in_the_scan, sum_largest_1third;
	int jj, k, limit_jj, size1;
	//column0 * possible_column_pt2= new column0[1000];


	rawf = rampOpenFile(rawfilename);
	if(rawf==NULL){
		cout<<"Error: Cannot open mzXML file "<<endl;
		return 1;
	}
	//       cout<< "Do I know lscan now1?   lscan = " << lscan <<endl;
	//       cout<< "                   scannindex = " << scanindex <<endl;
	pmanager = new precursorManager();
	scanindex = getIndexOffset(rawf);
	ramp_fileoffset_t * allscansoffset = readIndex(rawf, scanindex, &lscan);
	thescans = &allscans;
	Collector* gbcl;
	temp0 = (char*) calloc(100000, sizeof(char));
	gbcl = new Collector(temp0,100000);
	readHeader(rawf, allscansoffset[max_scan_num], &(thescans->scanheader));
	pscan = max_scan_num;
	thescans->rpeaks = readPeaks(rawf, allscansoffset[max_scan_num]);
	readHeader(rawf, allscansoffset[pscan],&precHeader); //this is the only function of pscan, may use i instead?

	ppeakcount = precHeader.peaksCount;
	size1 = int (ppeakcount/2);
	limit_jj = int (size1/3);
	//cout << "limit_jj=" << limit_jj << endl;

	sum_in_the_scan=0.00000;
	for(j=0;j<size1;j++){
		intensiT[j] = thescans->rpeaks[2*j+1];
		sum_in_the_scan += intensiT[j];
	}
	// By taking largest 1/3 instead of samllest 2/3, we save approximately 3/8 of time 
	// on bubble sorting (from 8/9 of the triangle -> 5/9 of the triangle) 
	sum_largest_1third=0.00000;     
	for(jj=0; jj<limit_jj; jj++){
		for (k=jj+1; k<size1; k++){
			if ( intensiT[jj] < intensiT[k] ) {
				temp = intensiT[jj];
				intensiT[jj] = intensiT[k];
				intensiT[k] = temp;
			}
		}
		sum_largest_1third += intensiT[jj];
	}
	low_ave=(sum_in_the_scan - sum_largest_1third)/(size1-limit_jj);  
	return low_ave;

}


int max_intensiT_search(struct column0 *aa, int size)
{
	int posi; int i;
	float temp;
	for(i=0;i<size;i++){
		if (aa[i].intensiT > temp){
			posi=i;
			temp=aa[i].intensiT;
		}
	}
	return posi;
}


int bestscan_search(struct column0 *aa, int size, int b)
{
	int i,c1,j,jj,token_taker,diff_temp;
	c1=b-60;
	int temp[8], difference[8];
	j=0; 	
	for(i=0;i<size;i++){
		if ((aa[i].scan_num>c1)&&(aa[i].scan_num<b)) {
			temp[j]=i;
			difference[j]= b - aa[i].scan_num;
			j++;
		}
	}
	if (j==0){
		return -1; //tell outside no peak found. problematic!
	}
	if (j==1){
		return temp[0];
	}else{ 
		diff_temp=difference[0];
		token_taker = temp[0];
		for(jj=1;jj<j;jj++){
			if(difference[jj]<diff_temp){
				diff_temp = difference[jj];
				token_taker = temp[jj];
			}
		}
		return token_taker;
	}
}

int bestscan_search2(struct column0 *aa, int size, int b) // is the same as function bestscan_search but faster
{
	int token, delta, i;
	int c1 = b-40;
	if (size > 19) { 
		token = int(size/2);
		delta = int(token/2);
		while  (delta >= 2){
			if ( aa[token].scan_num < c1){
				token += delta;
			} else {
				token -= delta;
			}
			delta = int (delta/2);
		}
		if ( aa[token].scan_num > c1){
			token -= (delta*4+2);
		}
		if (token < 0) {
			token =0;
		}
	} else {
		token =0; 
	}

	if (size == 1) {
		return 0;
	}

	for(i=token;i<size;i++){
		if (aa[i].scan_num > b) {
			return i-1;
		}
	}

	return -1; // all are smaller than b;
}

//int apexcandi_search(struct column0 *aa, int size_of_aa, int* ind_best, int* ap1, int* ap2, int* uppt, int* lopt);
int apexcandi_search(struct column0 *aa, int size_of_aa, int index_best, int* apex1, int* apex2, int* upper_cut_pt, int* lower_cut_pt) {
	//search apex1 and upper bound
	bool continue_flag = true;
	int i;
	double temp_max1, temp_max2;
	int prev_decrease, decrease_record;
	int prev_increase, increase_record;
	
	*apex1=index_best;
	temp_max1 = aa[index_best].intensmooth;
	//temp_max2 = aa[index_best].intensmooth;
	if (index_best < (size_of_aa -1)){

		i = index_best+1;
		decrease_record = 0;
		prev_decrease = 0;
		while ( continue_flag == true ) {
			if (aa[i].intensmooth >= temp_max1) {
				*apex1 = i;
				temp_max1 = aa[i].intensmooth;
			} 
			if ( aa[i].intensmooth < aa[i-1].intensmooth) {
				if ( prev_decrease == 1 ) {
					decrease_record = 1;
				}
				prev_decrease = 1;
			} else {
				prev_decrease = 0;
			}

			if ((decrease_record == 1) && (i < (size_of_aa -1))) {
				if ((1.010*aa[i-1].intensmooth < aa[i].intensmooth) && (1.010*aa[i].intensmooth < aa[i+1].intensmooth)) { 
					*upper_cut_pt = i-1; // summation area includes the vally bottom point. 
					continue_flag = false;
				}
			}
			if((i==size_of_aa-1) &&(continue_flag ==true)){
				*upper_cut_pt = i;
				continue_flag = false;  //therefore, the ceiling is (size_of_aa-1).
			}
			i++;
		}//while

	} else  { //if (index_best == (size_of_aa -1) )
		*upper_cut_pt  = size_of_aa - 1;
	}
	//	cout << "*apex1=" << *apex1 <<"  temp_max1="<< temp_max1 << endl; 	

	//search apex2 and lower bound
	continue_flag = true;
	*apex2=index_best;
	temp_max2 = aa[index_best].intensmooth;
	if ( index_best > 0 ) {

		i = index_best-1;
		increase_record = 0;
		prev_increase = 0;
		while ( continue_flag == true ) {
			if (aa[i].intensmooth >= temp_max2) {
				*apex2 = i;
				temp_max2 = aa[i].intensmooth;
			} 
			if (aa[i].intensmooth < aa[i+1].intensmooth) {
				if ( prev_increase == 1 ) {
					increase_record = 1;
				}
				prev_increase = 1;
			} else {
				prev_increase = 0;
			}

			if ((increase_record == 1) && (i>0)){
				if ((aa[i-1].intensmooth > 1.010*aa[i].intensmooth) && (aa[i].intensmooth > 1.010*aa[i+1].intensmooth)) {
					*lower_cut_pt = i+1; // Surface area includes the vally bottom point.
					continue_flag = false;
				}
			}
			if ((i==0)&& (continue_flag ==true)) {
				*lower_cut_pt = 0;
				continue_flag = false;
			}
			i--;
		} //while

	} else {//if (index_best == 0 )
		*lower_cut_pt = 0;
	}
	//	cout <<"*apex2="<< *apex2 <<"  temp_max2="<< temp_max2 << endl;

	return 0;
}

/*
int I1_pre(struct column0 *aa, int size, float heavy_R_time1, float heavy_R_time2, int* lower_cut, int* upper_cut)
{
int i, lower_cutt, upper_cutt;
float time_beforehand_allowannce;
float time_after_allowannce;
float temp_max,temp_max1;
std::vector <int> diff;  
int max[2];

if ((heavy_R_time1 - aa[0].R_time) > time_beforehand_allowannce){
	for (i=1; i<size; i++){
	if ((heavy_R_time1 - aa[i].R_time) <= time_beforehand_allowannce){
	lower_cutt = i;
	break;
	}
	}
} else { lower_cutt = 0;}
if ((aa[size-1].R_time-heavy_R_time2) > time_after_allowannce){
	for(i=size-2; i>=0; i--){
	if ((aa[i].R_time-heavy_R_time2) <= time_after_allowannce){
	upper_cutt = i;
	break;
	}
	}
} else { upper_cutt = size-1;}

cout << "lower_cutt="<< lower_cutt <<"   upper_cutt=" << upper_cutt <<endl;

if (lower_cutt < upper_cutt) {
	//find the place of max IntensiT
	temp_max = aa[lower_cutt].intensiT;
	max[0] = lower_cutt;
	for (i=lower_cutt+1; i<=upper_cutt; i++){
	if ( temp_max <  aa[i].intensiT) {
	max[0] = i;
	temp_max = aa[i].intensiT;
	}
	}
	temp_max1 = 0;
	for (i=lower_cutt; i<=upper_cutt; i++){
	if (i != max[0]) {
	if ( temp_max1 < aa[i].intensiT) {
	max[1] = i;
	temp_max1 = aa[i].intensiT;
	}
	}
	}
	//now we have two largest at  max[0] and max[1]


	//find the minimum of array diff
	for (i=lower_cutt; i<=upper_cutt-1; i++){
	diff.push_back( aa[i].scan_index - aa[i+1].scan_index );
	}

}


}
*/

// we are making something harder to judge the peak of unknown bestscan 
// cout << "SSSD "<<i<<" "<< possible_column_pt[i].scan_index <<" "<<possible_column_pt[i].scan_num<<"\t"<<possible_column_pt[i].R_time<<"\t"
// <<possible_column_pt[i].R_time/60<<"\t"<<possible_column_pt[i].mz1<<"\t"<< possible_column_pt[i].intensiT<<endl;

// we are not to seek best scan nor upper nor lower cut
// we will just 
// 1. check R-time, if too farfrom the range of heavy, kick out
// 2. check possible_column_pt[i].scan_index, if continue oe in the form (i, i+2) or (i, i+3) 
// 3. compare intensity
// 4. after determine which columns to take, directly give the area.
// input: 1. address of possible_column_pt 2. its size 3. R-time range of heavy 

//I1_pre(possible_column_pt, member_index, heavy_R_time1, heavy_R_time2, upper_cut, lower_cut);
//int bestscan_search2(struct column0 *aa, int size, int b) 


float min_of_two(float a,float b)
{
	if (a>b) 
	return b;
	else
	return a;
}

float max_of_two(float a,float b)
{
	if (a<b) 
	return b;
	else
	return a;
}

int min_of_two_int(int a,int b)
{
	if (a>b)
	return b;
	else
	return a;
}

int max_of_two_int(int a,int b)
{
	if (a<b)
	return b;
	else
	return a;
}

float max_array(float a[], int b)
{
	float temp; int i;
	temp = a[0];
	for(i=1;i<b;i++){
		if (a[i]>temp)
		temp=a[i];
	}
	return temp;
}

int max_int_array(int a[], int b)
{
	int temp; int i;
	temp = a[0];
	for(i=1;i<b;i++){
		if (a[i]>temp)
		temp=a[i];
	}
	return temp;
}

int min_int_array(int a[], int b)
{
	int temp; int i;
	temp = a[0];
	for(i=1;i<b;i++){
		if (a[i]<temp)
		temp=a[i];
	}
	return temp;
}

float average_of_light_mz_overlapping_zone(struct column0 *aa, int size)
{
	int i;
	float mz_sum=0.00000;
	unsigned counter=0;
	for(i=0; i<size; i++){
		if (aa[i].intensiT>0.000){ 
			mz_sum += aa[i].mz1;
			counter++;
		}
	}
	if (counter == 0) {
		return -1.000;
	} else {
		return mz_sum/counter;
	}
}

double summatioN(struct column0 *aa, int b, int c)
{
	int i;
	float summ=0;
	for(i=b; i<=c; i++){
		summ=summ+aa[i].intensiT;
	}
	return summ;
}

double summatioNproduct(struct column0 *aa, int b, int c, double* upper_limit)
{
	int i;
	double summ=0;
	double upper_summ=0;
	summ = 2*aa[b].intensiT*(aa[b+1].R_time-aa[b].R_time);    //assume the width is the same as available neighbor. but take
	summ += 2*aa[c].intensiT*(aa[c].R_time-aa[c-1].R_time);
	for(i=b+1; i<c; i++){
		summ += aa[i].intensiT*(aa[i+1].R_time-aa[i-1].R_time);
	}

	upper_summ = 2*aa[b].intensiT*(aa[b+1].R_time-aa[b].R_time); 
	upper_summ += 2*aa[c].intensiT*(aa[c].R_time-aa[c-1].R_time);
	for(i=b+1; i<c; i++){
		if (aa[i].intensiT < 100) {
			upper_summ += aa[i].intensiT2*(aa[i+1].R_time-aa[i-1].R_time);  
		} else {
			upper_summ += aa[i].intensiT*(aa[i+1].R_time-aa[i-1].R_time);
		}
	}
	//pass by address  upper_summ;
	upper_summ = upper_summ/2;
	*upper_limit = upper_summ;
	return summ/2;
}

int low_1_search(struct column0 *aa, int size, int b)
{
	int i;
	for(i=b-1;i>=0;i--){
		if ((aa[i+1].scan_index - aa[i].scan_index) > 2 ) {
			return i+1;
		}
	}
	return 0;
}


int low_0_search(struct column0 *aa, int size, int b)
{
	int i;
	for(i=b-1;i>=0;i--){
		if ((aa[i+1].scan_index-aa[i].scan_index) > 2 ) {
			if (aa[i+1].intensiT > 0.00){ // is this if redundant?
				return i+1;
			} else if ((i+2)<size && aa[i+2].intensiT > 0.00){ 
				return i+2;
			}      //
		} 
		if ((aa[i].intensiT==0.00)&&(aa[i-1].intensiT==0.00)) {
			if (aa[i+1].intensiT > 0.00){
				return i+1;
			} else if ((i+2)<size && aa[i+2].intensiT > 0.00){
				return i+2;
			} 
		} 
		if (aa[i].intensiT==0.00) {
			if ((aa[i+1].scan_index-aa[i-1].scan_index) > 2 ) {
				if (aa[i+1].intensiT > 0.00){
					return i+1;
				} else if ((i+2)<size && aa[i+2].intensiT > 0.00){
					return i+2;
				}
			}
		}
	}
	if (aa[0].intensiT==0.00) {
		return 1;
	} else {
		return 0;
	}
}


// aa[i].scan_index-aa[i-1].scan_index ==0 ; possible two columns in mz range one scan.
// aa[i].scan_index-aa[i-1].scan_index ==1 ; normal
// aa[i].scan_index-aa[i-1].scan_index ==2 ; we allow one scan missing.

int upper_1_search(struct column0 *aa, int size, int b)
{
	int i;
	for(i=b+1;i<size;i++){
		if ((aa[i].scan_index-aa[i-1].scan_index) > 2 ) {
			return i-1;
		}
	}
	return size-1;
}

int upper_0_search(struct column0 *aa, int size, int b)
{
	int i;
	for(i=b+1;i<size;i++){
		if ((aa[i].scan_index-aa[i-1].scan_index) > 2 ) {
			if (aa[i-1].intensiT > 0.00){ // is this if redundant?
				return i-1;
			} else if ((i-2)>=0 && aa[i-2].intensiT > 0.00){
				return i-2;
			}   
		} 
		if ((aa[i].intensiT==0.00)&&(aa[i+1].intensiT==0.00)) { 
			if (aa[i-1].intensiT > 0.00){ // is this if redundant?
				return i-1;
			} else if ((i-2)>=0 && aa[i-2].intensiT > 0.00){
				return i-2;
			}
		} 
		if (aa[i].intensiT==0.00) {
			if ((aa[i+1].scan_index-aa[i-1].scan_index) > 2 ) {
				if (aa[i-1].intensiT > 0.00){ // is this if redundant?
					return i-1;
				} else if ((i-2)>=0 && aa[i-2].intensiT > 0.00){
					return i-2;
				}
			}
		}
	}
	if (aa[size-1].intensiT==0.00) {
		if((size-2)>=0) return size-2; else return 0;
	} else {
		return size-1;
	}
}


/*
int low_2_search(struct column0 *a, int size, int b)
{
int i; 
for(i=b-1;i>=0;i--){	
		if ((a[i].increase==-1) && (a[i+1].increase==-1)){
		return i+2;
		}
}
return 0;
}
*/

int low_2a_search(int a[], int size, int b)
{
	int i;
	for(i=b-1;i>=0;i--){
		if ((a[i]==-1) && (a[i+1]==-1)){
			return i+1; // "The area under curve" includes the valley bottom points.
		}
	}
	return 0;
}


int low_3_search(struct column0 *a, int size, int b, double threshold)
{
	int i;
	for(i=b-1;i>=0;i--){
		if (a[i].intensiT < threshold){
			return i+1;
		}	
	}
	return 0;
}
/*
int upper_2_search(struct column0 *aa, int size, int b)
{
int i;
for(i=b+1;i<size;i++){
		if ((aa[i].increase==1) && (aa[i-1].increase==1)){
		return i-3;
		}
}
return size;
}
*/

int upper_2a_search(int a[], int size, int b)
{
	int i;
	for(i=b+1;i<size;i++){
		if ((a[i]==1) && (a[i-1]==1)){
			return i-2;  //"The area under curve" includes the valley bottom points.
		}
	}
	return (size-1);
}


int upper_3_search(struct column0 *aa, int size, int b, double threshold)
{
	int i;
	for(i=b+1;i<size;i++){
		if (aa[i].intensiT < threshold){
			return i-1;
		}
	}
	return (size-1);
}

int assign_the_difference(struct column0 *aa, int b)
{
	if(b != 0){
		if(aa[b].intensiT > aa[b-1].intensiT)
		return 1;
		else if (aa[b].intensiT < aa[b-1].intensiT)
		return -1;
		else
		return 0;
	} else {
		return 0;
	}
}

double PPintegratorA(char* rawfilename, int bestScan, float precmz, int addinfo, int given_heavy_n_search_light, float* starting_time,  float* end_time, float* max_R_time, int *max_scan_num, float mz_error, int num_of_KK, int *real_max_scan_num, float* real_max_inten, float* max_smoo_inten, vector<struct intern_calib>& qq){

	
	int debug=0, debug_b4=0;
	RAMPFILE* rawf;
	struct peakscanheader allscans, *thescans;
	ramp_fileoffset_t scanindex;
	int i,j,lscan;
	int pscan=0,ppeakcount=0; /*PTMap2*/ // the scannum and peakcount of the precursor scan of the MS/MS scan 
	char *temp0;
	bool highresMS,highresMSMS,CentroidMS, NormalIso;

	precursorManager* pmanager;
	struct precursorGroup* currpGroup;
	ScanHeaderStruct precHeader;	// precursor scan header
	float SILACpmz;
	RAMPREAL* temprpeaks;
	double IntMassSum, IntSum, SILACIntMassSum,SILACIntSum;
	//YingHua's modification begin here
	//
	float TT321,upperRB,lowerRB,lowerRB_b4deconvo,upperRB_b4deconvo;
	int upperScan,lowerScan;
	int ms1_scan_index, member_index, index_best, member_index2, member_indexb4;
	double summ_intensity;
	int lower_cut,upper_cut;
	int low_cut_candi[3];
	int upper_cut_candi[3];
	double real_area, upper_limit_real_area;
	column0 * whole_column_pt = new column0[1800];
	column0 * whole_column_ptb4 = new column0[1800];
	double bArray[2700];
	int group[400];
	int size1, delta, size2, delta2,size1a,size2a,size_of_bArray;
	int apex, apex1, apex2, lower_cut_pt, upper_cut_pt;
	double temp_max1, temp_max2, maxx;
	bool flag01;
	float ref_column_width, time_allowance_b4, time_allowance_after, time0_allowance_b4, time0_allowance_after;
	int ii;
	int size_of_whole_column_pt, size_of_whole_column_ptb4;
	int up01,down01;
	int index_bestb4, apex1b4, apex2b4, upper_cut_ptb4, lower_cut_ptb4, apexb4, lower_cutb4, upper_cutb4, low_cut_candib4[3], upper_cut_candib4[3];
	double temp_max1b4, temp_max2b4, maxxb4, temp;
	bool dump_trig;
	int MM;
	double c01,c02,c03;
	struct intern_calib temp_ele_qq;
	struct mz_intensity_pair {
		float mz;
		float intensiT;
	};
	mz_intensity_pair temp_elem;
	unsigned counter;
	vector<float> PCMMmz;
	float PCMmz, PCMupperRB, PCMlowerRB, delta_mz;
	bool fetch_prior, calibration01;
	int pre_low_cut, pre_upper_cut, pre_low_cutb4, pre_upper_cutb4;
	const float mass_PCM = 445.120025;  //only used when calibration01=false;
	float mz_error_10 = 1.000000E-05;
	
	// The next line is variables used in light peak search
	// float t0,t2,t_max; bool flag02,flag02b4; float peak_R_time_upper_bound, peak_R_time_lower_bound, R_time_upper_bound, R_time_lower_bound;

	//weights for intensity smoothing We are trying 0.18, 0.20, 0.24, 0.20, 0.18; other candidate 0.15, 0.22, 0.26
	c01=0.1800; c02=0.2000; c03=0.2400; //A
	//c01=0.1500; c02=0.2200; c03=0.2600;   //B    //c01=0.1800; c02=0.2000; c03=0.2400;
	cout <<"bestScan=" << bestScan << endl;

	rawf = rampOpenFile(rawfilename);
	if(rawf==NULL){
		cout<<"Error: Cannot open mzXML file. rawfilename: "<<rawfilename<<endl;
		return -20.000;
	}
	
	calibration01=true; //false means that we will use lock mass to calibrate m/z zone we search
	//true means just use the value given

	//initial screening
	//time0_allowance_b4 = 8.00;//30.000; // for apex_start (light) from t_max (heavy)
	//time0_allowance_after = 12.00;//50.000;

	//final   screening
	//time_allowance_b4 = 10.00;//20.000; // for apex_start (light) from t_max (heavy)
	//time_allowance_after = 15.00;//40.000;

	//Retention Time control -> only for light peak.

	if (addinfo == 1) {
		lowerScan=bestScan-799;
		upperScan=bestScan+999;
		if (calibration01==true){
			upperRB= precmz*(1.0000000+mz_error); //mz_error as a margin 1.000e-5 is 5ppm
			lowerRB= precmz*(1.0000000-mz_error);
			lowerRB_b4deconvo = lowerRB - 3.0000;
			upperRB_b4deconvo = upperRB + 1.0000;
			cout << "lowerRB=" <<lowerRB<< "   upperRB="<<upperRB<<"   lowerScan="<<lowerScan<<"    upperScan="<< upperScan<<endl;
			cout << "lowerRB_b4deconvo=" <<lowerRB_b4deconvo<< "   upperRB_b4deconvo="<<upperRB_b4deconvo<<endl;
		}
	}
	
	pmanager = new precursorManager();
	highresMS = true;
	CentroidMS = true;

	scanindex = getIndexOffset(rawf);
	ramp_fileoffset_t * allscansoffset = readIndex(rawf, scanindex, &lscan);
	thescans = &allscans;
	Collector* gbcl;
	temp0 = (char*) calloc(100000, sizeof(char));
	gbcl = new Collector(temp0,100000);
	ms1_scan_index=0;
	member_index=0;
	member_indexb4=0;
	summ_intensity=0;
	member_index2=0;
	flag01 = true;
	PCMMmz.clear();	
	if (lowerScan < 0) {
		lowerScan=0;
	}
	if (upperScan > (lscan+1)) {
		upperScan=lscan+1; //because the last scan is indexed as lscan
	}

	for (i=lowerScan;i<upperScan;i++){
		readHeader(rawf, allscansoffset[i], &(thescans->scanheader));
		if(thescans->scanheader.msLevel==1){
			ms1_scan_index++;
			pscan = i;
			thescans->rpeaks = readPeaks(rawf, allscansoffset[i]);
			readHeader(rawf, allscansoffset[pscan],&precHeader); //this is the only function of pscan, may use i instead?

			if (calibration01==false){//i.e. The machine was not using PCM internal calibration but MaxQuant did. 
				// so the out put of MaxQuant is corrected mass (shifted) ..... to fetch the peak from rawfile generated
				// by machine,  we need to shift our mz_search_range back.
				// Then we should employ PCM as lock mass 445.120025.
				// I.  Get the starting/end point of the scan which match 445.120025 +/- 15 ppm in dichotomy way.
				// II. A) Scan and take (mass, intensity), B) Take the mz correspondant to the largest intensity
				// III.calculate out the adjustment amount.
				// IV. assign the upperRB, lowerRB, lowerRB_b4deconvo, upperRB_b4deconvo

				//Now stage I

				PCMlowerRB = mass_PCM*(1.0000000-mz_error_10);
				PCMupperRB = mass_PCM*(1.0000000+mz_error_10);
				ppeakcount = precHeader.peaksCount;

				size1 = int (ppeakcount/2);
				delta = int (size1/2);
				while (delta >= 2){
					if (thescans->rpeaks[2*size1] < PCMlowerRB){
						size1 += delta;
					} else {
						size1 -= delta;
					}
					delta = int (delta/2);
				}
				if ( thescans->rpeaks[2*size1] > PCMlowerRB){
					size1 -= (delta*4);
				}

				size2 = int(ppeakcount/2);
				delta2 = int (size2/2);
				while (delta2 >= 2){
					if (thescans->rpeaks[2*size2] < PCMupperRB){
						size2 += delta2;
					} else {
						size2 -= delta2;
					}
					delta2 = int (delta2/2);
				}
				if ( thescans->rpeaks[2*size2] < PCMupperRB){
					size2 += (delta2*4);
				}

				//if (thescans->rpeaks[2*size2] < PCMupperRB) {
				//cout << "Boom, n is too small in the expression size2 += (delta2*n); size2="<<size2<<"  thescans->rpeaks[2*size2]="<< thescans->rpeaks[2*size2]<<"   PCMupperRB="<<PCMupperRB<<endl;
				//}
				//finding size1 is to find nearest to but smaller than PCMlowerRB, is it possible there is nothing smaller than PCMlowerRB?
				//finding size2 is to find nearest to but larger than PCMupperRB, is it possible there is nothing larger than PCMupperRB?
				//It is impossible (size2 <=  size1)
				
				size1a = size1*2;
				size2a = size2*2;
				counter=0;
				for(j=size1a;j<size2a;j++){
					if (j % 2==0){
						if (thescans->rpeaks[j] <= PCMupperRB){
							if (thescans->rpeaks[j] >= PCMlowerRB){

								if (counter==0) {
									temp_elem.mz = thescans->rpeaks[j];
									temp_elem.intensiT = thescans->rpeaks[j+1];
								} else {
									if (thescans->rpeaks[j+1]>temp_elem.intensiT) { //take the largest intensity
										temp_elem.mz =  thescans->rpeaks[j];
										temp_elem.intensiT = thescans->rpeaks[j+1];
									}
								}
								counter++;

							}
						} else {
							break;
						}
					}//if (j % 2==0){
				}//for(j=size1a;j<size2a;j++){
				fetch_prior= false;
				if (counter>0){
					PCMmz = temp_elem.mz;
					PCMMmz.push_back(PCMmz);
				} else {
					fetch_prior=true;
				}

				if (fetch_prior==true) {
					if (PCMMmz.size()>3){
						PCMmz = (PCMMmz[PCMMmz.size()-1] + PCMMmz[PCMMmz.size()-2] + PCMMmz[PCMMmz.size()-3] + PCMMmz[PCMMmz.size()-4])/4;
					} else if (PCMMmz.size()>2){
						PCMmz = (PCMMmz[PCMMmz.size()-1] + PCMMmz[PCMMmz.size()-2] + PCMMmz[PCMMmz.size()-3])/3;
					} else if (PCMMmz.size()>1){
						PCMmz = (PCMMmz[PCMMmz.size()-1] + PCMMmz[PCMMmz.size()-2])/2;
					} else if (PCMMmz.size()>0){
						PCMmz = PCMMmz[PCMMmz.size()-1];
					} else { // (PCMMmz.size()==0)
						PCMmz = 445.120025;
					}
				}
				// delta_mz = PCMmz - 445.120025;
				//Turn premz from theo to actual by adding (actual - theo)
				// precmz += delta_mz; //if read-in precmz is theoretical value; (corrected in Da not in ppm) 
				///CORRECT Perl, use theoretical value as input.
				//
				precmz = precmz * PCMmz/445.120025;
				upperRB = precmz*(1.0000000+mz_error_10);
				lowerRB = precmz*(1.0000000-mz_error_10);
				lowerRB_b4deconvo = lowerRB - 3.0000;
				upperRB_b4deconvo = upperRB + 1.0000;     
			}//if (calibration01==false)


			//if (addinfo == 0) {
			if ((flag01 == true) && (member_index !=0)) {        //get ref_column_width for single column case.
				ref_column_width = precHeader.retentionTime - TT321;
				flag01 = false;
				cout << "in PPintegratorA ref_column_width= " << ref_column_width << endl;
			} // this takes the time difference between first column getting into desired mz zone and its next ms1 scan.
			// The value will be used in single column case; or be reset when the ((upper_cut - lower_cut) >=1 ).
			//if (( precHeader.retentionTime < R_time_lower_bound ) || ( precHeader.retentionTime > R_time_upper_bound)) { //Retention Time control
			//  continue;                                    //t0= *starting_time; t2= *end_time;
			//}	      
			//}

			ppeakcount = precHeader.peaksCount;
			TT321 = precHeader.retentionTime;  //sssizz = 2*ppeakcount;
			
			size1 = int (ppeakcount/2);
			delta = int (size1/2);
			while (delta >= 2){
				if (thescans->rpeaks[2*size1] < lowerRB_b4deconvo){
					size1 += delta;
				} else {
					size1 -= delta;
				}
				delta = int (delta/2);
			} 	    
			if ( thescans->rpeaks[2*size1] > lowerRB_b4deconvo){
				size1 -= (delta*4);
			}
			
			size2 = int(ppeakcount/2);
			delta2 = int (size2/2);
			while (delta2 >= 2){
				if (thescans->rpeaks[2*size2] < upperRB_b4deconvo){
					size2 += delta2;
				} else {
					size2 -= delta2;
				}
				delta2 = int (delta2/2);
			}
			if ( thescans->rpeaks[2*size2] < upperRB_b4deconvo){
				size2 += (delta2*4);
			}
			
			if (size2 == size1) { continue;}  // this means there is nothing between lowerRB and upperRB in mz domain
			//############################

			//below, ms1_scan_index is MS1 scan order number which is not the same as i (the real scannumber) because
			//there are some scans are ms2 in real scannumber.
			size1a = size1*2;
			size2a = size2*2;

			counter=0;
			for(j=size1a;j<size2a;j++){
				if (j % 2==0){
					if (thescans->rpeaks[j] <= upperRB){
						if (thescans->rpeaks[j] >= lowerRB){
							if (counter==0) {
								temp_elem.mz = thescans->rpeaks[j];
								temp_elem.intensiT = thescans->rpeaks[j+1];
							} else {
								if (thescans->rpeaks[j+1]>temp_elem.intensiT) { //take the largest intensity
									temp_elem.mz =  thescans->rpeaks[j];
									temp_elem.intensiT = thescans->rpeaks[j+1];
								}
							}
							counter++;
						}
					} else {
						if (counter>0){
							whole_column_ptb4[member_indexb4].scan_index = ms1_scan_index;
							whole_column_ptb4[member_indexb4].scan_num= i;
							whole_column_ptb4[member_indexb4].R_time = TT321;
							whole_column_ptb4[member_indexb4].mz1 = temp_elem.mz;
							whole_column_ptb4[member_indexb4].intensiT = temp_elem.intensiT;
							member_indexb4++;
						}
						break;
					}
				}//if (j % 2==0){
			}//for(j=size1a;j<size2a;j++){
			//size_of_whole_column_ptb4 = member_indexb4;
			
			deconvolute( thescans->rpeaks, size1,  size2, bArray, group, 0);

			//int deconvolute(double *rpeaks, int k1, int k2, int k, double *bArray, int *group,int show){
			size_of_bArray = 3*(size2 - size1 +1);
			// Here we need to add a screening that if there are two or more elements in the array, we will keep the element of largest intensity.
			// If we put screen here, there is at most only one element per scannum. If we also put such scrrening at correspondent 
			// place before generasting array whole_column_ptb4.... Then our b4-after-screening meaning has CHANGED FROM 
			// "(# of peaks in b4) and (# of peaks in after) are the same" TO if "there exist at least one peak for both case b4 and after in this scan"
			// Therefore the case that there are 3 peaks in b4 and 2 peaks in after will pass the screening.

			counter=0;
			for(j=0;j<size_of_bArray;j++){
				if (j % 3==0){
					if (bArray[j] <= upperRB){
						if (bArray[j] >= lowerRB){
							if (counter==0) {
								temp_elem.mz = bArray[j];
								temp_elem.intensiT = bArray[j+1];
							} else {
								if (bArray[j+1]>temp_elem.intensiT) {  //take the largest intensity
									temp_elem.mz = bArray[j];
									temp_elem.intensiT = bArray[j+1];
								} 
							}
							counter++;
						}
					} else {
						if (counter>0){
							whole_column_pt[member_index].scan_index = ms1_scan_index;
							whole_column_pt[member_index].scan_num= i;
							whole_column_pt[member_index].R_time = TT321;
							whole_column_pt[member_index].mz1 = temp_elem.mz;
							whole_column_pt[member_index].intensiT = temp_elem.intensiT;
							member_index++;
						}
						break;
					}
				}//if (j % 3==0){
			}//for(j=0;j<size_of_bArray;j++){
			//size_of_whole_column_pt = member_index;	    
		}//if(thescans->scanheader.msLevel==1)
	}//for (i=lowerScan;i<upperScan;i++){
	size_of_whole_column_ptb4 = member_indexb4;
	size_of_whole_column_pt = member_index;
	cout <<"member_indexb4="<< member_indexb4 << endl;
	cout << "member_index=" << member_index << endl;


	cout << "####### BEGINNING OF THE ANALYSIS OF \"AFTER DECONVOLUTION\" #######" << endl;
	//cout << "LET'S PRINT OUT THINGS AFTER DECONVOLUTION: ";
	cout << "size_of_whole_column_pt= " << size_of_whole_column_pt <<endl;
	cout << "To get detailed print out, set debug=2 or 3." << endl;
	if (debug >=3) {
		cout << "Original array whole_column_pt:"<<endl;
		cout << "i\tscan_index\tscan_num\tR_time(in sec)\t(in min)\tmz\tintensiT\n";
		for (i=0; i< size_of_whole_column_pt; i++) {
			cout << "SSSD "<<i<<"\t"<< whole_column_pt[i].scan_index <<"\t"<<whole_column_pt[i].scan_num<<"\t";
			cout << whole_column_pt[i].R_time<<"\t"<<whole_column_pt[i].R_time/60<<"\t";
			cout << std::setprecision(6) <<whole_column_pt[i].mz1<<"\t";
			cout << whole_column_pt[i].intensiT<<endl;//"\t"<< whole_column_pt[i].intensmooth<<endl;
		}
		cout << endl;
	}
	//Algorithm plan
	//1. get max close to the best scan number given by maxquant output,
	//2. take close interval which is bounded with the max and best_local (given from 
	//   output of maxquant) as assured column
	//3. Push "lower_bound_indicator1" (its domain is the same as member index.) from middle assured area lower 
	//   down to where scan_index has a gap more than 2.
	//   The indicator should fall onto the inner next to the gap
	//4. Push "lower_bound_indicator2" (its domain is the same as member index.) from middle assured area lower
	//   down to where continuous two "-1" happen to variable increase and the minimum intensity is less than
	//   20% of the average of middle assured area.
	//5. Push "lower_bound_indicator3" (its domain is the same as member index.) from middle assured area lower
	//   down to where continuous two "-1" happen to variable increase and the minimum intensity is less than
	//   5% of the average of middle assured area.
	//6. Repeat step 3-5 for upper bound in the oppisite direction.

	//if (addinfo12345 == 1) { //OK, 100 Lines below
	index_best = bestscan_search2(whole_column_pt,size_of_whole_column_pt,bestScan);
	if (index_best == -1) {
		cout << "Wine Wine.. we cannot find the peak. No peak in bestScan falls in the defined mz range. ";
		return -1.000;
		// add code in main.cpp, if return value == -1,
		// next sequence. because no best_scan  => no peak defined => no MS1 peak area => no stoichi. 
	} else if (((bestScan - whole_column_pt[index_best].scan_num) > 120) && (size_of_whole_column_pt <=5)) {
		for (i=0; i< size_of_whole_column_pt; i++) {
			if (whole_column_pt[i].intensiT==0) { cout << "Probably a bad peak, small & interferenced, and MQ did not judge right."<<endl; return -1.000;}
		}	  
	} else {
		cout << "#The previous and closest scannumber to given bestscan is: " << whole_column_pt[index_best].scan_num << endl;
		if (debug >=3) {
			cout << "#the correspondent member_index is: " << index_best << endl;
		}
		cout << "# Its intensity is :" << whole_column_pt[index_best].intensiT << endl;
	}

	if (debug >=3) {
		cout << "size_of_whole_column_pt= "<< size_of_whole_column_pt <<endl;
		cout << "index_best  =" << index_best << endl;
		cout << "If bestScan is given, index_best is nearest before given bestScan." << endl;
	}

	pre_low_cut  =low_0_search(whole_column_pt, size_of_whole_column_pt, index_best);  //check continuity, allow one scan go out of mz zone or value of zero
	pre_upper_cut=upper_0_search(whole_column_pt, size_of_whole_column_pt, index_best);

	if (debug >=3) {
		cout << "  pre_low_cut=" << pre_low_cut<< endl;
		cout << "   index_best=" << index_best<<endl;
		cout << "pre_upper_cut=" << pre_upper_cut<< endl;
	}

	int size_of_possible_column_pt=pre_upper_cut - pre_low_cut+1;
	column0 * possible_column_pt = new column0[size_of_possible_column_pt];
	copy(whole_column_pt+pre_low_cut, whole_column_pt+pre_upper_cut+1, possible_column_pt);
	index_best -= pre_low_cut;
	if (debug >=2) {
		cout << "now index_best=" << index_best;
		cout << "    possible_column_pt[index_best].scan_num= " << possible_column_pt[index_best].scan_num << endl;
	}
	//SMOOTHING
	if (size_of_possible_column_pt >= 4) {
		possible_column_pt[0].intensmooth = (c03*possible_column_pt[0].intensiT+c02*possible_column_pt[1].intensiT+c01*possible_column_pt[2].intensiT)/(c01+c02+c03);
		possible_column_pt[size_of_possible_column_pt-1].intensmooth = (c03*possible_column_pt[size_of_possible_column_pt-1].intensiT+c02*possible_column_pt[size_of_possible_column_pt-2].intensiT+c01*possible_column_pt[size_of_possible_column_pt-3].intensiT)/(c01+c02+c03);
		possible_column_pt[1].intensmooth = (c02*possible_column_pt[0].intensiT+c03*possible_column_pt[1].intensiT+c02*possible_column_pt[2].intensiT+c01*possible_column_pt[3].intensiT)/(c01+2*c02+c03);
		possible_column_pt[size_of_possible_column_pt-2].intensmooth = (c01*possible_column_pt[size_of_possible_column_pt-4].intensiT +c02*possible_column_pt[size_of_possible_column_pt-3].intensiT +c03*possible_column_pt[size_of_possible_column_pt-2].intensiT +c02*possible_column_pt[size_of_possible_column_pt-1].intensiT)/(c01+2*c02+c03);
		if (size_of_possible_column_pt > 4){
			for (i=2; i<(size_of_possible_column_pt-2); i++) {
				possible_column_pt[i].intensmooth = c01*possible_column_pt[i-2].intensiT+c02*possible_column_pt[i-1].intensiT+c03*possible_column_pt[i].intensiT+c02*possible_column_pt[i+1].intensiT+c01*possible_column_pt[i+2].intensiT;
			}
		}
	} else if (size_of_possible_column_pt == 3) {
		possible_column_pt[0].intensmooth = (c03*possible_column_pt[0].intensiT+c02*possible_column_pt[1].intensiT\
		+c01*possible_column_pt[2].intensiT)/(c01+c02+c03);
		possible_column_pt[1].intensmooth = (c02*possible_column_pt[0].intensiT+c03*possible_column_pt[1].intensiT\
		+c02*possible_column_pt[2].intensiT)/(2*c02+c03);
		possible_column_pt[2].intensmooth = (c03*possible_column_pt[2].intensiT+c02*possible_column_pt[1].intensiT\
		+c01*possible_column_pt[0].intensiT)/(c01+c02+c03);
	} else {
		for (i=0; i<size_of_possible_column_pt; i++) {
			possible_column_pt[i].intensmooth = possible_column_pt[i].intensiT;
		}
	}

	cout << "size_of_possible_column_pt= " << size_of_possible_column_pt <<endl;
	if (debug >=2) {
		cout << "i\tscan_index\tscan_num\tR_time(in sec)\t(in min)\tmz\tintensiT\n";
		//cout << "i scan_index  scan_num\t   R_time\t intensiT\n";
		for (i=0; i< size_of_possible_column_pt; i++) {
			cout << "MMMD "<<i<<"\t"<< possible_column_pt[i].scan_index <<"\t"<<possible_column_pt[i].scan_num<<"\t";
			cout << possible_column_pt[i].R_time<<"\t"<<possible_column_pt[i].R_time/60<<"\t";
			cout << std::setprecision(6) <<possible_column_pt[i].mz1<<"\t";
			cout << possible_column_pt[i].intensiT<<"\t"<< possible_column_pt[i].intensmooth<<endl;
		}
		cout << endl;
	}
	//search apex1 and upper bound  & search apex2 and lower bound
	apexcandi_search(possible_column_pt, size_of_possible_column_pt, index_best, &apex1, &apex2, &upper_cut_pt, &lower_cut_pt);
	temp_max1 = possible_column_pt[apex1].intensmooth;
	temp_max2 = possible_column_pt[apex2].intensmooth;
	if (temp_max1 > temp_max2) {
		apex = apex1;
		maxx = temp_max1;
	} else {
		apex = apex2;
		maxx = temp_max2;
	}
	if (debug >=2) {
		cout <<"apex1="<< apex1<<"  temp_max1="<< temp_max1 << endl;
		cout <<"apex2="<< apex2<<"  temp_max2="<< temp_max2 << endl;
		cout <<" apex="<< apex2<<"       maxx="<< maxx << endl;
	}


	cout << "# index_best =" << index_best << endl;
	cout << "index_best is nearest before given bestScan if bestScan is given." << endl;
	cout << "index_best is the apex judged by non-smoothed intensity." << endl;
	cout << "# apex (0 < apex <size_of_possible_column_pt) =" << apex << endl;
	cout << "# The correspondent scan_num:    " << possible_column_pt[apex].scan_num << endl;
	cout << "# the correspondent R-time:      " << possible_column_pt[apex].R_time << endl;
	// cout << "# Its intensity is :" << possible_column_pt[index_best].intensiT << endl;

	low_cut_candi[1]  = lower_cut_pt; //low_2_search(possible_column_pt, size_of_possible_column_pt, apex);
	upper_cut_candi[1]= upper_cut_pt; //upper_2_search(possible_column_pt, size_of_possible_column_pt, apex);
	low_cut_candi[0]  =  low_1_search(possible_column_pt, size_of_possible_column_pt, apex); //judge going out by MS1scannum
	low_cut_candi[2]  =  low_3_search(possible_column_pt, size_of_possible_column_pt, apex, possible_column_pt[apex].intensiT*0.05); //judge by height only
	upper_cut_candi[0]=upper_1_search(possible_column_pt, size_of_possible_column_pt, apex);
	upper_cut_candi[2]=upper_3_search(possible_column_pt, size_of_possible_column_pt, apex, possible_column_pt[apex].intensiT*0.05);
	for (ii=0; ii<3; ii++){
		if ((low_cut_candi[ii] > 10000)||(low_cut_candi[ii] < -10000)) {
			low_cut_candi[ii] = 0 ;
		}
	}
	cout << "low_cut_candi:  "<<low_cut_candi[0]<<"  "<<low_cut_candi[1]<<"  "<<low_cut_candi[2]<<endl;
	cout << "upper_cut_candi:"<<upper_cut_candi[0]<<"  "<<upper_cut_candi[1]<<"  "<<upper_cut_candi[2]<<endl;
	lower_cut = max_int_array(low_cut_candi,3);
	upper_cut = min_int_array(upper_cut_candi,3);
	if (lower_cut == 0) {
		cout << "You may have to make  ### here larger. lowerScan = bestScan - ###;" << endl;
	}
	if (upper_cut == size_of_possible_column_pt) {
		upper_cut--;
		cout << "You may have to make  ### here larger. lowerScan = bestScan + ###;" << endl;
	}
	cout<<"lower_cut= "<< lower_cut <<"   upper_cut= "<< upper_cut <<endl;
	//B4B4B4B4B4B4B4B4B4B4B4B4B4B4B4B4{
	cout<<"The correspondent retention time is from "<< possible_column_pt[lower_cut].R_time;
	cout<<" to " << possible_column_pt[upper_cut].R_time << endl;
	cout<<"The correspondent scan_num is from "<< possible_column_pt[lower_cut].scan_num;
	cout<<" to " << possible_column_pt[upper_cut].scan_num << endl;


	// OK before we reversion to this version which has the allowance in "comparing b4-after deconvolution"
	// we had   1. index_best
	//          2. pre_low_cut, pre_upper_cut (check continuity) 
	//          2-1. copy whole_column_pt to  possible_column_pt  
	//          3. smoothing 
	//          4. finding apexes 
	//          5. finding upper_cut and lower_cut 
	// on both b4-array and after-array.

	// In this version, we would like to skip these procedure on b4-array.
	// Just finished the 4 steps mentioned here on after-array and then compare after-array(not smoothed) with b4-array.
	// The guideline of the comparison:
	//    0. initialize counter=0; Differ_lmt=0;
	//    1. scope from lowerbound to upper bound
	//    2. check if scannum are the same
	//    3. check if intensity is zero
	//       3a if yes, (1) counter++;  (2) Differ_limt += the intensity in b4array (3)
	//    4. at the end of each loop, check if ( counter > floor(threshold_ratio * (upper bound - lower bound +1)) )
	//    5. at the end check if the ratio Differ_lmt/sum < 0.1
	//                  Upper_limit = sum + Differ_lmt

	
	cout << "#################################" <<endl;
	//B4B4B4B4B4B4B4B4B4B4B4B4B4B4B4B4{
	// About *starting_time, *end_time, we reset it to new value only when value "real_area" is returned.


	dump_trig = true;

	//finding the start

	double sum01 = 0.00000;  //This sum is used to roughly estimate the area under the curve. However  
	int counterR = 0;     // the real sum is variable real_area in which time width is considered.
	double Differ_lmt =0.0000;
	double threshold_ratio_for_column_number = 0.200;
	double threshold_ratio_for_area = 0.150;
	int threshold01 = floor(threshold_ratio_for_column_number * (upper_cut -lower_cut +1));
	int lower_cut_whole_b4,q;
	double mismatch_frac=0, Upper_limit;
	
	
	
	for (i=0; i< size_of_whole_column_ptb4; i++) {
		if (whole_column_ptb4[i].scan_num == possible_column_pt[lower_cut].scan_num) {
			lower_cut_whole_b4 = i;
			break;
		}
	} 
	for (i=lower_cut; i<=upper_cut; i++) {
		sum01 += possible_column_pt[i].intensiT;
		if (possible_column_pt[i].intensiT ==0) {
			counterR++;
			//Differ_lmt += possible_column_ptb4[i].intensiT;
			q = lower_cut_whole_b4 - lower_cut + i;
			Differ_lmt += whole_column_ptb4[q].intensiT;
			possible_column_pt[i].intensiT2 = whole_column_ptb4[q].intensiT; 
			// We will use this assigned value intensiT2 in function summatioNproduct()
			// Then the function gives both lower limit (function value) and upper limit(passed by address)
			// summatioNproduct() consider time of each bin, but mismatch_frac is still a good rough estimate.
		}
		if (counterR > threshold01) { //That means if missing 2 columns in 10 cloulmn 2 <= 0.2*10 , it will not return -8.
			cout << "The number of mismatches between b4 and after deconvolution array is over the threshold."<<endl;
			return -8.0000;
		}
	}
	if (sum01 > 0) {
		mismatch_frac = Differ_lmt/sum01;
	} else {
		cout << "trouble!" << endl;
	}

	Upper_limit = sum01 + Differ_lmt;
	
	if (mismatch_frac > threshold_ratio_for_area) {
		cout << "The (area under curve) of mismatch between b4 and after deconvolution array is over the threshold." <<endl;
		return -8.0000;
	}
	//pass Upper_limit out of function.


	cout << "#################################" <<endl;
	//B4B4B4B4B4B4B4B4B4B4B4B4B4B4B4B4{
	// About *starting_time, *end_time, we reset it to new value only when value "real_area" is returned.


	cout << "lower_cut=" << lower_cut <<"    upper_cut= " << upper_cut << endl;
	if (lower_cut > upper_cut) {
		cout << "  lower_cut > upper_cut" <<endl;
		return -1.000;
	} else if (lower_cut < upper_cut) {
		cout << "possible_column_pt[lower_cut].R_time=" << possible_column_pt[lower_cut].R_time <<endl;
		cout << "possible_column_pt[upper_cut].R_time=" << possible_column_pt[upper_cut].R_time <<endl;
		real_area = summatioNproduct(possible_column_pt, lower_cut, upper_cut, &upper_limit_real_area);
		cout << "real area_P = "<< real_area <<"\t\t";
		cout << "upper_limit_real_area = "<< upper_limit_real_area <<endl;
		qq.clear();
		for (j = lower_cut; j <= upper_cut; j++) {
			temp_ele_qq.mz = possible_column_pt[j].mz1;
			temp_ele_qq.scannum = possible_column_pt[j].scan_num;
			temp_ele_qq.time = possible_column_pt[j].R_time;
			qq.push_back(temp_ele_qq);
		} 
		*max_smoo_inten = possible_column_pt[apex].intensmooth;
		*max_R_time = possible_column_pt[apex].R_time;
		*max_scan_num = possible_column_pt[apex].scan_num;
		*starting_time = possible_column_pt[lower_cut].R_time;
		*end_time = possible_column_pt[upper_cut].R_time;
		return real_area;
	} else {
		cout << "area of one_column case" << endl;
		cout << "possible_column_pt[lower_cut].R_time=" << possible_column_pt[lower_cut].R_time << endl; 
		cout << "possible_column_pt_pt[upper_cut].intensiT = " << possible_column_pt[upper_cut].intensiT << endl;
		cout << "initial ref_column_width = " << ref_column_width << endl;
		if (size_of_possible_column_pt>3) {
			if (upper_cut==0) {
				up01=(possible_column_pt[upper_cut+1].scan_index -  possible_column_pt[upper_cut].scan_index);
				ref_column_width = possible_column_pt[upper_cut+1].R_time - possible_column_pt[upper_cut].R_time;
				ref_column_width = ref_column_width/up01;
			} else if (upper_cut == size_of_possible_column_pt-1) {
				down01 = (possible_column_pt[upper_cut].scan_index - possible_column_pt[upper_cut-1].scan_index);
				ref_column_width = possible_column_pt[upper_cut].R_time - possible_column_pt[upper_cut-1].R_time;
				ref_column_width = ref_column_width/down01;
			} else {
				
				up01=(possible_column_pt[upper_cut+1].scan_index -  possible_column_pt[upper_cut].scan_index);
				down01 = (possible_column_pt[upper_cut].scan_index -  possible_column_pt[upper_cut-1].scan_index);
				if ((up01-down01)>3){
					ref_column_width = possible_column_pt[upper_cut].R_time - possible_column_pt[upper_cut-1].R_time;
					ref_column_width = ref_column_width/down01;
				} else if ((up01-down01)<-3) {
					ref_column_width = possible_column_pt[upper_cut+1].R_time - possible_column_pt[upper_cut].R_time;
					ref_column_width = ref_column_width/up01;
				} else {
					ref_column_width = possible_column_pt[upper_cut+1].R_time - possible_column_pt[upper_cut-1].R_time;
					ref_column_width = ref_column_width/(up01+down01);
				}
			}
		} // if size_of_possible_column_pt >3 not does not hold,... ref_column_width was defined LN 593 - 602
		real_area = ref_column_width * possible_column_pt[upper_cut].intensiT;
		cout << "final ref_column_width = " << ref_column_width << endl;
		cout << "real area_P = "<< real_area <<endl;
		qq.clear();
		temp_ele_qq.mz = possible_column_pt[lower_cut].mz1;
		temp_ele_qq.scannum = possible_column_pt[lower_cut].scan_num;
		temp_ele_qq.time = possible_column_pt[lower_cut].R_time;
		qq.push_back(temp_ele_qq);
		*max_smoo_inten = possible_column_pt[apex].intensmooth;
		*max_R_time = possible_column_pt[apex].R_time;
		*max_scan_num = possible_column_pt[apex].scan_num;
		*starting_time = possible_column_pt[lower_cut].R_time; 
		*end_time = possible_column_pt[upper_cut].R_time;
		return real_area ;
	}
}
double PPintegratorB(char* rawfilename, int bestScan, float precmz,int addinfo,int given_heavy_n_search_light, float* starting_time,  float* end_time, float* max_R_time, int *max_scan_num,float mz_error,int num_of_KK, int *real_max_scan_num, float* real_max_inten, float* max_smoo_inten, float delta_3DH,int charge, vector<struct intern_calib>& qq){

	RAMPFILE* rawf;
	int debug =1;
	struct peakscanheader allscans, *thescans;
	ramp_fileoffset_t scanindex;
	int i, j,lscan;
	int pscan=0,ppeakcount=0; /*PTMap2*/ // the scannum and peakcount of the precursor scan of the MS/MS scan 
	char *temp0;
	bool highresMS,highresMSMS,CentroidMS, NormalIso;

	precursorManager* pmanager;
	struct precursorGroup* currpGroup;
	ScanHeaderStruct precHeader;	// precursor scan header
	float SILACpmz;
	RAMPREAL* temprpeaks;
	double IntMassSum, IntSum, SILACIntMassSum,SILACIntSum;
	//YingHua's modification begin here
	//
	float TT321,upperRB,lowerRB,lowerRB_b4deconvo,upperRB_b4deconvo,t0,t2,t_max;
	int upperScan,lowerScan;
	int ms1_scan_index, member_index, index_best, member_indexb4;
	int lower_cut,upper_cut;
	int low_cut_candi[3];
	int upper_cut_candi[3];
	double real_area, upper_limit_real_area;
	//column0 * possible_column_pt = new column0[800];
	//column0 * possible_column_ptb4 = new column0[1200];
	double bArray[2400];
	int group[400];
	int size1, delta, size2, delta2,size1a,size2a,size_of_bArray;
	int apex, apex1, apex2, lower_cut_pt, upper_cut_pt;
	double temp_max1, temp_max2, maxx;
	bool flag01, flag02;
	float ref_column_width, time_allowance_b4, time_allowance_after, time0_allowance_b4, time0_allowance_after;
	float peak_R_time_upper_bound, peak_R_time_lower_bound, R_time_upper_bound, R_time_lower_bound;
	int ii;
	//int size_of_possible_column_pt, size_of_possible_column_ptb4;
	int up01,down01;
	int index_bestb4, apex1b4, apex2b4, upper_cut_ptb4, lower_cut_ptb4, apexb4, lower_cutb4, upper_cutb4, low_cut_candib4[3], upper_cut_candib4[3];
	double temp_max1b4, temp_max2b4, maxxb4;
	bool flag02b4, dump_trig;
	double c01,c02,c03;
	struct mz_intensity_pair {
		float mz;
		float intensiT;
	};
	mz_intensity_pair temp_elem;
	unsigned counter;
	vector<float> PCMMmz;
	//float PCMmz, PCMupperRB, PCMlowerRB, delta_mz;
	float premz;
	//const float mass_PCM = 445.120025;
	column0 * middle_column_pt = new column0[800];
	column0 * middle_column_ptb4 = new column0[1200];
	column0 * prior_column_pt = new column0[800];
	column0 * prior_column_ptb4 = new column0[1200];
	column0 * posterior_column_pt = new column0[800];
	column0 * posterior_column_ptb4 = new column0[1200];
	unsigned k;
	int priorm_indexb4, priorm_index, posteri_indexb4, posteri_index, insert;
	int size_of_prior_column_ptb4, size_of_prior_column_pt, size_of_posterior_column_ptb4, size_of_posterior_column_pt;
	int size_of_middle_column_ptb4, size_of_middle_column_pt;
	int pre_low_cut, pre_upper_cut, pre_low_cutb4, pre_upper_cutb4;
	bool condition;
	bool Nocaseof_no_overlapping=1;
	double threshold, Lulumi;
	int no_nonzeropeaks_aft_deconv;

	//weights for intensity smoothing We are trying 0.18, 0.20, 0.24, 0.20, 0.18; other candidate 0.15, 0.22, 0.26
	c01=0.1800; c02=0.2000; c03=0.2400; //A
	//c01=0.1500; c02=0.2200; c03=0.2600;   //B    //c01=0.1800; c02=0.2000; c03=0.2400;
	float mz_error_10 = 8.000000E-06;
	//float delta_3DH = 5.025539917;

	rawf = rampOpenFile(rawfilename);
	if(rawf==NULL){
		cout<<"Error: Cannot open mzXML file. rawfilename: "<<rawfilename<<endl;
		return -20.000;
	}
	
	//initial screening
	time0_allowance_b4 = 30.00;//8.00;//30.000; // for apex_start (light) from t_max (heavy)
	time0_allowance_after= 30.00;//12.00;//50.000;

	//final   screening
	time_allowance_b4 = 10;//10.00;//20.000; // for apex_start (light) from t_max (heavy)
	time_allowance_after= 15;//15.00;//40.000;

	cout << "LIGHT PEAK SEARCH STARTS" << endl;
	cout <<"bestScan=" << bestScan << endl;
	cout << "qq.size()=" << qq.size() << endl;
	//Retention Time control
	if (addinfo == 0) {
		t0= *starting_time; //This is right. No need to initialize t0,t2, peak_R_time_upper_bound, peak_R_time_lower_bound, R_time_upper_bound  
		t2= *end_time;      //when  (addinfo == 1), or says, scannum is given by perl.
		t_max= *max_R_time;
		cout << "t0="<< t0 << "   t2=" << t2 <<"   t_max="  << t_max <<endl;
		//check if t0, t2 is wrong.... or in mutiple sites case, find the reason why they are different.
		if (qq[0].time != t0) {
			cout << "TTTT  t0="<< t0 << "    qq[0].time=" << qq[0].time << endl;
		}
		if (qq[qq.size()-1].time != t2 ) {
			cout << "TTTT  t2="<< t2 << "    qq[qq.size()-1].time=" << qq[qq.size()-1].time << endl;
		}

		cout << "bestScan= " << bestScan << endl;
		if (given_heavy_n_search_light==1) {
			//peak_R_time_upper_bound = min_of_two(t_max + time_allowance_after,  t2+1 ); // +15
			//peak_R_time_lower_bound = max_of_two(t_max - time_allowance_b4, t0-1 );    // -10
			peak_R_time_upper_bound = min_of_two(t_max + time_allowance_after, t2+15);
			peak_R_time_lower_bound = max_of_two(t_max - time_allowance_b4, t0-15);
			R_time_upper_bound = t2 + time0_allowance_after;
			R_time_lower_bound = t0 - time0_allowance_b4;
		} else {
			//peak_R_time_upper_bound = min_of_two(t_max + time_allowance_b4, t2+1);    // +10
			//peak_R_time_lower_bound = max_of_two(t_max - time_allowance_after,t0-1); // -15
			peak_R_time_upper_bound = min_of_two(t_max + time_allowance_b4, t2+15);   // +10
			peak_R_time_lower_bound = max_of_two(t_max - time_allowance_after,t0-15); // -15   
			R_time_upper_bound = t2 + time0_allowance_b4;
			R_time_lower_bound = t0 - time0_allowance_after;
		}
	}

	//cout << "lowerRB\tupperRB"<<endl;
	pmanager = new precursorManager();
	highresMS = true;
	CentroidMS = true;

	scanindex = getIndexOffset(rawf);
	ramp_fileoffset_t * allscansoffset = readIndex(rawf, scanindex, &lscan);
	thescans = &allscans;
	Collector* gbcl;
	temp0 = (char*) calloc(100000,sizeof(char));
	gbcl = new Collector(temp0,100000);
	ms1_scan_index=0;
	member_index=0;
	member_indexb4=0;
	flag01 = true;
	ref_column_width=0.0000;  //this is used to calculate area for case that only single-column exists.
	no_nonzeropeaks_aft_deconv=0;
	
	if (addinfo == 0) {
		lowerScan=bestScan-899; //699
		upperScan=bestScan+999; //999
		if (lowerScan < 0){
			lowerScan = 0;
		}
		if ( upperScan > (lscan+1)){
			upperScan = lscan+1;
		}
	}
	cout << "   lowerScan="<<lowerScan<<"    upperScan="<< upperScan<<endl;

	// for (i=lowerScan;i<upperScan;i++){
	// for (i=qq[0].scannum; i=qq[qq.size()-1].scannum; i++) {
	// Instead of using teh above ways to loop, we directly asssgin the scannum, like the following. So we also don't
	// need "if(thescans->scanheader.msLevel==1)"
	cout << "overlapping zone mz lowerRB, middle, upperRB"<< endl;
	for (k=0; k<qq.size(); k++) {
		i= qq[k].scannum;
		readHeader(rawf, allscansoffset[i], &(thescans->scanheader));
		if(thescans->scanheader.msLevel!=1){
			cout << "This way does not work.You have to change the code." << endl;
		}
		ms1_scan_index++;//????now ms1_scan_index == k; so seems redundant.
		pscan = i;
		thescans->rpeaks = readPeaks(rawf, allscansoffset[i]);
		readHeader(rawf, allscansoffset[pscan],&precHeader); //this is the only function of pscan, may use i instead?

		if (given_heavy_n_search_light == 1) {
			upperRB = (qq[k].mz - delta_3DH/charge)*(1.0000000+mz_error);
			lowerRB = (qq[k].mz - delta_3DH/charge)*(1.0000000-mz_error);
			if (debug >=3 ) {
				cout << std::setprecision(8) <<lowerRB<<" "<< (qq[k].mz - delta_3DH/charge) <<" "<<upperRB<<endl;
			}
		} else {
			upperRB = (qq[k].mz + delta_3DH/charge)*(1.0000000+mz_error);
			lowerRB = (qq[k].mz + delta_3DH/charge)*(1.0000000-mz_error);
			if (debug >=3 ) {
				cout << std::setprecision(8) <<lowerRB<<" "<< (qq[k].mz + delta_3DH/charge) <<" "<<upperRB<<endl;
			}
		}
		lowerRB_b4deconvo = lowerRB - 3.00;
		upperRB_b4deconvo = upperRB + 1.00;

		if ((flag01 == true) && (member_index !=0)) {        //get ref_column_width for single column case.
			ref_column_width = precHeader.retentionTime - TT321;
			flag01 = false;
			cout << "in PPintegratorB ref_column_width= " << ref_column_width << endl;
		} 

		ppeakcount = precHeader.peaksCount;
		TT321 = precHeader.retentionTime;  //sssizz = 2*ppeakcount;
		size1 = int (ppeakcount/2);
		delta = int (size1/2);
		while (delta >= 2){
			if (thescans->rpeaks[2*size1] < lowerRB_b4deconvo){
				size1 += delta;
			} else {
				size1 -= delta;
			}
			delta = int (delta/2);
		}
		if ( thescans->rpeaks[2*size1] > lowerRB_b4deconvo){
			size1 -= (delta*4);
		}

		size2 = int(ppeakcount/2);
		delta2 = int (size2/2);
		while (delta2 >= 2){
			if (thescans->rpeaks[2*size2] < upperRB_b4deconvo){
				size2 += delta2;
			} else {
				size2 -= delta2;
			}
			delta2 = int (delta2/2);
		}
		if ( thescans->rpeaks[2*size2] < upperRB_b4deconvo){
			size2 += (delta2*4);
		}
		size1a = size1*2;
		size2a = size2*2;
		size_of_bArray = 3*(size2 - size1 +1);
		for(j=size1a;j<size2a;j++){
			if (j % 2==0){
				if (thescans->rpeaks[j] <= upperRB){
					if (thescans->rpeaks[j] >= lowerRB){
						//if (thescans->rpeaks[j+1] > 100) { //just added
						middle_column_ptb4[member_indexb4].scan_index = ms1_scan_index;
						middle_column_ptb4[member_indexb4].scan_num= i;
						middle_column_ptb4[member_indexb4].R_time = TT321;
						middle_column_ptb4[member_indexb4].mz1 = thescans->rpeaks[j];
						middle_column_ptb4[member_indexb4].intensiT = thescans->rpeaks[j+1];
						Lulumi = middle_column_ptb4[member_indexb4].intensiT;
						//middle_column_pt[member_index].increase= assign_the_difference(middle_column_pt, member_index);
						member_indexb4++;
						//}
					}
				} else {
					break;
				}
			}//if (j % 2==0){
		}//for(j=size1a;j<size2a;j++){
		deconvolute( thescans->rpeaks, size1,  size2, bArray, group, 0);
		for(j=0;j<size_of_bArray;j++){
			if (j % 3==0){
				if (bArray[j] <= upperRB){
					if (bArray[j] >= lowerRB){
						middle_column_pt[member_index].scan_index = ms1_scan_index;
						middle_column_pt[member_index].scan_num= i;
						middle_column_pt[member_index].R_time = TT321;
						middle_column_pt[member_index].mz1 = bArray[j];
						middle_column_pt[member_index].intensiT = bArray[j+1];
						middle_column_pt[member_index].intensiT2= Lulumi;
						//if middle_c*_pt[member_index].intensiT==0, then 0 < (real value) < middle_c*_pt[member_index].intensiT2
						if (middle_column_pt[member_index].intensiT > 100) {
							no_nonzeropeaks_aft_deconv++;
						}
						member_index++;
					}
				} else {
					break;
				}
			}//if (j % 3==0){
		}//for(j=0;j<size_of_bArray;j++){	    
	}// for (k=0; k<qq.size(); k++) {

	size_of_middle_column_ptb4 = member_indexb4;
	size_of_middle_column_pt = member_index;
	//cout << "Just finished the overlapping zone array. Now check.";
	//cout <<"  member_indexb4="<< member_indexb4 ;
	//cout <<"  member_index=" << member_index << endl;
	if (debug >=4) {
		if (member_index > 0) {
			cout << "Compare b4 and after in overlapping zone:" << endl;
			cout << "intensities b4 should be the same as aft2:"<<endl;
			for (i=0; i< member_index; i++) {
				cout << "i="<<i<<"  scan_num b4:"<<middle_column_ptb4[i].scan_num<<"  aft:"<<middle_column_pt[i].scan_num;
				cout << "  intensities b4:"<< middle_column_ptb4[i].intensiT <<    "  aft:"<< middle_column_pt[i].intensiT << "  aft2:"<< middle_column_pt[i].intensiT2 << endl;
				/* Perfectly checked .... nothing below print out
		if (middle_column_ptb4[i].scan_num != middle_column_pt[i].scan_num) {
		cout << "TTTTTT" << endl;
			} 
		if (middle_column_ptb4[i].scan_num != middle_column_pt[i].scan_num) {
			cout << "TTTTTT" << endl;
			}
		*/

			}
		}
	}
	
	if (Nocaseof_no_overlapping == 1) {
		//if (size_of_middle_column_pt ==0) {
		if (no_nonzeropeaks_aft_deconv ==0) {
			if (size_of_middle_column_ptb4 ==0) {
				cout << "There is no peak found in overlapping zone. (both after and b4 deconvolution)  member_index==0,  light peak 0verlapping zone"<<endl;
				return -1;  //This means if the search peak is compeletely out of "overlapping," we we treat it as zero. // return -1, will be treat as info "negligible" 
			}
			if (size_of_middle_column_ptb4 <=3) {//in overlapping zone, there are only three or fewer columns. and all of these were set to zero in deconv.
				condition = true;  //condition means negligible_condition 
				j=0;
				while ((condition == true) && (j < member_indexb4)) {
					threshold= 3 * noise_level(rawfilename, middle_column_ptb4[j].scan_num);
					cout << "j="<<j<<"threshold=" <<threshold<<"  real_inten=" <<  middle_column_ptb4[j].intensiT <<endl;
					if ( middle_column_ptb4[j].intensiT >= threshold) { condition = false; } else { middle_column_ptb4[j].intensiT=0.000000;}
					j++;
				}
				if (condition) {
					cout << "Although "<< member_indexb4 <<"-column peak is mixed but smaller than background noise. negligible." << endl;
					member_indexb4 = 0;
					return -1; // This means if the search peak is compeletely out of "overlapping," we we treat it as zero.
				} else {
					if ((given_heavy_n_search_light==0) && (member_indexb4 == 1)) {
						member_indexb4 = 0;
						return 0.0000; //with artificial chemical reaction to add heavy isotope we are confident in saying: if MS shows no heavy
						// peak found, it will be true that all of this site was originally light isotope acetylated already b4 chemical reaction.
					} else {
						cout << "The "<< member_indexb4 <<"-column peak is mixed and one of the column is larger than background noise.";
						cout << "dump" << endl;
						return -6.0000; //
					}
				}
			} else { // if (member_indexb4 > 3)
				cout << "In overlapping zone, there is no aft-dev peak found but more than 3 b4-dev peak columns found, dump!"<< endl;
				cout << "mixed part is big. We directly kick it out without checking/comparing with background noise level." << endl;
				return -6.0000; //
			}
		}//if (no_nonzeropeaks_aft_deconv ==0) {
	}//if (Nocaseof_no_overlapping == 1)

	// THE FOLLOWING IS THE COMMENTS IN PPintegratorA(){} (for calibrating peak)
	// We list it here, in PPintegratorB(){}, just for reference.
	// OK before we reversion to this version which has the allowance in "comparing b4-after deconvolution"
	// we had   1. index_best
	//          2. pre_low_cut, pre_upper_cut (check continuity)
	//          2-1. copy whole_column_pt to  possible_column_pt
	//          3. smoothing
	//          4. finding apexes
	//          5. finding upper_cut and lower_cut
	// on both b4-array and after-array.
	//
	// In this version, we would like to skip these procedure on b4-array.
	// Just finished the 4 steps mentioned here on after-array and then compare after-array(not smoothed) with b4-array.
	// The guideline of the comparison:
	//    0. initialize counter=0; Differ_lmt=0;
	//    1. scope from lowerbound to upper bound
	//    2. check if scannum are the same
	//    3. check if intensity is zero
	//       3a if yes, (1) counter++;  (2) Differ_limt += the intensity in b4array (3)
	//    4. at the end of each loop, check if ( counter > floor(threshold_ratio * (upper bound - lower bound +1)) )
	//    5. at the end check if the ratio Differ_lmt/sum < 0.1
	//                  Upper_limit = sum + Differ_lmt


	//$$$$$$$$$$$$$$$$$$$$$$$$$	
	if ( member_index < 4) {
		float sum_qq_mz=0.000;
		for (k=0; k<qq.size(); k++) {
			sum_qq_mz += qq[k].mz; 
		}
		if (given_heavy_n_search_light == 1) {
			premz = sum_qq_mz/qq.size() - delta_3DH/charge;
		} else {
			premz = sum_qq_mz/qq.size() + delta_3DH/charge;
		} 
	} else {
		premz = average_of_light_mz_overlapping_zone(middle_column_pt,size_of_middle_column_pt);
	}
	cout << "premz =" << premz << endl;
	lowerRB= premz*(1.0000000 - mz_error_10); //In extension zones, we use larger mz allowance, 8ppm.
	upperRB= premz*(1.0000000 + mz_error_10);
	lowerRB_b4deconvo = lowerRB - 3.0000;
	upperRB_b4deconvo = upperRB + 1.0000;

	ms1_scan_index=0;
	priorm_indexb4=0;
	priorm_index=0;
	posteri_indexb4=0;
	posteri_index=0;
	flag01 = true;

	for (i=lowerScan;i<upperScan;i++){
		readHeader(rawf, allscansoffset[i], &(thescans->scanheader));
		if(thescans->scanheader.msLevel==1){
			ms1_scan_index++;
			pscan = i;
			thescans->rpeaks = readPeaks(rawf, allscansoffset[i]);
			readHeader(rawf, allscansoffset[pscan],&precHeader);

			if (i < qq[0].scannum) {
				insert = 1;
			} else if (i <= qq[qq.size()-1].scannum) {
				insert = 0;
			} else {
				insert = 2;
			}

			if (insert==0) {
				for ( j=0; j<size_of_middle_column_pt; j++) {
					if (middle_column_pt[j].scan_num == i) {
						middle_column_pt[j].scan_index = ms1_scan_index;
						//middle_column_ptb4[j].scan_index = ms1_scan_index;
						break;
					}
				}
			}

			if ((insert==1)||(insert==2)) {

				if ((ref_column_width<0.001) && (flag01 == true) && (priorm_index !=0)) {        //get ref_column_width for single column case.
					ref_column_width = precHeader.retentionTime - TT321;
					flag01 = false;
					cout << "in PPintegratorB prior_zone ref_column_width= " << ref_column_width << endl;
				}
				ppeakcount = precHeader.peaksCount;
				TT321 = precHeader.retentionTime;  //sssizz = 2*ppeakcount;
				size1 = int (ppeakcount/2);
				delta = int (size1/2);
				while (delta >= 2){
					if (thescans->rpeaks[2*size1] < lowerRB_b4deconvo){
						size1 += delta;
					} else {
						size1 -= delta;
					}
					delta = int (delta/2);
				}
				if ( thescans->rpeaks[2*size1] > lowerRB_b4deconvo){
					size1 -= (delta*4);
				}

				size2 = int(ppeakcount/2);
				delta2 = int (size2/2);
				while (delta2 >= 2){
					if (thescans->rpeaks[2*size2] < upperRB_b4deconvo){
						size2 += delta2;
					} else {
						size2 -= delta2;
					}
					delta2 = int (delta2/2);
				}
				if ( thescans->rpeaks[2*size2] < upperRB_b4deconvo){
					size2 += (delta2*4);
				}
				size1a = size1*2;
				size2a = size2*2;
				size_of_bArray = 3*(size2 - size1 +1);
			}//if ((insert==1)||(insert==2))
			
			if (insert==1) {
				counter=0;
				for(j=size1a;j<size2a;j++){
					if (j % 2==0){
						if (thescans->rpeaks[j] <= upperRB){
							if (thescans->rpeaks[j] >= lowerRB){
								if (counter==0) {
									temp_elem.mz = thescans->rpeaks[j];
									temp_elem.intensiT = thescans->rpeaks[j+1];
								} else {
									if (thescans->rpeaks[j+1]>temp_elem.intensiT) { //take the largest intensity
										temp_elem.mz =  thescans->rpeaks[j];
										temp_elem.intensiT = thescans->rpeaks[j+1];
									}
								}
								counter++;
							}
						} else {
							if (counter>0){
								prior_column_ptb4[priorm_indexb4].scan_index = ms1_scan_index;
								prior_column_ptb4[priorm_indexb4].scan_num= i;
								prior_column_ptb4[priorm_indexb4].R_time = TT321;
								prior_column_ptb4[priorm_indexb4].mz1 = temp_elem.mz;
								prior_column_ptb4[priorm_indexb4].intensiT = temp_elem.intensiT;
								Lulumi = prior_column_ptb4[priorm_indexb4].intensiT;
								priorm_indexb4++;
							}
							break;
						}
					}//if (j % 2==0){
				}//for(j=size1a;j<size2a;j++){
				
				deconvolute( thescans->rpeaks, size1,  size2, bArray, group, 0);
				size_of_bArray = 3*(size2 - size1 +1);
				counter=0;
				for(j=0;j<size_of_bArray;j++){
					if (j % 3==0){
						if (bArray[j] <= upperRB){
							if (bArray[j] >= lowerRB){
								if (counter==0) {
									temp_elem.mz = bArray[j];
									temp_elem.intensiT = bArray[j+1];
								} else {
									if (bArray[j+1]>temp_elem.intensiT) {  //take the largest intensity
										temp_elem.mz = bArray[j];
										temp_elem.intensiT = bArray[j+1];
									}
								}
								counter++;
							}
						} else {
							if (counter>0){
								prior_column_pt[priorm_index].scan_index = ms1_scan_index;
								prior_column_pt[priorm_index].scan_num= i;
								prior_column_pt[priorm_index].R_time = TT321;
								prior_column_pt[priorm_index].mz1 = temp_elem.mz;
								prior_column_pt[priorm_index].intensiT = temp_elem.intensiT;
								prior_column_pt[priorm_index].intensiT2=Lulumi;
								priorm_index++;
							}
							break;
						}
					}//if (j % 3==0){
				}//for(j=0;j<size_of_bArray;j++){
			}
			//If this scan corressponds to poterior arrays. 
			if (insert==2) {
				counter=0;
				for(j=size1a;j<size2a;j++){
					if (j % 2==0){
						if (thescans->rpeaks[j] <= upperRB){
							if (thescans->rpeaks[j] >= lowerRB){
								if (counter==0) {
									temp_elem.mz = thescans->rpeaks[j];
									temp_elem.intensiT = thescans->rpeaks[j+1];
								} else {
									if (thescans->rpeaks[j+1]>temp_elem.intensiT) { //take the largest intensity
										temp_elem.mz =  thescans->rpeaks[j];
										temp_elem.intensiT = thescans->rpeaks[j+1];
									}
								}
								counter++;
							}
						} else {
							if (counter>0){
								///*
								posterior_column_ptb4[posteri_indexb4].scan_index = ms1_scan_index;
								posterior_column_ptb4[posteri_indexb4].scan_num= i;
								posterior_column_ptb4[posteri_indexb4].R_time = TT321;
								posterior_column_ptb4[posteri_indexb4].mz1 = temp_elem.mz;
								posterior_column_ptb4[posteri_indexb4].intensiT = temp_elem.intensiT;
								//*/
								Lulumi = temp_elem.intensiT;
								posteri_indexb4++;
							}
							break;
						}
					}//if (j % 2==0){
				}//for(j=size1a;j<size2a;j++){
				deconvolute( thescans->rpeaks, size1,  size2, bArray, group, 0);
				counter=0;
				for(j=0;j<size_of_bArray;j++){
					if (j % 3==0){
						if (bArray[j] <= upperRB){
							if (bArray[j] >= lowerRB){
								if (counter==0) {
									temp_elem.mz = bArray[j];
									temp_elem.intensiT = bArray[j+1];
								} else {
									if (bArray[j+1]>temp_elem.intensiT) {  //take the largest intensity
										temp_elem.mz = bArray[j];
										temp_elem.intensiT = bArray[j+1];
									}
								}
								counter++;
							}
						} else {
							if (counter>0){
								posterior_column_pt[posteri_index].scan_index = ms1_scan_index;
								posterior_column_pt[posteri_index].scan_num= i;
								posterior_column_pt[posteri_index].R_time = TT321;
								posterior_column_pt[posteri_index].mz1 = temp_elem.mz;
								posterior_column_pt[posteri_index].intensiT = temp_elem.intensiT;
								posterior_column_pt[posteri_index].intensiT2= Lulumi;
								posteri_index++;
							}
							break;
						}
					}//if (j % 3==0){
				}//for(j=0;j<size_of_bArray;j++)
			}//if (insert==2)
		}//if(thescans->scanheader.msLevel==1)
	}// for (i=lowerScan;i<upperScan;i++)

	// Do we need to compare b4/after deconv here? Or just catonate it...
	// Then find the apexes of both b4/after array. Then find the lower and upper bounds. Then compare.
	
	//$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
	// 1. CONCATENATE ARRAY AND PRINT OUT TO EXAM.

	size_of_prior_column_ptb4 = priorm_indexb4;
	size_of_prior_column_pt = priorm_index;

	size_of_posterior_column_ptb4 = posteri_indexb4;
	size_of_posterior_column_pt = posteri_index;

	size_of_middle_column_ptb4 = member_indexb4;
	size_of_middle_column_pt = member_index;
	cout << "combine combine" << endl;
	cout << "size_of_prior_column_pt    = " << size_of_prior_column_pt << endl;
	cout << "size_of_middle_column_pt = " << size_of_middle_column_pt << endl;
	cout << "size_of_posterior_column_pt= " << size_of_posterior_column_pt << endl;
	//	cout << "combine combine ################################ "  << endl;
	cout << "size_of_prior_column_ptb4    = " << size_of_prior_column_ptb4 << endl;
	cout << "size_of_middle_column_ptb4 = " << size_of_middle_column_ptb4 << endl;
	cout << "size_of_posterior_column_ptb4= " << size_of_posterior_column_ptb4 << endl<< endl;

	column0 * whole_column_pt = new column0[(size_of_prior_column_pt+size_of_middle_column_pt+size_of_posterior_column_pt)];
	copy(prior_column_pt, prior_column_pt + size_of_prior_column_pt, whole_column_pt);
	copy(middle_column_pt, middle_column_pt + size_of_middle_column_pt, whole_column_pt+size_of_prior_column_pt);
	copy(posterior_column_pt, posterior_column_pt + size_of_posterior_column_pt, whole_column_pt+size_of_prior_column_pt+size_of_middle_column_pt);
	int size_of_whole_column_pt = size_of_prior_column_pt + size_of_middle_column_pt + size_of_posterior_column_pt;

	column0 * whole_column_ptb4 = new column0[(size_of_prior_column_ptb4+size_of_middle_column_ptb4+size_of_posterior_column_ptb4)];
	copy(prior_column_ptb4, prior_column_ptb4 + size_of_prior_column_ptb4, whole_column_ptb4);
	copy(middle_column_ptb4, middle_column_ptb4 + size_of_middle_column_ptb4, whole_column_ptb4+size_of_prior_column_ptb4);
	copy(posterior_column_ptb4, posterior_column_ptb4 + size_of_posterior_column_ptb4, whole_column_ptb4+size_of_prior_column_ptb4+size_of_middle_column_ptb4);
	int size_of_whole_column_ptb4 = size_of_prior_column_ptb4 + size_of_middle_column_ptb4 + size_of_posterior_column_ptb4;

	cout << endl<<"####### BEGINNING OF THE ANALYSIS OF \"after deconvulution\" #######"<<endl;
	cout << "LET'S PRINT OUT THINGS AFTER DECONVOLUTION: ";
	cout << "size_of_whole_column_pt= " << size_of_whole_column_pt <<endl;
	cout << "i scan_index  scan_num\t   R_time\t intensiT\n";
	for (i=0; i<size_of_whole_column_pt; i++) {
		if (i==size_of_prior_column_pt) {
			cout << "overlapping_zone_starts" << endl;
		}
		if (i==(size_of_prior_column_pt+size_of_middle_column_pt)) {
			cout << "overlapping_zone_ends" << endl;
		}
		cout << "SSSB "<<i<<"\t"<< whole_column_pt[i].scan_index <<"\t"<<whole_column_pt[i].scan_num<<"\t";
		cout << whole_column_pt[i].R_time<<"\t"<<whole_column_pt[i].R_time/60<<"\t";
		cout << std::setprecision(6) << whole_column_pt[i].mz1<<"\t";
		cout << whole_column_pt[i].intensiT <<endl;//"\t"<< whole_column_pt[i].intensmooth<<endl;
	}
	cout << endl;
	
	if (size_of_middle_column_pt == 1 ) { //This "if" can be placed right before copying array to save computation. we place it here for purpose of debugging. 
		/*cout << whole_column_pt[size_of_prior_column_pt-1].scan_index << "\t1 . whole_column_pt[size_of_prior_column_pt-1].scan_index" << endl; 
	cout << whole_column_pt[size_of_prior_column_pt].scan_index<< "\t2A. whole_column_pt[size_of_prior_column_pt].scan_index" << endl;
	cout << middle_column_pt[0].scan_index<< "\t2B. middle_column_pt[0].scan_index" << endl;
		cout << posterior_column_pt[0].scan_index                     << "\t3A. posterior_column_pt[0].scan_index" << endl;
		cout << whole_column_pt[size_of_prior_column_pt+1].scan_index << "\t3B. whole_column_pt[size_of_prior_column_pt+1].scan_index"<<endl;
	*/
		if (((posterior_column_pt[0].scan_index - middle_column_pt[0].scan_index) > 2) && ((middle_column_pt[0].scan_index - prior_column_pt[size_of_prior_column_pt-1].scan_index) > 2) ) {
			if ((ref_column_width > 0.05) && (ref_column_width < 2.0)) {
				return middle_column_pt[0].intensiT*ref_column_width;
			} else {
				return middle_column_pt[0].intensiT; //assume width is 1 sec. time interval between two nearest ms1 scans.
			}
		}
	}

	if (size_of_middle_column_pt == 2 ) {
		if ((middle_column_pt[0].intensiT == 0) && ((posterior_column_pt[0].scan_index - middle_column_pt[1].scan_index) > 2)) {
			if ((ref_column_width > 0.05) && (ref_column_width < 2.0)) {
				return middle_column_pt[1].intensiT*ref_column_width;
			} else {
				return middle_column_pt[1].intensiT; //assume width is 1 sec. time interval between two nearest ms1 scans.
			}
		}
		if ((middle_column_pt[1].intensiT == 0) && ((middle_column_pt[0].scan_index - prior_column_pt[size_of_prior_column_pt-1].scan_index) > 2)) {
			if ((ref_column_width > 0.05) && (ref_column_width < 2.0)) {
				return middle_column_pt[0].intensiT*ref_column_width;
			} else {
				return middle_column_pt[0].intensiT; //assume width is 1 sec. time interval between two nearest ms1 scans.
			}
		}
	} 


	if ( (size_of_whole_column_pt==0) ||((size_of_whole_column_pt==1)&&(whole_column_pt[0].intensiT<100)) ){
		cout << "no columns found in the allowed mz range found in the interval (bestscan-900,bestscan+1000)" << endl;
		cout << "IMPOSSIBLE ZONE2!" <<endl;
		if (given_heavy_n_search_light==1) {
			return -1.00;
		} else {
			return 0.0000;
		}
		//*max_scan_num = 0;
		//return -1.000;
	}

	//  1. Get index_best by finding the max in the region (peak_R_time_lower_bound, peak_R_time_upper_bound)
	//     But should not be the apex fall close to the edge.
	//     The section ends LN 846
	double max_intens_broad=0.0000;
	double max_intens=0.0000;
	//rtime_apex_of_calibrating_peak = (peak_R_time_upper_bound + peak_R_time_lower_bound )/2;

	bool flag_broadest00=0;
	bool flag000=0;
	bool flag002=0;
	int index_very_start=0, index_last=0, index_t0=0, index_t2=0;
	int index_best_broad=0, index_best_broad2=0, index_best3=0, index_best_in=0, index_best_in2=0;   
	bool kill_wr_P01 = 0, kill_wr_P02 = 0, kill_wr_P03 = 0, kill_wr_P04 = 0;
	int unwanted_upper_cut=0, unwanted_lower_cut=0, upper_in=0, lower_in=0;


	flag002=0;
	cout << "t2=" <<t2<<endl;
	cout << "peak_R_time_lower_bound=" <<peak_R_time_lower_bound<<endl;
	cout << "peak_R_time_upper_bound=" <<peak_R_time_upper_bound<<endl;
	cout << "R_time_lower_bound=" <<R_time_lower_bound<<endl;
	cout << "R_time_upper_bound=" <<R_time_upper_bound<<endl;

	for (i=0; i< size_of_whole_column_pt; i++){
		//max in the whole zone
		if (whole_column_pt[i].R_time > R_time_lower_bound){
			if (flag_broadest00==0) {
				flag_broadest00=1;
				index_very_start=i;
			}
			if (whole_column_pt[i].R_time < R_time_upper_bound){
				if (whole_column_pt[i].intensiT > max_intens_broad){
					max_intens_broad=whole_column_pt[i].intensiT;
					index_best_broad=i;
				}
				if ((whole_column_pt[i].R_time >= t0) && (flag000==0)) {
					flag000 =1;
					index_t0=i;
				}
				if ((whole_column_pt[i].R_time > t2) && (flag002==0)) {
					flag002 =1;
					index_t2=i-1;
				}
				//So, overlapping zone is i=index_t0; i<=index_t2;i++
				//Assign a scope here? like t0-5, t2+5 ?
			} else {
				index_last = i-1;
				if (flag002==0) {
					index_t2=i-1;
				}
				break;
			}
		}
	}

	cout << "ckpt 000-0,         index_t0="<< index_t0<<       "     index_t2=" <<index_t2  <<endl;
	cout << "ckpt 000-0, index_very_start="<<index_very_start<<"   index_last="<< index_last<<endl;
	cout << "ckpt 000-0, index_best_broad="<<index_best_broad<<endl;
	for (i=index_t0; i<=index_t2; i++){
		if (whole_column_pt[i].intensiT > max_intens){
			max_intens=whole_column_pt[i].intensiT;
			index_best=i;
		}
	}
	cout << "ckpt 000, index_best="<< index_best<< "    max_intens=" <<max_intens <<endl;
	// index_very_start mapping to first one > peak_R_time_lower_bound
	// index_last       mapping to last one  < peak_R_time_upper_bound
	// index_t0         mapping to first one >= t0
	// index_t2         mapping to last one  <= t2
	// index_best_broad is the max between peak_R_time_lower_bound peak_R_time_upper_bound

	if (max_intens_broad < 100) {  //or max_intens < 100 ?
		cout << "aft no columns in the allowed time apex range found." << endl;
		cout << "IMPOSSIBLE ZONE4!" <<endl;
		if (given_heavy_n_search_light==1) {
			return -1.00;
		} else {
			return 0.0000;
		}
		//*max_scan_num = 0;
		//return -1.000;
	}
	/*
	skip_prior=0;
	skip_posterior=0;
	if (index_very_start == index_t0) {skip_prior=1;//no peaks in prior zone
	}
	if (index_t2 == index_last) {skip_posterior=1;//no peaks in posterior zone
	}
	*/

	if ((index_best_broad >= index_t0) && (index_best_broad <= index_t2)) {
		// this "if" condition is more general than condition ((skip_prior==1) && (skip_posterior==1))
		// normal case... determining which peak has finished.
		index_best3=index_best_broad;
	} else {

		// 1. Exclude out  |\            the obtained apex is at the edge of peak_R_time_upper_bound or peak_R_time_lower_bound
		//                 | \        /|
		//                 |  \      / | 
		if  (whole_column_pt[index_best_broad].R_time < (peak_R_time_lower_bound+2)){
			// just kill this incomplete downhill peak |\
			//                                         | \
			// check continuity => find the upper_cut of this unwanted peak => set these to zero
			cout << "XXXXXXXXXXXXXXXXA" << endl;
			unwanted_upper_cut=upper_0_search(whole_column_pt, size_of_whole_column_pt, index_best_broad);
			cout << "index_best_broad =" << index_best_broad << "   unwanted_upper_cut=" << unwanted_upper_cut<< endl;
			// add slope judgement here? to prevent killing part of wanted?
			for (i=index_very_start; i<=unwanted_upper_cut; i++){
				whole_column_pt[i].intensiT = 0.0000000;
			}
			kill_wr_P01 = 1;
			// choice 1: Using upper_0_search (the above... consider 0.000 and discontiniuty)
			// if there is discontinuity in the unwanted peak, we may not be able to set-zero-value/kill at
			// the remainder of the unwanted peak which stretches into the region of interest.
			// choice 2: Use the code below (consider 0.000 and violating monologue decrease and "ignore discontinuity"
			// ...big trouble.... wrong judgement.... judge two peaks as one peak. opposite to choice one.)
			/*
		for (i=index_best_broad;i<=(index_t2 +2); i++){
		if (whole_column_pt[i].intensiT > whole_column_pt[i+1].intensiT) {
			whole_column_pt[i].intensiT = 0.0000000;
		} else {
		break;
		}
		if (whole_column_pt[i+1].intensiT==0) {
			whole_column_pt[i].intensiT = 0.0000000;
			break;
		}
		}
		*/
		}

		if (whole_column_pt[index_best_broad].R_time > (peak_R_time_upper_bound -2)) {
			//just kill this incomplete uphill peak   /|
			//                                       / | 
			// check continuity => find the lower_cut of this unwanted peak => set these to zero
			cout << "YYYYYYYYYYYYYYYYYA" << endl;
			unwanted_lower_cut=low_0_search(whole_column_pt, size_of_whole_column_pt, index_best_broad);
			cout << "index_best_broad =" << index_best_broad << "   unwanted_lower_cut=" << unwanted_lower_cut<< endl;
			// add slope judgement here? to prevent killing part of wanted?
			for (i=index_last; i>=unwanted_lower_cut; i--){
				whole_column_pt[i].intensiT = 0.0000000;
			}
			kill_wr_P02 = 1;
			/*
		for (i=index_best_broad;i<=(index_t0 -2); i--){
		if (whole_column_pt[i].intensiT > whole_column_pt[i-1].intensiT) {
		whole_column_pt[i].intensiT = 0.0000000;
		} else {
		break;
		}
		if (whole_column_pt[i-1].intensiT==0) {
		whole_column_pt[i].intensiT = 0.0000000;
		break;
		}
		}
		*/
		}
		// After setting the intensity of "incomplete peak on the edge -15, +15" to zero,
		// we search the apex again. It turns to quasi-nest structure but only two layer recursive 
		if ((kill_wr_P01 == 1) || (kill_wr_P02 == 1)){
			max_intens=0.0000;
			for (i=index_very_start; i<=index_last; i++){
				if (whole_column_pt[i].intensiT > max_intens){
					max_intens=whole_column_pt[i].intensiT;
					index_best_broad2=i;
				}
			}
			
			if (max_intens < 0.01) {
				cout << "aft no columns in the allowed time apex range found after killing an unwanted peak." << endl;
				if (given_heavy_n_search_light==1) {
					return -1.00;
				} else {
					return 0.0000;
				}
			}
			// We still need to check in the new search, if highest happened on the side opposite to the side we
			// kill peak, b4 the new search. 
			
			if  (whole_column_pt[index_best_broad2].R_time < (peak_R_time_lower_bound+2)){
				// just kill this incomplete downhill peak |	\
				//                                         |		\
				// check continuity => find the upper_cut of this unwanted peak => set these to zero
				cout << "XXXXXXXXXXXXXXXXB" << endl;
				unwanted_upper_cut=upper_0_search(whole_column_pt, size_of_whole_column_pt, index_best_broad2);
				cout << "index_best_broad2 =" << index_best_broad2 << "   unwanted_upper_cut=" << unwanted_upper_cut<< endl;
				// add slope judgement here? to prevent killing part of wanted?
				for (i=index_very_start; i<=unwanted_upper_cut; i++){
					whole_column_pt[i].intensiT = 0.0000000;
				}
				kill_wr_P03 = 1;
			}

			if (whole_column_pt[index_best_broad2].R_time > (peak_R_time_upper_bound -2)) {
				//just kill this incomplete uphill peak   /|
				//                                       / |
				// check continuity => find the lower_cut of this unwanted peak => set these to zero
				cout << "YYYYYYYYYYYYYYYYYB" << endl;
				unwanted_lower_cut=low_0_search(whole_column_pt, size_of_whole_column_pt, index_best_broad2);
				cout << "index_best_broad2 =" << index_best_broad2 << "   unwanted_lower_cut=" << unwanted_lower_cut<< endl;
				// add slope judgement here? to prevent killing part of wanted?
				for (i=index_last; i>=unwanted_lower_cut; i--){
					whole_column_pt[i].intensiT = 0.0000000;
				}
				kill_wr_P04 = 1;
			}

			// After setting the intensity of "incomplete peak on the edge -15, +15" to zero,
			// we search the apex again. It turns to quasi-nest structure but only two layer recursive
			if ((kill_wr_P03 == 1) || (kill_wr_P04 == 1)){
				max_intens=0.0000;
				for (i=index_very_start; i<=index_last; i++){
					if (whole_column_pt[i].intensiT > max_intens){
						max_intens=whole_column_pt[i].intensiT;
						index_best3=i;
					}
				}
			} else {
				index_best3 = index_best_broad2;
			}
		} else { //if ((kill_wr_P01 == 1) || (kill_wr_P02 == 1)){
			index_best3 = index_best_broad;
		}
	} // if ((index_best_broad >= index_t0) && (index_best_broad <= index_t2)) {index_best3 = index_best_broad;} else{
	// END OF the PART1 of finding index_best: Exclude out apex at the edge of peak_R_time_upper_bound or peak_R_time_lower_bound

	// PART 2. if highest apex A is not in the overalpping zone, we check if there is another apex/peak B in the overlapping zone.
	//       if yes and peak B is resonable large (not too small), we may let peak B speak.
	//       if yes and apex A is not within 5 seconds from the boundary of overlapping zone, we may let peak B speak

	// index_very_start mapping to first one > peak_R_time_lower_bound
	// index_last       mapping to last one  < peak_R_time_upper_bound
	// index_t0         mapping to first one >= t0
	// index_t2         mapping to last one  <= t2
	// index_best is the max between peak_R_time_lower_bound peak_R_time_upper_bound after delete ncomplete peak on the edge
	
	//for 2  if highest apex A is not in the overalpping zone, we check if there is another apex/peak B in the overlapping zone.
	//       if yes and peak B is resonable large (not too small), we may let peak B speak.
	//       if yes and apex A is not within 5 seconds from the boundary of overlapping zone, we may let peak B speak.

	if ((index_best3 < index_t0) || (index_best3 > index_t2)) {
		double max_intens_in = 0.0000;
		for (i=index_t0; i<=index_t2; i++){
			if (whole_column_pt[i].intensiT > max_intens_in){
				max_intens_in=whole_column_pt[i].intensiT;
				index_best_in=i;
			}
		}

		if (max_intens_in > 1000) { 
			if (index_best3 < index_t0) {
				if (index_best_in == index_t0){ //perfect, do nothing
					index_best = index_best3;
				} else if (index_best_in == index_t2) {
					// another smaller peak on the other side stretch to overlapping zone now
					// module AA1
					// no need to do 1.  check if this peak has the same incomplete uphill edge peak problem.... set it to zero.
					// 2.  smooth the area (index_very_start, index_last)
					// 3.  find apex (starting from index_t2 toward upper.)  
					// 4.  compare position of apex to see which is closer. 
					//     (To simplify process, here we do NOT compare: 
					//                             1. the height of two peaks, 
					//                             2. the area of two peaks,
					//                             3. the area in overlapping zone of two peaks.)
					
					double max_intens_in2 = 0.0000;
					for (i=index_t2; i<=index_last; i++){
						if (whole_column_pt[i].intensiT > max_intens_in2){
							max_intens_in2=whole_column_pt[i].intensiT;
							index_best_in2=i;
						}
					}

					if ((whole_column_pt[index_best_in2].R_time - whole_column_pt[index_t2].R_time) > (whole_column_pt[index_t0].R_time - whole_column_pt[index_best3].R_time)){
						index_best = index_best3; //index_best3's apex is closer and higher, though "maybe" less area in overalpping zone.
						cout << "ckpt 001" << endl;
					} else {
						if ((whole_column_pt[index_best_in2].R_time - whole_column_pt[index_t2].R_time + 5) < (whole_column_pt[index_t0].R_time - whole_column_pt[index_best3].R_time)){
							index_best = index_best_in2; // index_best_in2's apex is closer by at least 5 sec than index_best3's bigger apex.
							cout << "ckpt 002" << endl;
						} else {
							index_best = index_best3; 
							cout << "ckpt 003" << endl;
						}
					}

				} else {
					// There is an isolated peak in overlapping zone. check if it is small.
					// module AB
					//    1. smooth the area (index_very_start, index_last) 
					//    2. find upper_cut of index_best to see if  index_best < index_best_in < upper_cut 
					//       (if they belong to the same peak)
					//    3. if no, 
					//        3a check if the width of this peak (index_best_in) is >=2 column. 
					//        3b check the position of apex (index_t0.time-index_best.time) > 5
					//        3c check the position of apex (index_t0.time-index_best.time) > 10
					//           3a Yes, 3b Yes => take index_best_in
					//           3a No,  3b No  => take index_best                                           
					//           3a No,  3b Yes, 3c No => take index_best
					//           3a No,  3b Yes, 3c Yes=> take index_best_in
					upper_in=upper_0_search(whole_column_pt, size_of_whole_column_pt, index_best_in);
					lower_in=low_0_search(whole_column_pt, size_of_whole_column_pt, index_best_in);
					if ((upper_in > index_best_in) || (lower_in < index_best_in)) { // that means there are at least two columns in this peak.
						index_best = index_best_in;
						cout << "ckpt 004" << endl;
					} else {
						if ((whole_column_pt[index_t0].R_time - whole_column_pt[index_best3].R_time) <= 5) {
							index_best = index_best3;   // take the highest peak which is out of overlapping zone but within 5 sec away from the zone boundary. 
							cout << "ckpt 005" << endl;
						} else {
							index_best = index_best_in; // take this single column peak in overalpping zone
							cout << "ckpt 006" << endl;
						}
					}
				}
			} //if (index_best3 < index_t0)
			if (index_best3 > index_t2) {
				if (index_best_in == index_t2) { //perfect, do nothing
					index_best = index_best3;
					cout << "ckpt 007" << endl;
				} else if (index_best_in == index_t0) {
					// another smaller peak on the other side stretch to overlapping zone now
					// module AA2 
					// same as module AA1, except step3. find apex (starting from index_t0 toward lower.)
					cout << "ckpt 008 prime" << endl;
					double max_intens_in2 = 0.0000;
					for (i=index_very_start; i<=index_t0; i++){
						if (whole_column_pt[i].intensiT > max_intens_in2){
							max_intens_in2=whole_column_pt[i].intensiT;
							index_best_in2=i;
							cout << "ckpt 008" << endl;
						}
					}

					if ((whole_column_pt[index_t0].R_time - whole_column_pt[index_best_in2].R_time) > (whole_column_pt[index_best3].R_time - whole_column_pt[index_t2].R_time)){
						index_best = index_best3; //index_best3's apex is closer and higher, though "maybe" less area in overalpping zone.
					} else {
						if ((whole_column_pt[index_t0].R_time - whole_column_pt[index_best_in2].R_time + 5) < (whole_column_pt[index_best3].R_time - whole_column_pt[index_t2].R_time)){
							index_best = index_best_in2; // index_best_in2's apex is closer by at least 5 sec than index_best3's bigger apex.
							cout << "ckpt 009" << endl;
						} else {
							index_best = index_best3;
							cout << "ckpt 010" << endl;
						}
					}
				} else {
					// There is an isolated peak in overlapping zone. check if it is small.
					// module AB
					upper_in=upper_0_search(whole_column_pt, size_of_whole_column_pt, index_best_in);
					lower_in=low_0_search(whole_column_pt, size_of_whole_column_pt, index_best_in);
					if ((upper_in > index_best_in) || (lower_in < index_best_in)) { // that means there are at least two columns in this peak.
						index_best = index_best_in;
						cout << "ckpt 011" << endl;
					} else {
						if ((whole_column_pt[index_best3].R_time - whole_column_pt[index_t2].R_time) < 5) {
							index_best = index_best3;
							cout << "ckpt 012" << endl;
						} else {
							index_best = index_best_in;
							cout << "ckpt 013" << endl;
						}
					}
				}
			}//if (index_best3 > index_t2)
		} else { //if (max_intens_in > 1000) {
			index_best = index_best3;  //no peak found in overlapping zone.
			cout << "ckpt 014" << endl;
		}
	} //if ((index_best < index_t0) || (index_best > index_t2))
	// END OF the PART1 of finding index_best: check if there is another apex/peak B in the overlapping zone.

	cout << "index_best ="<< index_best <<"    intensiT="<< whole_column_pt[index_best].intensiT <<endl;
	*real_max_scan_num = whole_column_pt[index_best].scan_num;
	*real_max_inten = whole_column_pt[index_best].intensiT;
	*max_scan_num =   whole_column_pt[index_best].scan_num;


	//dump this?
	/*
		if (size_of_whole_column_pt==1) {
			if ((whole_column_pt[0].R_time < peak_R_time_upper_bound ) && (whole_column_pt[0].R_time > peak_R_time_lower_bound )) {
		cout << "a single column at time:" << whole_column_pt[0].R_time << endl;
		cout << "height of the single column is: "<<  whole_column_pt[0].intensiT << endl;
		*real_max_scan_num = whole_column_pt[0].scan_num;
		*real_max_inten = whole_column_pt[0].intensiT;
		*max_scan_num =      whole_column_pt[0].scan_num;
			return whole_column_pt[0].intensiT * ref_column_width;
			} else {
		cout <<"single column but not in the allowed apex time range found." <<endl;
		cout <<" peak_R_time_lower_bound="<<peak_R_time_lower_bound<<"   peak_R_time_upper_bound="<<peak_R_time_upper_bound<<endl;
		cout <<" a single column at time:" << whole_column_pt[0].R_time << endl;
		cout << "IMPOSSIBLE ZONE3!" <<endl;
			if (given_heavy_n_search_light==1) {
				return -1.00; //now we are looking light, but light not found. give stoichi_L=0.
			} else {
				return 0.0000; //now we are looking heavy, but heavy not found. give stoichi_L=1.
			}
			//*max_scan_num = 0;
			//return -1.000;
			}
		}

	*/


	
	
	//*max_scan_num = whole_column_pt[apex_start].scan_num;//???why? because if HH is given, LH is a mess, it may ruin LL search. So decided still
	//use HH insteda of LH result.
	//3. Finding lower_cut, upper_cut
	//############  The following is not appropriate. 1. the order of screening is different from "scannum-given"
	//############  case. it should be a.) judged by sign of derivative b.) judge going out by MS1scannum c.) height.
	//############  2. no going down judge before judge two continuous up in upper_2a_search(increase0, size_of_whole_column_pt,index_best)
	//############    similar problem for lower_2a_search(increase0, size_of_whole_column_pt,index_best)
	//############  3. Suggestion: improve upper_2a_search & lower..., then put whole "if (addinfo==0) {} " before
	//############    LN 840 "cout << "# apex (0 < apex <size_of_whole_column_pt) =" << apex << endl;""

	cout << "size_of_whole_column_pt= "<< size_of_whole_column_pt <<endl;
	cout << "index_best  b4 smooth =" << index_best << endl;
	cout << "index_best b4 smooth here is the apex judged by non-smoothed intensity. " << endl;
	cout << "Roughly index_best is the highest peak in time range: (peak_R_time_lower_bound+2, peak_R_time_upper_bound-2)" <<endl;
	cout << "However, 1. incomplete at edge peak should be excluded out" <<endl; 
	cout << "2. we do consider retention time difference, if there are more than one peak in the range and both apexes are out of"<<endl;
	cout << "overlapping zone: if the difference of the attribute|apextime - overlapping zone boundary| of two peaks" << endl;
	cout << "are larger than 5 sec... The chosen one is the one closer in time, otherwise choose higher peak." <<endl;
	cout << "3. if a single column peak in overalpping zone and other peak's apex is out of overlapping and |apextime - overlapping zone boundary| > 5" << endl;
	cout << "choose the single column peak in overalpping zone, otherwise, choose that bigger one." <<endl;
	cout << "3-2. if 2-(or more)-column peak in overalpping zone, choose it." << endl;

	pre_low_cut  =low_0_search(whole_column_pt, size_of_whole_column_pt, index_best);
	pre_upper_cut=upper_0_search(whole_column_pt, size_of_whole_column_pt, index_best);
	
	cout << "  pre_low_cut=" << pre_low_cut<< endl;
	cout << "   index_best=" << index_best<<endl; 
	cout << "pre_upper_cut=" << pre_upper_cut<< endl;

	//## ABOVE this point all possible_column_pt were changed to whole_column_pt
	//## Below we name our newly gnerated array as old name possible_column_pt
	//## That means no need to change the code below. (Surely, still small part about "b4-array.")
	int size_of_possible_column_pt=pre_upper_cut - pre_low_cut+1;
	column0 * possible_column_pt = new column0[size_of_possible_column_pt];
	copy(whole_column_pt+pre_low_cut, whole_column_pt+pre_upper_cut+1, possible_column_pt);
	index_best -= pre_low_cut;
	cout << "now index_best=" << index_best<<endl;
	cout << "possible_column_pt[index_best].scan_num" << possible_column_pt[index_best].scan_num << endl;

	//SMOOTHING
	if (size_of_possible_column_pt >= 4) {
		possible_column_pt[0].intensmooth = (c03*possible_column_pt[0].intensiT+c02*possible_column_pt[1].intensiT\
		+c01*possible_column_pt[2].intensiT)/(c01+c02+c03);
		possible_column_pt[size_of_possible_column_pt-1].intensmooth = (c03*possible_column_pt[size_of_possible_column_pt-1].intensiT\
		+c02*possible_column_pt[size_of_possible_column_pt-2].intensiT\
		+c01*possible_column_pt[size_of_possible_column_pt-3].intensiT)/(c01+c02+c03);
		possible_column_pt[1].intensmooth = (c02*possible_column_pt[0].intensiT+c03*possible_column_pt[1].intensiT\
		+c02*possible_column_pt[2].intensiT+c01*possible_column_pt[3].intensiT)/(c01+2*c02+c03);
		possible_column_pt[size_of_possible_column_pt-2].intensmooth = (c01*possible_column_pt[size_of_possible_column_pt-4].intensiT\
		+c02*possible_column_pt[size_of_possible_column_pt-3].intensiT\
		+c03*possible_column_pt[size_of_possible_column_pt-2].intensiT\
		+c02*possible_column_pt[size_of_possible_column_pt-1].intensiT)/(c01+2*c02+c03);
		if (size_of_possible_column_pt > 4){
			for (i=2; i<(size_of_possible_column_pt-2); i++) {
				possible_column_pt[i].intensmooth = c01*possible_column_pt[i-2].intensiT+c02*possible_column_pt[i-1].intensiT+c03*possible_column_pt[i].intensiT\
				+c02*possible_column_pt[i+1].intensiT+c01*possible_column_pt[i+2].intensiT;
			}
		}
	} else if (size_of_possible_column_pt == 3) {
		possible_column_pt[0].intensmooth = (c03*possible_column_pt[0].intensiT+c02*possible_column_pt[1].intensiT\
		+c01*possible_column_pt[2].intensiT)/(c01+c02+c03);
		possible_column_pt[1].intensmooth = (c02*possible_column_pt[0].intensiT+c03*possible_column_pt[1].intensiT\
		+c02*possible_column_pt[2].intensiT)/(2*c02+c03);
		possible_column_pt[2].intensmooth = (c03*possible_column_pt[2].intensiT+c02*possible_column_pt[1].intensiT\
		+c01*possible_column_pt[0].intensiT)/(c01+c02+c03);
	} else {
		for (i=0; i<size_of_possible_column_pt; i++) {
			possible_column_pt[i].intensmooth = possible_column_pt[i].intensiT;
		}
	}

	cout << "size_of_possible_column_pt= " << size_of_possible_column_pt <<endl;

	if (debug >=2) {
		cout << "i\tscan_index\tscan_num\tR_time(in sec)\t(in min)\tmz\tintensiT\n";
		//cout << "i scan_index  scan_num\t   R_time\t intensiT\n";
		for (i=0; i< size_of_possible_column_pt; i++) {
			cout << "NNNB "<<i<<"\t"<< possible_column_pt[i].scan_index <<"\t"<<possible_column_pt[i].scan_num<<"\t";
			cout << possible_column_pt[i].R_time<<"\t"<<possible_column_pt[i].R_time/60<<"\t";
			cout << std::setprecision(6) <<possible_column_pt[i].mz1<<"\t";
			cout << possible_column_pt[i].intensiT<<"\t"<< possible_column_pt[i].intensmooth<<endl;
		}
		cout << endl;
	}

	//search apex1 and upper bound  //Defined as 1. experience two continuous decrease, then whatever, then two continuous incrrease.
	//search apex2 and lower bound
	apexcandi_search(possible_column_pt, size_of_possible_column_pt, index_best, &apex1, &apex2, &upper_cut_pt, &lower_cut_pt);
	temp_max1 = possible_column_pt[apex1].intensmooth;
	temp_max2 = possible_column_pt[apex2].intensmooth;
	if (temp_max1 > temp_max2) {
		apex = apex1;
		maxx = temp_max1;
	} else {
		apex = apex2;
		maxx = temp_max2;
	}
	cout <<"aft apex1="<< apex1<<"  temp_max1="<< temp_max1 << endl;
	cout <<"    apex2="<< apex2<<"  temp_max2="<< temp_max2 << endl;
	cout <<"    upper_cut_pt="<< upper_cut_pt<<"  lower_cut_pt="<< lower_cut_pt << endl;

	cout << "# apex (0 < apex <size_of_possible_column_pt) =" << apex << endl;
	cout << "# The correspondent scan_num:    " << possible_column_pt[apex].scan_num << endl;
	cout << "# the correspondent R-time:      " << possible_column_pt[apex].R_time << endl;
	low_cut_candi[1]  = lower_cut_pt; //low_2_search(possible_column_pt, size_of_possible_column_pt, apex);
	upper_cut_candi[1]= upper_cut_pt; //upper_2_search(possible_column_pt, size_of_possible_column_pt, apex);
	low_cut_candi[0]  =  low_1_search(possible_column_pt, size_of_possible_column_pt, apex); //judge going out by MS1scannum
	low_cut_candi[2]  =  low_3_search(possible_column_pt, size_of_possible_column_pt, apex, possible_column_pt[apex].intensiT*0.05); //judge by height only
	upper_cut_candi[0]=upper_1_search(possible_column_pt, size_of_possible_column_pt, apex);
	upper_cut_candi[2]=upper_3_search(possible_column_pt, size_of_possible_column_pt, apex, possible_column_pt[apex].intensiT*0.05);
	for (ii=0; ii<3; ii++){
		if ((low_cut_candi[ii] > 10000)||(low_cut_candi[ii] < -10000)) {
			low_cut_candi[ii] = 0 ;
		}
	}
	cout << "low_cut_candi:  "<<low_cut_candi[0]<<"  "<<low_cut_candi[1]<<"  "<<low_cut_candi[2]<<endl;
	cout << "upper_cut_candi:"<<upper_cut_candi[0]<<"  "<<upper_cut_candi[1]<<"  "<<upper_cut_candi[2]<<endl;
	lower_cut = max_int_array(low_cut_candi,3);
	upper_cut = min_int_array(upper_cut_candi,3);
	if (lower_cut == 0) {
		cout << "You may have to make  ### here larger. lowerScan = bestScan - ###;" << endl;
	}
	if (upper_cut == size_of_possible_column_pt) {
		upper_cut--;
		cout << "You may have to make  ### here larger. lowerScan = bestScan + ###;" << endl;
	}
	cout<<"lower_cut= "<< lower_cut <<"   upper_cut= "<< upper_cut <<endl;
	cout<<"The correspondent retention time is from "<< possible_column_pt[lower_cut].R_time;
	cout<<" to " << possible_column_pt[upper_cut].R_time << endl;
	cout<<"The correspondent scan_num is from "<< possible_column_pt[lower_cut].scan_num;
	cout<<" to " << possible_column_pt[upper_cut].scan_num << endl;



	cout << "#################################ABCDEFG" <<endl;
	//B4B4B4B4B4B4B4B4B4B4B4B4B4B4B4B4{
	// About *starting_time, *end_time, we reset it to new value only when value "real_area" is returned.

	dump_trig = true;

	double sum01 = 0.00000;  //This sum is used to roughly estimate the area under the curve. However
	int counterR = 0;     // the real sum is variable real_area in which time width is considered.
	double Differ_lmt =0.0000;
	double threshold_ratio_for_column_number = 0.200;
	double threshold_ratio_for_area = 0.150;
	int threshold01 = floor(threshold_ratio_for_column_number * (upper_cut -lower_cut +1));
	int lower_cut_whole_b4,q;
	double mismatch_frac=0, Upper_limit;
	int endpoint, temppp;

	for (i=0; i< size_of_whole_column_ptb4; i++) {
		if (whole_column_ptb4[i].scan_num == possible_column_pt[lower_cut].scan_num) {
			lower_cut_whole_b4 = i;
			break;
		}
	}
	for (i=lower_cut; i<=upper_cut; i++) {
		sum01 += possible_column_pt[i].intensiT;
		if (possible_column_pt[i].intensiT ==0) {
			counterR++;
			temppp = upper_cut - lower_cut + 3 + lower_cut_whole_b4;
			endpoint = min_of_two_int(temppp, size_of_whole_column_ptb4);
			for (j=lower_cut_whole_b4; j< endpoint; j++) {
				if (whole_column_ptb4[j].scan_num == possible_column_pt[i].scan_num) {
					q = j; break;
				}
			}
			//q = lower_cut_whole_b4 - lower_cut + i;
			Differ_lmt += whole_column_ptb4[q].intensiT;
			possible_column_pt[i].intensiT2 = whole_column_ptb4[q].intensiT;
			// We will use this assigned value intensiT2 in function summatioNproduct()
			// Then the function gives both lower limit (function value) and upper limit(passed by address)
			// summatioNproduct() consider time of each bin, but mismatch_frac is still a good rough estimate.
		}
		if (counterR >  threshold01) { //That means if missing 2 columns in 10 cloulmn 2 <= 0.2*10 , it will not return -8.
			cout << "The number of mismatches between b4 and after deconvolution array is over the threshold.";
			return -8.0000;
		}
	}
	if (sum01 >0) {
		mismatch_frac = Differ_lmt/sum01;
	} else {
		cout << "trouble!" << endl;
	}

	Upper_limit = sum01 + Differ_lmt;

	if (mismatch_frac > threshold_ratio_for_area) {
		cout << "The integration of mismatch between b4 and after deconvolution array is over the threshold.";
		return -8.0000;
	}


	cout << "#################################" <<endl;


	cout << "lower_cut=" << lower_cut <<"    upper_cut= " << upper_cut << endl;
	if (lower_cut > upper_cut) {
		cout << "  lower_cut > upper_cut" <<endl;
		return -1.000;
	} else if (lower_cut < upper_cut) {
		cout << "possible_column_pt[lower_cut].R_time=" << possible_column_pt[lower_cut].R_time <<endl;
		cout << "possible_column_pt[upper_cut].R_time=" << possible_column_pt[upper_cut].R_time <<endl;
		real_area = summatioNproduct(possible_column_pt, lower_cut, upper_cut, &upper_limit_real_area);
		cout << "real area_P = "<< real_area <<endl;
		cout << "upper_limit_real_area = "<< upper_limit_real_area <<endl;

		*max_smoo_inten = possible_column_pt[apex].intensmooth;
		*max_R_time = possible_column_pt[apex].R_time;
		*max_scan_num = possible_column_pt[apex].scan_num;
		*starting_time = possible_column_pt[lower_cut].R_time;
		*end_time = possible_column_pt[upper_cut].R_time;
		return real_area;
	} else {
		cout << "area of one_column case" << endl;
		cout << "possible_column_pt[lower_cut].R_time=" << possible_column_pt[lower_cut].R_time << endl; 
		cout << "possible_column_pt_pt[upper_cut].intensiT = " << possible_column_pt[upper_cut].intensiT << endl;
		cout << "initial ref_column_width = " << ref_column_width << endl;
		if (size_of_possible_column_pt>3) {
			if (upper_cut==0) {
				up01=(possible_column_pt[upper_cut+1].scan_index -  possible_column_pt[upper_cut].scan_index);
				ref_column_width = possible_column_pt[upper_cut+1].R_time - possible_column_pt[upper_cut].R_time;
				ref_column_width = ref_column_width/up01;
			} else if (upper_cut == size_of_possible_column_pt-1) {
				down01 = (possible_column_pt[upper_cut].scan_index - possible_column_pt[upper_cut-1].scan_index);
				ref_column_width = possible_column_pt[upper_cut].R_time - possible_column_pt[upper_cut-1].R_time;
				ref_column_width = ref_column_width/down01;
			} else {
				
				up01=(possible_column_pt[upper_cut+1].scan_index -  possible_column_pt[upper_cut].scan_index);
				down01 = (possible_column_pt[upper_cut].scan_index -  possible_column_pt[upper_cut-1].scan_index);
				if ((up01-down01)>3){
					ref_column_width = possible_column_pt[upper_cut].R_time - possible_column_pt[upper_cut-1].R_time;
					ref_column_width = ref_column_width/down01;
				} else if ((up01-down01)<-3) {
					ref_column_width = possible_column_pt[upper_cut+1].R_time - possible_column_pt[upper_cut].R_time;
					ref_column_width = ref_column_width/up01;
				} else {
					ref_column_width = possible_column_pt[upper_cut+1].R_time - possible_column_pt[upper_cut-1].R_time;
					ref_column_width = ref_column_width/(up01+down01);
				}
			}
		} // if size_of_possible_column_pt >3 not does not hold,... ref_column_width was defined LN 593 - 602
		real_area = ref_column_width * possible_column_pt[upper_cut].intensiT;
		cout << "final ref_column_width = " << ref_column_width << endl;
		cout << "real area_P = "<< real_area <<endl;
		*max_smoo_inten = possible_column_pt[apex].intensmooth;
		*max_R_time = possible_column_pt[apex].R_time;
		*max_scan_num = possible_column_pt[apex].scan_num;
		*starting_time = possible_column_pt[lower_cut].R_time; 
		*end_time = possible_column_pt[upper_cut].R_time;
		return real_area ;
	}
}
