#/usr/bin/perl
# This new version will extract the useful information from msms.txt to help identify MS1
# The old basic version was dealing with MS1 output file of MaxQuant only.
# It was to the combination of simple03.pl and block2_new's get_seqm01.pl
#
# Usage:
# 
#  perl temp03.pl Acetyl\ \(K\)Sites.txt msms.txt checking-data
#  Here we have two output files,  checking-data and out-data

## Remember to check the protein modification type at 
## 1. @cell2 = split(/[\(ac\)ahoxdi]/,$cell[17]);
## 2. in subroutine getformula{}  

## in the output we want to have the info (sorted by AA-sequence already)
## 1-1. AA-sequence, mod_sequence, charge, m/z, rawfile of Best Score, scan# of Best Score
## 1-2. # of C H O N S
## 2. sum of the # of free Lysine (K but not K(ac)) and free N-terminal ( _blahblah but not _(ac))
## 3. # of free Lysine (K)
## 4. # of free Lysine (K) at N-terminal
## with info 1 & 2, we can calculate out the natural isotope distribution given the heavy-acetyl number
## (if the acetyl site was occupied, we cannot add heavy atoms onto it; so what we care is unoccupied site)
## for info 2, case of ( _K ) will be doubly counted, it is right, because
##    there are two amines (two acetyl sites) in a lysine at N terminal.
##

## Define a hash structure
## using amino acid symbol as keys and chemical compostion (a string) as correspondent values
$aaCnum{"A"}="C3H7NO2";
$aaCnum{"G"}="C2H5NO2";
$aaCnum{"S"}="C3H7NO3";
$aaCnum{"T"}="C4H9NO3";
$aaCnum{"C"}="C3H7NO2S";  
$aaCnum{"V"}="C5H11NO2";  
$aaCnum{"L"}="C6H13NO2";
$aaCnum{"I"}="C6H13NO2";
$aaCnum{"M"}="C5H11NO2S";
$aaCnum{"P"}="C5H9NO2";
$aaCnum{"F"}="C9H11NO2";
$aaCnum{"Y"}="C9H11NO3";
$aaCnum{"W"}="C11H12N2O2";
$aaCnum{"D"}="C4H7NO4";
$aaCnum{"E"}="C5H9NO4";
$aaCnum{"N"}="C4H8N2O3";
$aaCnum{"Q"}="C5H10N2O3";
$aaCnum{"H"}="C6H9N3O2";
$aaCnum{"K"}="C6H14N2O2";
$aaCnum{"R"}="C6H14N4O2";
## in a cell, Cys is easy to form the disulfide bond with other Cys, so wet bench people let Iodoacetamide C2H4INO
## come in to play, but it modifies S-H to S-C2H4NO 
$aaMass{"A"}= 71.0371137900;
$aaMass{"G"}= 57.0214637260;
$aaMass{"S"}= 87.0320284100;
$aaMass{"T"}=101.0476784740;
$aaMass{"C"}=160.0306485;              ##103.009184800;
$aaMass{"V"}= 99.0684139180;
$aaMass{"L"}=113.0840639820;
$aaMass{"I"}=113.0840639820;
$aaMass{"M"}=131.040484900;
$aaMass{"P"}= 97.0527638540;
$aaMass{"F"}=147.0684139180;
$aaMass{"Y"}=163.0633285380;
$aaMass{"W"}=186.0793129600;
$aaMass{"D"}=115.0269430300;
$aaMass{"E"}=129.0425930940;
$aaMass{"N"}=114.0429274520;
$aaMass{"Q"}=128.0585775160;
$aaMass{"H"}=137.0589118740;
$aaMass{"K"}=128.0949630240;
$aaMass{"R"}=156.1011110440;

##
## Using the above to define 2-dimensional hash aaAllnum
## Please notice that condense reactional water is removed at the end
##
foreach $temp (keys %aaCnum){
    if($aaCnum{$temp}=~ m/C(\d+)/) {
        $aaAllnum{$temp}{"C"}=$1;
    }
 
   if($aaCnum{$temp}=~ m/H(\d+)/) {
        $aaAllnum{$temp}{"H"}=$1;
    }
    if($aaCnum{$temp}=~ m/O(\d+)/) {
        $aaAllnum{$temp}{"O"}=$1;
    }
    if($aaCnum{$temp}=~ m/N/) {
        $aaAllnum{$temp}{"N"}=1;
    } ## maybe just directly assign the value (no need to
      ## have if condition) because every amino acid has
      ## at least a Nitrogen atom.
    if($aaCnum{$temp}=~ m/N(\d+)/) {
        $aaAllnum{$temp}{"N"}=$1;
    }
    $aaAllnum{$temp}{"S"}=0;
    if($aaCnum{$temp}=~ m/S/) {
        $aaAllnum{$temp}{"S"}=1;
    } ## Here I exclude out the situation that an amino
      ## acid has tow or more sulfurs.
    $aaAllnum{$temp}{"H"} = $aaAllnum{$temp}{"H"}-2;
    $aaAllnum{$temp}{"O"} = $aaAllnum{$temp}{"O"}-1;
}

# file1 is reserved for MS1 calculation, file2 is input file "msms.txt"
# file3 is the output of perl and the input of cpp in next stage

my ($file2, $file3) = @ARGV;  
#open my $fh1, '<', $file1;
open my $fh2, '<', $file2;

open my $fout1, '>', $file3 or die $!;
open my $fout2, '>', "out-data" or die $!;

##open (myoutfile, ">>$ARGV[1]");
$mass_HO =  17.002739652;
$mass_H =  1.007825032;
$mass_dif_3DH = 5.025539917; ##3.018830238;now we replace dif_3DH with dif_3DH2C13C12 

foreach $line (<$fh2>) {
    chomp($line);
    if ($line =~ /^Raw\ file/) {
        @cell06 = split(/\t/, $line);
        $size_cell06 = @cell06;
        for($i=0; $i<$size_cell06; $i++){
            if  ($cell06[$i] eq "Modified sequence") {
                $seq_col = $i;
            }
            if  ($cell06[$i] eq "Charge") {
                $charge_col = $i;
            }
            if  ($cell06[$i] eq "m/z") {
                $mz_col = $i;
            }
            if  ($cell06[$i] eq "Masses") {
                $mass_col = $i;
            }
            if  ($cell06[$i] eq "Matches") {
                $match_col = $i;
            }
            if  ($cell06[$i] eq "Scan number") {
                $scann_col = $i;
            }
        }
    } else {
      @cell = split(/\t/, $line);
      @index=(0,0,0,0,0,0);
      ##  if ($cell[$seq_col] =~/^\_\(a/){
      ##  Now we do the chemical reaction first, there will be free N-terminal
      $seque_prec=$cell[$seq_col];
      $num_of_K = scalar(@{[$seque_prec =~ /K/g]});
      $num_of_Kah = scalar(@{[$seque_prec =~ /K\(ah\)/g]});
      $num_of_Kac = scalar(@{[$seque_prec =~ /K\(ac\)/g]});
      $num_of_freeKend = scalar(@{[$seque_prec =~ /K\_/g]});
      if ($num_of_K le 1){
	  next; # only containing one acetyl site, you don't need MS2 info to get stoichiometry.
                # no acetyl sites?... there is no your business. Get out of here.
      }
      if ($num_of_K ge 5){
	  next; #we have not developed the cpp code for this.
      }
      ## KICK OUT the cases containing FREE K.
      if (($num_of_Kah + $num_of_Kac) eq $num_of_K) {
          # In getmass($seque_prec,\%aaMass), it includes a single H atom and sum of condensed(dehydrated) amino acids 
	  $mass_theo_total = getmass($seque_prec,\%aaMass) + $mass_HO + $mass_H*$cell[$charge_col];
	  $precursor_mass = $cell[$mz_col] * $cell[$charge_col];

      # In the following 23 LINEs, we removed the modifications and get pure sequence $cpure
      # and use K instead of split(/\(a[c|h]\)/, $seque_prec) to position acetyl sites
          @cell2pure = split(/[\(ac\)ahoxdiph]/,$seque_prec);
          $size2pure = @cell2pure;
          $cpure="";
          for($i=0; $i<$size2pure; $i++){
              $cpure=$cpure.$cell2pure[$i];
          }
          $num_of_AA = length($cpure)-2;
          $AA_total = scalar(@{[$seque_prec =~ /[A-Z]/g]});
	  unless ($num_of_AA eq $AA_total){
	      die "Some modifications are not considered.\n";
	  }
          @cell_K = split(/K/, $cpure);
	  $sizeK =  @cell_K;## which is num_of_K+1
          ## which is also num_of_acetyl_sites (including N-term)
          ## which should be $size2-1, if 100% acetylized.
          ## $kk = $sizeK - int [($mass_theo_total - $precursor_mass)/(3*(D-H))]
	  print $fout2 "\n\n\n$seque_prec\n";	 print $fout2 "$cpure   $sizeK\n";
	  $index[0] = length($cell_K[0]);
          print $fout2 "$index[0] ";
	  for($ii=1; $ii<($sizeK-1); $ii++){
	      $index[$ii] = $index[$ii-1]+1+length($cell_K[$ii]);
	      print $fout2 "$index[$ii] ";
	  }
	  print $fout2 "\n";

          # In the above, we removed the modifications and get pure sequence $cpure
          # and use K instead of split(/\(a[c|h]\)/, $seque_prec) to position acetyl sites
	 ########################################################################
	 ## $kk is defined as MS1 peak order. That means this MS2 is taken from #
	 ## $kk-th MS1 peak, which contains $kk heavy isotope acetyl sites.     #
	 ########################################################################
	  $determm = ($mass_theo_total - $precursor_mass)/$mass_dif_3DH;
	  ##print  $fout1 "$mass_theo_total   $precursor_mass   determm=  $determm";
          if (($determm < 0.2 ) && ($determm > -0.2)){ $kk =  $num_of_K+1; }
          if (($determm < 1.2 ) && ($determm > 0.8 )) { $kk =  $num_of_K; }
          if (($determm < 2.2 ) && ($determm > 1.8 )) { $kk =  $num_of_K-1; }
          if (($determm < 3.2 ) && ($determm > 2.8 )) { $kk =  $num_of_K-2; }
          if (($determm < 4.2 ) && ($determm > 3.8 )) { $kk =  $num_of_K-3; }
          if (($determm < 5.2 ) && ($determm > 4.8 )) { $kk =  $num_of_K-4; }

	  if ($seque_prec =~/^\_\(ac/){
              $kk++;
          } 

	  @cell2 = split(/\(a[c|h]\)/,$seque_prec);
	  $size2 = @cell2;
	  $c="";
	  for($i=0; $i<$size2; $i++){
	      $c=$c.$cell2[$i];
	  }

## WE just comment out this temporarily	  
	  if ($kk eq ($num_of_K+1)) {
	      next; # the MS2 from the MS1 peak which is of all heavy acetylated is useless in solving stoichiometry.  
	  }
          if ($kk eq 1) {
              next; # the MS2 from the MS1 peak which is of all light acetylated is useless in solving stoichiometry.
          }
          print $fout1 "\n$c\t$num_of_K\t$kk\t";
	  print $fout1 "Scannum\t$cell[$scann_col]\t$cell[0]\t$cell[$mz_col]\t$cell[$charge_col]\n";
	  print $fout1 "$seque_prec\t\$mass_theo_total= $mass_theo_total\t\$precursor_mass=$precursor_mass\t\$determm=$determm\t\$num_of_K=$num_of_K\n";
##	  print $fout1 "$mass_theo_total\t$precursor_mass\n";
	  $offset=0;
	  ## The following 26 lines are used to BUILD A DICTIONARY. 
	  ##
	  if ($seque_prec =~/^\_\(a/){
	      $adjust=6;
	  } else {
	      $adjust=2;
	  }
	  for($i=0; $i<($AA_total-1); $i++){
	      $temp_bion = substr($seque_prec, 0, $i+$offset+$adjust); ##_(ah) ...(ah)
	      $temp_bion_tail = substr($seque_prec, length($temp_bion), 1);
	      if ($temp_bion_tail eq "("){
		  $temp_bion_tail = substr($cell[$seq_col], length($temp_bion), 4);
		  $temp_bion = $temp_bion.$temp_bion_tail;
		  $offset +=4;
	      }
#	      print $fout1 "\$temp_bion=$temp_bion\n";
	      $mass_theob = getmass($temp_bion,\%aaMass);
	      # IF temp_bion is null....

              #print $fout1 "$i\t$temp_bion\t$mass_theob\n";
	      $yi=$AA_total - $i -1;
	      $bi=$i+1;
	      $mass_theo_heavy{b}{($bi)} = $mass_theob;
	      $mass_theo_heavy{y}{($yi)} = $mass_theo_total-$mass_theob+$mass_H*(2-$cell[$charge_col]); 
              # mass_theo_total includes complete general peptides and $cell[$charge_col] of H-atom. 
	      # Since in most of cases, precursors are +2 charged. y-ion is +1 charge, THE FORMULA ABOVE HAS NOT BEEN COMPLETELY VERIFIED.
	      #print $fout1 "b$bi\t$mass_theo_heavy{b}{($bi)}\n";
	      #print $fout1 "y$yi\t$mass_theo_heavy{y}{($yi)}\n";
	  }

#	  for ($i=1; $i<$AA_total; $i++){
#            print $fout1 "b $i $mass_theo_heavy{b}{$i}\n";
#	     print $fout1 "y ($AA_total-$i) $mass_theo_heavy{y}{(14-$i)}\n";
#	  }

	  ## OK, above we built a hash: given a b_ion  order number, it gives you 
	  ## the mass of single charged b_ion in which all acetyl sites are heavy iso acetyl. 
	  ## Now we are equipped to get mass of b_ion from MQ output.

          @cell_mass = split(/\;/,$cell[$mass_col]);
          @cell_match = split(/\;/,$cell[$match_col]);
          $size_mass = @cell_mass;
          $size_match = @cell_match;


	  my @gr1; my @gr2; my @gr3; my @gr4;
	  my @gr1c;my @gr2c;my @gr3c;my @gr4c;
	  my @gr1i;my @gr2i;my @gr3i;my @gr4i;
	  my @ygr1; my @ygr2; my @ygr3; my @ygr4;
	  my @ygr1c;my @ygr2c;my @ygr3c;my @ygr4c;
	  my @ygr1i;my @ygr2i;my @ygr3i;my @ygr4i;
	  
	  my @counter; my @countery;

	  $counter[1]=0; $counter[2]=0; $counter[3]=0; $counter[4]=0; $counter[5]=0;
	  $countery[1]=0; $countery[2]=0; $countery[3]=0; $countery[4]=0; $countery[5]=0;
	  # In case there is case of "no ions in certain group."
	  # assigning to 0, assure it will print out 0 instead of nothing (null string).
	  for($j=0; $j<$size_mass; $j++){
                    #initialize gr1, gr2,gr3,... here.
                    #for ($cell_match[$j] =~/^y/) please see temp05.pl

	      if ($cell_match[$j] =~/^b/) {
		  $bion = "b";
	      } elsif ($cell_match[$j] =~/^y/) {
		  $bion = "y";
	      } else {
		  next;
	      }## we skip a-ion and x-ion 
	      @match_part = split(/[-\(by]/,$cell_match[$j]);
	      @match_part2 = split(/[\(\)\+]/,$cell_match[$j]); ## all fragments should be positively charged
	      @match_part3 = split(/-/,$cell_match[$j]);
	      $ion_order = $match_part[1];
	      $ion_charge = $match_part2[1];
	      $immoni = $match_part3[1];

              if ($ion_charge eq ""){
                  $ion_charge=1;
              }

	      if ($bion eq "b"){
		  if (($ion_order < $index[0])||($ion_order >= $index[$num_of_K-1])){
		      next; # now we kick out ion in group 0;
		  }
#		  print $fout1 "B\t";
		  # determine group number
		  for ($jj=1; $jj<$num_of_K; $jj++){
		      if (($ion_order < $index[$jj])&&($ion_order >= $index[($jj-1)])){
			  $group_index=$jj;
		      }
		  }
		  # determine mass
		  $mass_theo = $mass_theo_heavy{b}{$ion_order};
		  # upper bound in the table could be not all heavy isotope ocupied. 
#		  print $fout1 "$kk $group_index\n";
		  if ( ($kk - $group_index) le 0){
#		      print $fout1 "\$mass_theo before adjust: $mass_theo\n";
		      $mass_theo = $mass_theo + $mass_dif_3DH*($kk - $group_index -1);
#		      print $fout1 "\$kk \$group_index and new mass_theo:  $kk, $group_index, $mass_theo\n";

		  }

	      } else {
	     ##	  print $fout1 "Y\t";
		  $revers=$AA_total-$ion_order; ## $revers is the ion-order of its correspondent b-ion
                  if (($revers < $index[0])||($revers >= $index[$num_of_K-1])){
                      next; # now we kick out ion in group 0;
                  }
		  
                  for ($jj=1; $jj<$num_of_K; $jj++){
                      if (($revers < $index[$jj]) && ($revers >= $index[($jj-1)])){
                          $group_index=$jj;
		      }
                  }
		  # determine mass
                  $mass_theo = $mass_theo_heavy{y}{$ion_order};
		  # upper bound in the table could be not all heavy isotope ocupied. 
              ##    print $fout1 "ion_oder=$ion_order $kk $group_index $num_of_K\n";
		  if ( ($kk + $group_index) le $num_of_K ){
              ##        print $fout1 "\$mass_theo before adjust: $mass_theo\n";
                      $mass_theo = $mass_theo + $mass_dif_3DH*($kk + $group_index -1 - $num_of_K );
              ##        print $fout1 "\$kk \$group_index and new mass_theo:  $kk, $group_index, $mass_theo\n";
                  }

	      } ## if ($bion eq "b")

              #immonium
	      if ($immoni eq "NH3"){
		  $mass_theo -= 17.0265491060;
	      }
	      if ($immoni eq "H2O"){
		  $mass_theo -= 18.0105646840;
	      }

	      print "from msms $cell_mass[$j]\n";
              # single or doubly charged
	      # Actually, in following, "if ($ion_charge eq 1){..}" is quite redundant, because it is just make up a minute
	      # difference between theoretical and what MaxQunat generated... I guess it is from the minute difference 10E-5 that 
	      # standard atomic mass we use.
	      if ($ion_charge eq 1){
		  if ((($mass_theo-$cell_mass[$j]) < 0.2) && (($mass_theo-$cell_mass[$j]) > -0.2)){
		      $output_mass= $cell_mass[$j];
		  }
		  if ( (($mass_theo-$cell_mass[$j]) < (0.2+$mass_dif_3DH)) && (($mass_theo-$cell_mass[$j]) > (-0.2+$mass_dif_3DH ))){
		      $output_mass= $cell_mass[$j]+$mass_dif_3DH; ## 3(D-H)
		  }
		  if ( (($mass_theo-$cell_mass[$j]) < (0.2+2*$mass_dif_3DH)) && (($mass_theo-$cell_mass[$j]) > (-0.2+2*$mass_dif_3DH ))){
		      $output_mass= $cell_mass[$j]+$mass_dif_3DH*2; ## 3(D-H)
		  }
		  if ( (($mass_theo-$cell_mass[$j]) < (0.2+3*$mass_dif_3DH)) && (($mass_theo-$cell_mass[$j]) > (-0.2+3*$mass_dif_3DH ))){
		      $output_mass= $cell_mass[$j]+$mass_dif_3DH*3; ## 3(D-H)
                  }
		  if ( (($mass_theo-$cell_mass[$j]) < (0.2+4*$mass_dif_3DH)) && (($mass_theo-$cell_mass[$j]) > (-0.2+4*$mass_dif_3DH ))){
                      $output_mass= $cell_mass[$j]+$mass_dif_3DH*4; ## 3(D-H)
                  }
	      }
	      if ($ion_charge eq 2){
		  $mass_theo += $mass_H;
		  $mass_theo = $mass_theo/2;
                  if ((($mass_theo-$cell_mass[$j]) < 0.1) && (($mass_theo-$cell_mass[$j]) > -0.1)){
                      $output_mass= $cell_mass[$j];
                  }
                  if ( (($mass_theo-$cell_mass[$j]) < (0.1+$mass_dif_3DH/2)) && (($mass_theo-$cell_mass[$j]) > (-0.1+$mass_dif_3DH/2))){
                      $output_mass= $cell_mass[$j]+$mass_dif_3DH/2;
                  }
		  if ( (($mass_theo-$cell_mass[$j]) < (0.1+$mass_dif_3DH)) && (($mass_theo-$cell_mass[$j]) > (-0.1+$mass_dif_3DH ))){
                      $output_mass= $cell_mass[$j]+$mass_dif_3DH;
                  }
                  if ( (($mass_theo-$cell_mass[$j]) < (0.1+3*$mass_dif_3DH/2)) && (($mass_theo-$cell_mass[$j]) > (-0.1+3*$mass_dif_3DH/2))){
                      $output_mass= $cell_mass[$j]+$mass_dif_3DH*3/2;
                  }
                  if ( (($mass_theo-$cell_mass[$j]) < (0.1+2*$mass_dif_3DH)) && (($mass_theo-$cell_mass[$j]) > (-0.1+2*$mass_dif_3DH ))){
                      $output_mass= $cell_mass[$j]+$mass_dif_3DH*2; 
                  }
	      }
	      
	      if ($bion eq "b"){
		  if ($group_index eq 1){
		      push(@gr1, $output_mass);
		      push(@gr1c,$ion_charge);
		      $counter[1]++;
		      print "counter[1]=$counter[1] output_mass=$output_mass  ion_charge= $ion_charge\n";
		  }
		  if ($group_index eq 2){
		      push(@gr2, $output_mass);
		      push(@gr2c,$ion_charge);
		      $counter[2]++;
		  }
		  if ($group_index eq 3){
		      push(@gr3, $output_mass);
		      push(@gr3c,$ion_charge);
		      $counter[3]++;

		  }
	      } else {
                  if ($group_index eq 1){
                      push(@ygr1, $output_mass);
                      push(@ygr1c,$ion_charge);
                      $countery[1]++;
		      print "countery[1]=$countery[1] output_mass=$output_mass  ion_charge= $ion_charge\n";
                  }
                  if ($group_index eq 2){
                      push(@ygr2, $output_mass);
                      push(@ygr2c,$ion_charge);
                      $countery[2]++;
                  }
                  if ($group_index eq 3){
                      push(@ygr3, $output_mass);
                      push(@ygr3c,$ion_charge);
                      $countery[3]++;
                  }
	      }

#	      if ($j < 25) {
#                  print $fout1 "\$j \$part[1] \$part2[1] \$part3[1]= ";
#		  print $fout1 "$j\t$match_part[1]\t$ion_charge\t$immoni\n";
		  ##order in coloumn masses,ion order num, charge
#		  print $fout1 "$group_index\t$mass_theo\n"
#	      }
#             What the hash gives is are the b-ions on which all acetyl sites are heavy
#             isotope acetylated. But it is impossible for the case that the mass of your
#             precursor indicates that it contains fewer heavy isotope, (See Table B-1, in
#              MS2pre.doc) So,... we do the folowing.   

	  }##  for($j=0; $j<$size_mass; $j++)

	  # Now let's print out group1, group2,... one by one.
	  # in a group we have two subgroups (for b and y ion respectively
	  # before that, we need to determine $num_of_peak accodring to its position in table B

	  #$group_num has range [1, $num_of_K-1]
	  for ($group_num=1; $group_num < $num_of_K; $group_num++){
                    #  ONLY from the inner to the outer of the table .... CANNOT CHANGE the order.
	      if (($kk eq 2)||($kk eq $num_of_K)||($group_num eq 1)||($group_num eq ($num_of_K -1))) {
		  $num_of_peak = 2;
	      } else {
		  if ($num_of_K eq 4) {
		      if (($kk eq 3)&&($group_num eq 2)){
			  $num_of_peak = 3;
		      }
		  }
		  if ($num_of_K eq 5) {
                      if (($kk eq 3)||($kk eq 4)||($group_num eq 2)||($group_num eq 3)){ 
			      $num_of_peak = 3;
		      }
		  }
		  if ($num_of_K eq 6) {
                      if (($kk eq 3)||($kk eq 5)||($group_num eq 2)||($group_num eq 4)){
			  $num_of_peak = 3;
		      }
		      if (($kk eq 4)&&($group_num eq 3)){
			  $num_of_peak = 4;
		      }
                  }
	      }
	      # $num_of_peak for y-ion and b-ion are the same in the same group.

	      print $fout1 "$group_num\t$counter[$group_num]\t$countery[$group_num]\t$num_of_peak\n";
	      if ($group_num == 1){
		  for($ii=0; $ii<$counter[$group_num]; $ii++){
		      print $fout1 "$gr1[$ii] $gr1c[$ii] ";
		  }
		  print $fout1 "\n";
		  for($ii=0; $ii<$countery[$group_num]; $ii++){
                      print $fout1 "$ygr1[$ii] $ygr1c[$ii] ";
                  }
	      }

	      if ($group_num == 2){
		  for($ii=0; $ii<$counter[$group_num]; $ii++){
		      print $fout1 "$gr2[$ii] $gr2c[$ii] ";
		  }
                  print $fout1 "\n";
                  for($ii=0; $ii<$countery[$group_num]; $ii++){
                      print $fout1 "$ygr2[$ii] $ygr2c[$ii] ";
                  }
	      }
	      if ($group_num == 3){
		  for($ii=0; $ii<$counter[$group_num]; $ii++){
		      print $fout1 "$gr3[$ii] $gr3c[$ii] ";
		  }
                  print $fout1 "\n";
                  for($ii=0; $ii<$countery[$group_num]; $ii++){
                      print $fout1 "$ygr3[$ii] $ygr3c[$ii] ";
                  }
	      }

	      print $fout1 "\n";
	  }
      } #if (($num_of_Kah + $num_of_Kac) eq $num_of_K) {
##      } #if ($cell[$seq_col] =~ /^\_\(a/)
    }
}##foreach $line (<fh2>)


sub getmass {
    my $seq = shift;
    my $aacount  = shift;
    my %aaMo = %{$aacount};
    my $mass = 0;
    ##C2D3H(-1)O = 45.0293949220 (all heavy and light are assign no natural isotope distributed.)
    ##C13_2D3H(-1)O = 47.0361046
    $mass += 47.0361046*scalar(@{[$seq =~ /\(ac\)/g]});##because we want get heaviest here!
    $mass += 47.0361046*scalar(@{[$seq =~ /\(ah\)/g]});
    $mass += 15.99491462*scalar(@{[$seq =~ /\(ox\)/g]});
    $mass += 79.96633041*scalar(@{[$seq =~ /\(ph\)/g]});
    ##we still need add many modification masses here
    $seq =~ s/_//g;
    $seq =~ s/\([a-z]*\)//g;
    while($seq=~/./g){
        $mass += $aaMo{$&};
    }
    $mass += $mass_H; ## not water but proton ....because it is b-ion not parent peptide
                      ## This give you complete NH2 on N-terminal but CO only on C-terminal. 
    return $mass;
}


