#include <iostream>
#include <sys/types.h>
#include <math.h>
#include <stdlib.h>
#include <math.h>
#include "base64.h"
#include "ramp.h"
#include "cramp.hpp"
#include "alloc.h"
#include <vector>

using namespace std;
//#define	TRACE		 1
//#define	TRACE_detail 1
//#define	TRACE_detail2 1
//#define TRACE_print  1
//#define constSCAN	3542

/******************
March 25 2013

extract max precursor ion intensity, given a precursor m/z and the spectrum number of nearby MS/MS identification.

*******************/

#define MAX_REDUNDANT_NUM	30		// maximum number of redundant protein ids with overlapping pep id in struct protid
#define H_MONO 1.0078246
#define H2O_MONO 18.01056
#define O_MONO 15.99492
#define IA_MONO 57.02146
#define constSINGLEMZ_PERCENT 0.15
#define constMIN_PRECURSORRANGELOWMZ 50
#define constMIN_PRECURSORRANGEHIGHMZ 4
#define constMIN_INTENSITYLOWMZ 0.05
#define constMIN_INTENSITYHIGHMZ 0.05
#define constMIN_INTENSITYPERCENT 0.002
#define constPEAKSCAN_RANGE 60
#define constTopPeakNumNoiseCalc 7
#define constNOISELEVEL_RATIO 4
#define constISOTOPE_GAP 1.5
#define constISOTOPERATIO_CONSTANT1 0	
#define constISOTOPENOISELEVEL_RATIO 0		
#define constISOTOPERATIO_CONSTANT2 0.0006	// = 1/2500, times m/z and plus ISOTOPERATIO_CONSTANT3 to get max level for peak isotope
#define constISOTOPERATIO_CONSTANT3 0.7		// check above
#define constMissHighMZPercent 0.5			// max percent of high mz peaks that cannot be assigned.
#define constHighMZSNRATIO 10				// MIN SN noise level a High Mz peak is considered to be input to highmzpeak list
#define constMIN_PEAKCOUNTS 10

#define constMSpeakrange 100		// number of peaks in precursor MS spectrum around the precursor ion to check for isotope and SILAC peaks
#define constMSerror 15			// number of ppm for MS error to identify isotope and SILAC peaks based on the precursor M/z, including mass correction for unknown element type than averagine
#define constMSMSerror 100			// number of ppm for MS error to identify isotope and SILAC peaks based on the precursor M/z, including mass correction for unknown element type than averagine
#define constIsoVar1 3		// no more than 3 times allowed for intensity ratio to theoretical intensity ratio
#define constIsoVar2 0.30		// at least 30% for intensity ratio to theoretical intensity ratio

//double constIso[5] = {0,1.003262148, 2.001690634, 3.000227919,3.992872695};
double constIso[6] = {0,1.002861318, 2.001671504, 3.010065,4.01342,5.01678};
float constAveragine=111.1254;
float constC=4.9384;
float constCr=0.0107;
float mass_dif_3DH=5.025539917;//3.018830238;

double factorial(int n){
	double temp;
	if(n <= 1) return 1;
	temp = (double) n * factorial(n - 1);
	return temp;
}

double combination(int n, int r){
	return ((double) factorial(n)/(factorial(r)*factorial(n-r))); 
}
int assign_the_difference(struct column0 *aa, int b);
float max_array(float a[], int num_elements);
int max_intensiT_search(struct column0 *a, int b);
int bestscan_search(struct  column0 *a, int size, int b);
float min_of_two(float a,float b);
float max_of_two(float a,float b);
float summatioN(struct column0 *aa, int b, int c);
int low_1_search(struct column0 *aa, int size, int b);
int low_2_search(struct column0 *aa, int size, int b, float threshold);
int low_3_search(struct column0 *aa, int size, int b, float threshold);
int upper_1_search(struct column0 *aa, int size, int b);
int upper_2_search(struct column0 *a, int size, int b, float threshold);
int upper_3_search(struct column0 *a, int size, int b, float threshold);
int max_int_array(int a[], int b);
int min_int_array(int a[], int b);

struct precursorGroup {
	float elutionStart;
	float elutionEnd;
	int specStart;
	int specEnd;
	float isotopeMz[6];
	double peakintensity;
	float NormMz;

	int isotopeType; // 0= light 1= heavy 2= not determinded when SILAC pair is not detected; spectra with isotopeType=0 or 2 should be put in light peptide cms file and spectra with isotopeType=1 or 2 should be put in heavy peptide cms file
	float normalizedRatio;
	int charge;
	int NumK;
	int NumR;
	int silacdiffType;
	int mcleNum;
	int	maxscan;	// the scan num with the highest precursor intensity

	float silacelutionStart;
	float silacelutionEnd;
	int silacspecStart;
	int silacspecEnd;
	float silacisotopeMz[6];
	double silacpeakintensity;
	float silacNormMz;

	struct precursorGroup *next;
};

struct peakstruct {
	float mz;
	float intensity;
	bool match;
	int pos;
	float snratio;
	float intpercent;
	int charge;		// 0 if charge state cannot be determined
	bool yion;		// true if the ion has a SILAC partner peak and it is a y ion
	bool isotope;   // true if either isotope peak or SILAC partner is identified
};

struct peakscanheader {
	int realpeakscount;				// number of peaks in allpeaks after considering noise reduction
	RAMPREAL* rpeaks;
	struct ScanHeaderStruct scanheader;
	int* highmzrange;		// number of peaks with intensity higher than 5% of max intensity and mz higher than (parent mz+20)
	int highmzpeaknum;
	int* lowmzrange;			// number of peaks with intensity higher than 20% of max intensity and mz lower than (parent mz-20)
	int lowmzpeaknum;
	bool limitedHighions;		// first pass of finding good ions in high mz range to get a number <=2, so the constHighmzint/4 should be applied later on
	int intensitySum_lowmzNum;
	int intensitySum_highmzNum;
	int charge;
	float precbd1;
	float precbd2;
	float lowcut;
	float highcut;
	float precursorlist[25];	// precursor ion candidate list
	float intensitySum_lowmz;	// intensity sum of all significant ions in low mz
	float intensitySum_highmz;	// intensity sum of all significant ions in high mz
	int precursornum;			// precursor ion candidate number
	RAMPREAL* rpeaks0;		// precusor MS scan rpeaks
	struct precursorGroup precursorInfo;
	struct peakstruct allpeaks[4000];	// allpeaks contains all the peaks after noise reduction
};


void quicksort(double* numarray, int len){
	if(len<2) return;
	double array1[100],array2[100], temp;
	int i, j1=0,j2=0;
	temp = numarray[0];
	for(i=1;i<len;i++){
		if(numarray[i]>temp){ array1[j1]=numarray[i]; j1++;}
		else { array2[j2]=numarray[i]; j2++;}
	}
	if(j1>1) quicksort(array1, j1);
	if(j2>1) quicksort(array2, j2);
	for(i=0;i<len;i++){
		if(i<j1) numarray[i]=array1[i];
		else if(i==j1) numarray[i]=temp;
		else if(j2>0) numarray[i]=array2[i-j1-1];
	}
	return;
}

int getprecursorcharge(struct peakscanheader* thescans){
	double tot=0, tothigh=0, precursor;
	int i, count;

	count = thescans->scanheader.peaksCount;
	precursor = thescans->scanheader.precursorMZ;
	for(i=0;i<count;i++){
		tot += thescans->rpeaks[2*i+1];
		if(thescans->rpeaks[2*i] > precursor) tothigh += thescans->rpeaks[2*i+1];
	}
//	char testline[40];
//if(thescans->scanheader.seqNum>=14457){ sprintf(testline,"tothigh=%lf, tot=%lf, percent=%lf", tothigh, tot, tothigh/tot); popmessage(testline);}
	if(tothigh / tot <= constSINGLEMZ_PERCENT) return 1;
	else return 2;
}


/******************************
		Precursor manager
*******************************/


class precursorManager {
public:
	int groupnum;
	struct precursorGroup *head;
	struct precursorGroup *tail;

	precursorManager();
	struct precursorGroup* getnewgroup();
	struct precursorGroup* searchgroup(float currmz, int currspec, int currcharge);
	void invertGroup(struct precursorGroup* src,struct precursorGroup* dst);
};

precursorManager::precursorManager(){
	groupnum=0;
	head = NULL;
	tail = NULL;
}

struct precursorGroup* precursorManager::getnewgroup(){
	struct precursorGroup* temp;

	temp = (struct precursorGroup*) calloc(sizeof(struct precursorGroup),1);
	if(tail==NULL) { tail = temp; head = temp;}
	else {
		tail->next = temp;
		tail = temp;
		temp->next = NULL;
	}
	return(temp);
}

struct precursorGroup* precursorManager::searchgroup(float currmz, int currspec, int currcharge){
	struct precursorGroup *temp, *temp0=NULL, *temp1=NULL, *temp2;
	float mserror0=10000, mserror1=10000, temperror0, temperror1;

	temp = head;
	while(temp!=NULL){
		if(currspec>=temp->specStart && currspec<=temp->specEnd){
			temperror0=fabs(currmz-temp->NormMz)/currmz*1000000;
			if( temperror0<= constMSerror){
				if(temperror0<mserror0) { temp0 = temp; mserror0 = temperror0;}
			}
		}
		if(currspec>=temp->silacspecStart && currspec<=temp->silacspecEnd && temp->silacNormMz>0){
			temperror1=fabs(currmz-temp->silacNormMz)/currmz*1000000;
			if(temperror1<= constMSerror){
				if(temperror1<mserror1) { temp1 = temp; mserror1 = temperror1;}
			}
		}
		temp = temp->next;
	}
	if(temp0 == NULL && temp1 == NULL) return (NULL);
	else if(temp0 != NULL && currcharge==temp0->charge) return (temp0);
	else if(temp1 != NULL && currcharge==temp1->charge){
		temp2 = getnewgroup();
		invertGroup(temp1,temp2);
		return (temp2);
	}
	else return (NULL);
}

void precursorManager::invertGroup(struct precursorGroup* src,struct precursorGroup* dst){
	int i;

	dst->silacelutionEnd = src->elutionEnd;
	dst->silacelutionStart = src->elutionStart;
	dst->silacspecEnd = src->specEnd;
	dst->silacspecStart = src->specStart;
	dst->silacpeakintensity = src->peakintensity;

	dst->elutionEnd = src->silacelutionEnd;
	dst->elutionStart = src->silacelutionStart;
	dst->specEnd = src->silacspecEnd;
	dst->specStart = src->silacspecStart;
	dst->peakintensity = src->silacpeakintensity;

	dst->normalizedRatio = src->normalizedRatio;
	dst->maxscan = src->maxscan;

	for(i=0;i<6;i++) {
		dst->isotopeMz[i] = src->silacisotopeMz[i];
		dst->silacisotopeMz[i] = src->isotopeMz[i];
	}
	if(src->isotopeType==0) dst->isotopeType=1;
	else if (src->isotopeType==1) dst->isotopeType=0;
	else dst->isotopeType = src->isotopeType;

	dst->NormMz = src->silacNormMz;
	dst->silacNormMz = src->NormMz;
	dst->NumK = src->NumK;
	dst->NumR = src->NumR;
	dst->mcleNum = src->mcleNum;
	dst->silacdiffType = src->silacdiffType;
	dst->charge = src->charge;
}

int deconvolute(double *rpeaks, int k1, int k2, int k, double *bArray, int *group,int show){
	int i,j,m,n,p,rank; float diff,diff1, intratio, intratioT;
	// copy rpeaks data into bArray
	for(i=k1;i<=k2;i++) {bArray[3*(i-k1)]=rpeaks[2*i];bArray[3*(i-k1)+1]=rpeaks[2*i+1];bArray[3*(i-k1)+2]=0;} // item 1 and 2 are the same and item 3 is the charge state which is filled later

	// iterate
	for(i=0;i<=(k2-k1);i++){
	// test if i peak is a base peak of an isotope group
		if(bArray[3*i+1]==0) continue; // if i peak has been marked as isotope of previous peaks or i peak is the central precursor which we are looking for its SILAC partner, then continue;
		if(show==1){
			cout<<"deconvolute i="<<i<<" "<<bArray[3*i]<<endl;
		}
		for(m=0;m<6;m++){group[m]=0;}
		for (j=(i+1);j<=(k2-k1);j++){
			if(bArray[3*j+1]==0) continue;
			diff = bArray[3*j]-bArray[3*i];
			if(diff>4) break;	// if peak j is too far away from i then, no longer consider it in isotope group
			for(m=0;m<6;m++){	// m is charge, n is isotope number
				if( (group[m]+1)<6 && fabs(diff*(m+1)-constIso[group[m]+1])/bArray[3*i]*1000000 < constMSerror){
					diff1 = (bArray[3*i]*(m+1)/constAveragine)*constC;		// calculate C number based on average formula
					rank=(diff1-(int)diff1)>0.5?((int)diff1+1):(int)diff1;	// record C number as integer in rank
					intratio=bArray[3*j+1]/bArray[3*i+1];	// the exp peak j to peak i intensity ratio
					intratioT = combination(rank,group[m]+1)*pow(constCr,group[m]+1);  // the theo peak j to peak i intensity ratio
					if(show==1){
						cout<<"	isotope maybe removed j="<<j<<" "<<bArray[3*j]<<" m="<<m<<" rank="<<rank<<" group[m]="<<group[m]<<" combi="<<combination(rank,group[m]+1)<<" fac="<<factorial(21)<<" intratio="<<intratio<<" intratioT="<<intratioT<<endl;
					}
					if(intratio/intratioT < constIsoVar1 && intratio/intratioT > constIsoVar2 ){	// if it is within reasonable range of isotope theoretical ratio,then count peak j as isotope
						if(show==1){
							cout<<"		ratio is ok"<<endl;
						}
						group[m]++;
					}
				}
			}
		}
		n=0;p=-1;
		for(m=5;m>=0;m--){if(group[m]>n) {n = group[m];p=m;}} // now charge state is found as p+1, cycle from high charge to low charge is to favor high charge state first, so that all possible isotopes peaks can be removed
		if(p>=0){
			// record charge state
			bArray[3*i+2]=p+1;
			// mark isotopes to 0
			n=0;
			for (j=(i+1);j<=(k2-k1);j++){
				if(bArray[3*j+1]==0) continue;
				diff = bArray[3*j]-bArray[3*i];
				if(diff>4) break;	// if peak j is too far away from i then, no longer consider it in isotope group
				if((n+1)<6 && fabs(diff*(p+1)-constIso[n+1])/bArray[3*i]*1000000 < constMSerror){
					diff1 = (bArray[3*i]*(p+1)/constAveragine)*constC;		// calculate C number based on average formula
					rank=(diff1-(int)diff1)>0.5?((int)diff1+1):(int)diff1;	// record C number as integer in rank
					intratio=bArray[3*j+1]/bArray[3*i+1];	// the exp peak j to peak i intensity ratio
					intratioT = combination(rank,n+1)*pow(constCr,n+1);  // the theo peak j to peak i intensity ratio
					if(intratio/intratioT < constIsoVar1 && intratio/intratioT > constIsoVar2){	// if it is within reasonable range of isotope theoretical ratio,then count peak j as isotope
						if(show==1){
							cout<<"	isotope to be removed j="<<j<<" "<<bArray[3*j]<<" n="<<n<<" p="<<p<<endl;
						}
						bArray[3*j+1]=0;n++;
						if(n==5) break;
					}
				}
			}
		}
	}
	return 0;
}

int deconvoluteMSMS(double *rpeaks, int k, struct peakstruct *allpeaks,double baseint, int *group,int show){
	int i,j,m,n,p,rank; float diff;
	// copy rpeaks data into allpeaks struct
	for(i=0;i<=k;i++) {
		allpeaks[i].mz=rpeaks[2*i];allpeaks[i].intensity=rpeaks[2*i+1];allpeaks[i].charge=0;allpeaks[i].isotope=false;
		allpeaks[i].intpercent=allpeaks[i].intensity/baseint;allpeaks[i].match=false;allpeaks[i].pos=i;allpeaks[i].snratio=0;allpeaks[i].yion=false;
	}

	// iterate
	for(i=0;i<k;i++){
	// test if i peak is a base peak of an isotope group
		if(allpeaks[i].intensity==0) continue; // if i peak has been marked as isotope of previous peaks , then continue;
		if(show==1){
			cout<<"deconvoluteMSMS i="<<i<<" "<<allpeaks[i].mz<<endl;
		}
		rank=0;
		for(m=0;m<6;m++){group[m]=0;}
		for (j=(i+1);j<k;j++){
			if(allpeaks[j].intensity==0 || allpeaks[j].intensity/allpeaks[i].intensity > 2) continue;
			diff = allpeaks[j].mz-allpeaks[i].mz;
			if(show==1){
				cout<<"		peak j="<<j<<" "<<allpeaks[j].mz<<" "<<diff<<" "<<constIso[1]<<" "<<fabs(diff-constIso[1])<<" "<<fabs(diff-constIso[1])/allpeaks[i].mz*1000000<<endl;
			}
			if(diff>4.1) break;	// if peak j is too far away from i then, no longer consider it in isotope group
			for(m=0;m<6;m++){	// m is charge, n is isotope number
				if( (group[m]+1)<6 && fabs(diff*(m+1)-constIso[group[m]+1])/allpeaks[i].mz*1000000 < constMSMSerror){group[m]++;}
			}
		}
		n=0;p=-1;
		for(m=0;m<6;m++){
			if(group[m]>n) {n = group[m];p=m;}
			if(show==1){
				cout<<"	group m="<<m<<" "<<group[m]<<endl;
			}
		} // now charge state is found as p+1
		if(p>=0){
			// record charge state
			allpeaks[i].charge=p+1;
			allpeaks[i].isotope=true;		// set to true if the isotope of the peak i can be found or its SILAC partner peak can be found
			// mark isotopes to 0
			n=0;
			for (j=(i+1);j<k;j++){
				if(allpeaks[j].intensity==0 || allpeaks[j].intensity/allpeaks[i].intensity > 2) continue;
				diff = allpeaks[j].mz-allpeaks[i].mz;
				if(diff>4) break;	// if peak j is too far away from i then, no longer consider it in isotope group
				if((n+1)<6 && fabs(diff*(p+1)-constIso[n+1])/allpeaks[i].mz*1000000 < constMSMSerror){
					allpeaks[j].intensity=0;n++;
					if(n==5) break;
				}
			}
		}
		if(show==1){
			cout<<"	charge p= "<<p<<" "<<allpeaks[i].charge<<endl;
		}
	}
	return 0;
}





struct trio1
{
  float mz;
  int charge;
  int scannum;
};

struct whatms2fetcherneed
{
  string fname;
  std::vector<trio1> trio;
};



/****************************** 
        OLD Main function
*******************************/
//int main(int argc, char** argv){
//double PPintegrator(char* rawfilename, int scannum_input, double precmz,  int addinfo){
//void ms2fetcher(int num_of_peak, whatms2fetcherneed tempfetcher_input, std::vector<vector<float> >  Intens_unit){
void ms2fetcher(int num_of_peak, whatms2fetcherneed tempfetcher_input, std::vector<vector<float> >& Intens_unit, int byion_indicater){
//Usage: ./extractIntensity  [mzXML file] [The scan_num of the bestscan] [m/z] [1=additional info, 0=none"<<endl;
  cout << "checkpt AA000" << endl;
  RAMPFILE* rawf;
  struct peakscanheader allscans, *thescans;
  ramp_fileoffset_t scanindex;
  int i,lscan;
  int pscan=0,ppeakcount=0; /*PTMap2*/ // the scannum and peakcount of the precursor scan of the MS/MS scan 
  char *temp0;
  bool highresMS,CentroidMS;
  precursorManager* pmanager;
  ScanHeaderStruct precHeader;	// precursor scan header
  
  //YingHua's modification begin here
  //
  float temp_upperRB,temp_lowerRB, delta, sum, temp_max, ave, temp, prod, intense_sum;
  unsigned g, initial;
  int sizz;
  unsigned jj,j;
  int h;
  std::vector <float> intensiT;
  std::vector <float> lowerRB, upperRB;
  cout << "checkpt AA001" << endl;
  cout << "tempfetcher_input.trio[0].scannum= "<< tempfetcher_input.trio[0].scannum <<endl;
  std::vector <float>  Intens_subunit; //This has num_of_peak elements.
  //  std::vector<vector<float> >  Intens_unit;
  float half_window=0.030;
  std::string tail = ".mzXML";
  tempfetcher_input.fname += tail;

  rawf = rampOpenFile(tempfetcher_input.fname.c_str());
  if(rawf==NULL){
    cout<<"Error: Cannot open mzXML file "<<endl;
    return;
  }
  pmanager = new precursorManager();
  highresMS = true;
  CentroidMS = true;
  scanindex = getIndexOffset(rawf);
  ramp_fileoffset_t * allscansoffset = readIndex(rawf, scanindex, &lscan);
  cout<< "Do I know lscan now3?   lscan = " << lscan <<endl;
  cout<< "Raw file is "<<tempfetcher_input.fname.c_str()<<endl;
  cout<< "                   scannindex = " << scanindex <<endl;
  thescans = &allscans;

  Collector* gbcl;
  temp0 = (char*) malloc(sizeof(char)*100000);
  gbcl = new Collector(temp0,100000);

  cout << " tempfetcher_input.trio.size()=" << tempfetcher_input.trio.size() << endl;

  
  Intens_unit.clear();
  for (g=0; g <tempfetcher_input.trio.size(); g++){
    if (tempfetcher_input.trio[g].charge == 1) {
      delta = mass_dif_3DH;
    }
    if (tempfetcher_input.trio[g].charge == 2) {
      delta = mass_dif_3DH/2;
    }
    lowerRB.clear();
    upperRB.clear();

    for (h=0; h < num_of_peak; h++){
      temp_lowerRB = tempfetcher_input.trio[g].mz + (h+1-num_of_peak)*delta - half_window;
      temp_upperRB = tempfetcher_input.trio[g].mz + (h+1-num_of_peak)*delta + half_window;
      //cout << " tempfetcher_input.trio[g].mz  =" << tempfetcher_input.trio[g].mz << endl;
      //cout << " (h+1-num_of_peak)            " << (h+1-num_of_peak) << endl;
      lowerRB.push_back(temp_lowerRB);
      upperRB.push_back(temp_upperRB);
    }

    //cout << "tempfetcher_input.trio[g].scannum=" << tempfetcher_input.trio[g].scannum << endl;
    pscan = tempfetcher_input.trio[g].scannum;
    readHeader(rawf, allscansoffset[pscan], &(thescans->scanheader));
    //cout<<"thescans->scanheader.basePeakIntensity = "<< thescans->scanheader.basePeakIntensity << endl;
    if(thescans->scanheader.msLevel==2){
      thescans->rpeaks = readPeaks(rawf, allscansoffset[pscan]);
      readHeader(rawf, allscansoffset[pscan],&precHeader);
      ppeakcount = precHeader.peaksCount;
      sizz = 2*ppeakcount;
      initial=0;
      for (h = 0; h < num_of_peak; h++){
	//	cout << "H="<< h<< "\tlowerRB[h]="<<lowerRB[h]<<"        upperRB[h]= "<<upperRB[h]<<endl;
	intensiT.clear();
	//initial=0;
	for( j=initial;j<sizz;j++){
	  if (j % 2==0){
	    if ((thescans->rpeaks[j] > lowerRB[h]) && (thescans->rpeaks[j] < upperRB[h])){
	      intensiT.push_back(thescans->rpeaks[j+1]);
	      //    cout << "h="<< h<< "   j=" <<j<<"   mz="<< thescans->rpeaks[j] <<"   intensiT=" << thescans->rpeaks[j+1] << endl;
	    } else if (thescans->rpeaks[j] > upperRB[h]){
	      if (intensiT.size() > 0) {
		initial = j+1; //make sure if tempfetcher_input.trio[g].mz is always increasing
	      } else {
		initial = 0;
	      }
	      break;

	    }
	  }
	}
	

	//cout << "h=" << h <<"lower upperRB[h] "<< lowerRB[h] <<"  "<<upperRB[h]<< endl;

	if (intensiT.size() == 1) {
	  Intens_subunit.push_back(intensiT[0]);
	} else if (intensiT.size() == 0) {
	  //	  cout << "no peak found. h=" << h <<"  lowerRB[h]+0.6=" << (lowerRB[h]+0.6) <<endl;
	  Intens_subunit.push_back(0);
	} else if (intensiT.size() > 1) {
	  sum = 0;
	  // cout << "intensiT.size()=" << intensiT.size()<< endl;
	  //cout << "intensiT[0]    =" << intensiT[0]<< endl;
          //cout << "intensiT[1]    =" << intensiT[1]<< endl;
	  //cout << "intensiT[last] =" << intensiT[intensiT.size()-1]<< endl;
	  for (jj=0; jj<intensiT.size(); jj++){
	    sum += intensiT[jj];
	  }
	  for (jj=1; jj<intensiT.size(); jj++){
	    if (intensiT[jj-1] > intensiT[jj]){
	      temp = intensiT[jj-1];
	      intensiT[jj-1] = intensiT[jj];
	      intensiT[jj] = temp;
	    }
	  }
	  temp_max = intensiT[intensiT.size()-1];
	  cout << "temp_max ="<< temp_max << endl;
	  if (temp_max > 0.001*(thescans->scanheader.basePeakIntensity)){  
	    Intens_subunit.push_back(temp_max);
	  } else {
	    ave = (sum- temp_max)/(intensiT.size()-1);
	    if (temp_max/ave > 1.6) {      //??? 2? or other value as threshold? 
	      Intens_subunit.push_back(temp_max);
	    } else {
	      Intens_subunit.push_back(0);//???????????
	      //or dump the whole subunit and jump to the next dataset.
	    }
	  } 
	}// else if (intensiT.size() > 1) {

      }//for (h = 0; h<num_of_peak; h++){

      //cout << "g="<<g<<"   Intens_subunit.size() = " << Intens_subunit.size() << "    Scannum=" << pscan <<"   byion_indicater="<< byion_indicater <<endl;
      //cout << "g="<<g<<"   Intens_subunit[0]  = " << Intens_subunit[0] << endl;
      //cout << "g="<<g<<"   Intens_subunit[1]  = " << Intens_subunit[1] << endl;
      // When outliers are assumed to be on L axis, we print out by the following
      //if ( ((Intens_subunit[1]<20) && (byion_indicater==0) && (Intens_subunit[0]> 18000))|| ((Intens_subunit[0]<20) && (byion_indicater==1) && (Intens_subunit[1]> 18000)) )  {
      //	cout  << "g="<<g<<"    Scannum=" << pscan <<"   mz="<< (lowerRB[0] + half_window) <<"   byion="<< byion_indicater<<"   Intens[0]=" << Intens_subunit[0]<<"   Intens[1]=" << Intens_subunit[1]<<endl;
      //}

      // When outliers are assumed to be on H axis, we print out by the following
      if ( ((Intens_subunit[0]<50000) && (byion_indicater==0) && (Intens_subunit[1]> 4000))|| ((Intens_subunit[1]<50000) && (byion_indicater==1) && (Intens_subunit[0]> 4000)) )  {
	cout  << "g="<<g<<"    Scannum=" << pscan <<"   mz="<< (lowerRB[0] + half_window) <<"   byion="<< byion_indicater<<"   Intens[0]=" << Intens_subunit[0]<<"   Intens[1]=" << Intens_subunit[1]<<endl;
      }


      //If it is Y-ion, WE REVERSE THE ORDER. 
      if (byion_indicater == 1) {
	if (Intens_subunit.size() == 2) {
	  temp = Intens_subunit[0];
	  Intens_subunit[0] = Intens_subunit[1];
	  Intens_subunit[1] = temp;
	}
	if (Intens_subunit.size() == 3) {
          temp = Intens_subunit[0];
          Intens_subunit[0] = Intens_subunit[2];
          Intens_subunit[2] = temp;
	}
	if (Intens_subunit.size() == 4) {
          temp = Intens_subunit[0];
          Intens_subunit[0] = Intens_subunit[3];
          Intens_subunit[3] = temp;
	  temp = Intens_subunit[1];
          Intens_subunit[1] = Intens_subunit[2];
          Intens_subunit[2] = temp;
        }	
      }

      intense_sum=0.000;
      for (i=0; i< Intens_subunit.size(); i++){
        intense_sum += Intens_subunit[i];
      }
      if (intense_sum > 0.000) {
	Intens_unit.push_back(Intens_subunit);	
      }
//Here we accept the sample points on axis so we comment out the 7 following lines
//and use the above 7 line to replace them.
/*      
      prod=1.000;
      for (i=0; i< Intens_subunit.size(); i++){
	prod = prod * Intens_subunit[i];
      }
      if (prod !=0) {
	Intens_unit.push_back(Intens_subunit);
      }
*/

 /*   if  ((Intens_subunit[0] !=0) && (Intens_subunit[1] !=0)) {
	Intens_unit.push_back(Intens_subunit);
	} */
      Intens_subunit.clear();

    }//if(thescans->scanheader.msLevel==2){
  }// for (g=0; g< tempfetcher_input.trio.size();g++){
  
  cout << "Intens_unit.size() =" << Intens_unit.size() << endl;

  for(i=0; i < Intens_unit.size(); i++){ 
    cout<<"i= "<<i<<"     Intens_unit[i][0] = "<<Intens_unit[i][0] << endl;
    cout<<"i= "<<i<<"     Intens_unit[i][1] = "<<Intens_unit[i][1] << endl;
  }



  return;

}


/*
cout << "In function ms2fetcher: "<< endl;
cout << "num_of_peak  ="<< num_of_peak <<endl;
cout << "tempfetcher_input.fname          = "<< tempfetcher_input.fname <<endl;
cout << "tempfetcher_input.trio[0].mz     = "<< tempfetcher_input.trio[0].mz <<endl;
cout << "tempfetcher_input.trio[0].charge = "<< tempfetcher_input.trio[0].charge <<endl;
cout << "tempfetcher_input.trio[0].scannum= "<< tempfetcher_input.trio[0].scannum <<endl;
*/
/*

float max_array(float a[], int b)
{ 
    float temp; int i;
    temp = a[0];
    for(i=1;i<b;i++){                
	if (a[i]>temp)
           temp=a[i];
        }         
    return temp;
}

int max_int_array(int a[], int b)
{
    int temp; int i;
    temp = a[0];
    for(i=1;i<b;i++){
        if (a[i]>temp)
           temp=a[i];
        }
    return temp;
}

int min_int_array(int a[], int b)
{
    int temp; int i;
    temp = a[0];
    for(i=1;i<b;i++){
        if (a[i]<temp)
           temp=a[i];
        }
    return temp;
}

/*       
int max_intensiT_search(struct column0 *aa, int size)
{
   int posi; int i;
   float temp;
   for(i=0;i<size;i++){
	if (aa[i].intensiT > temp){
	   posi=i;
	   temp=aa[i].intensiT;
	}
   }
   return posi;
}


int bestscan_search(struct column0 *aa, int size, int b)
{
   int i,c1,c2,j,jj,token_taker,diff_temp;
   c1=b-11;
   c2=b+11;
   int temp[7], difference[7];
   j=0; 	
   for(i=0;i<size;i++){
       	if ((aa[i].scan_num>c1)&&(aa[i].scan_num<c2)) {
	   temp[j]=i;
	   difference[j]= aa[i].scan_num-b;
	   if (difference[j]<0)
		difference[j]= (-1)*difference[j];        
	   j++;
        }
   }
   if (j==1){
	return temp[0];
   }else{ 
	diff_temp=difference[0];
	token_taker = temp[0];
	for(jj=1;jj<j;jj++){
 	    if(difference[jj]<diff_temp){
		diff_temp = difference[jj];
		token_taker = temp[jj];
	    }
	}
	return token_taker;
   }
}

*/
float min_of_two(float a,float b)
{
   if (a>b) 
	return b;
   else
	return a;
}

float max_of_two(float a,float b)
{
   if (a<b) 
        return b;
   else
        return a;
}

int max_of_two(int a, int b)
{
  if (a<b)
    return b;
  else
    return a;
}



