#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <algorithm>
#include <math.h>
//#include <stdlib.h>     /* atoi */

using namespace std;

struct masch
{
	float mz;
	int charge;
	int scannum;
	string rawfname;
};

struct ms2key
{
	string sequence;
	int num_of_K;
	int ms1peak_order;
	int scannum;
	string rawfname;
	float mz_ms1;
	int charge;
	std::vector<int> biondataset_total; //we plan to save the number of dataset in group1 in  dataset_total[0];
	//int dataset_total1, dataset_total2, dataset_total3;
	std::vector<int> yiondataset_total;
	std::vector<int> num_of_peak_to_search;
	std::vector<string> bionstring;
	std::vector<string> yionstring;
};

struct info_MS2_of_an_MS1peak
{
	int ms1peak_order;
	int executep;
	std::vector<int> scannum;
	std::vector<string> rawfname;
	std::vector<float> mz_ms1;
	std::vector<int> charge;
	std::vector<vector<int> > biondataset_total;
	std::vector<vector<int> > yiondataset_total;
	std::vector<int> num_of_peak_to_search;
	std::vector<vector<string> > bionstring;
	std::vector<vector<string> > yionstring;
};

struct seqfamily
{
	string familyseq;  
	int num_of_K;
	int execute;
	std::vector<info_MS2_of_an_MS1peak> ms1p;
};

struct trio1
{
	float mz;
	int charge;
	int scannum;
};

struct whatms2fetcherneed
{
	string fname;
	std::vector<trio1> trio;
};

struct line
{
	float slope;
	float intercept;
	float var_slope;
	float corr_coef;
	float SSE;
	bool infinity_indicator;// bool or int
};

struct slopeanditsvar
{
	float slope;
	float var_slope;
	bool infinity_indicator;// bool or int
};

const int  MAX=3;
float determ(float a[MAX][MAX],int n);
//float determ4(float a[4][4],int n);
float determ2(float a[2][2], int n);

void masch_receiver(int num_of_K, int h, int group_num, vector<masch>& d1, vector<masch>& d2, vector<line>& d5);
//void stoiche_in_a_single_MS1_peak(int num_of_K, int h, std::vector<vector<slopeanditsvar> >& d6);
void stoiche_in_a_single_MS1_peak(int num_of_K, int h, std::vector<vector<slopeanditsvar> >& d6, vector<float>& d7);
void ms2fetcher(int num_of_peak, whatms2fetcherneed d, std::vector<vector<float> >& Intens_unit, int byion_indicater);//d= tempfetcher_input
void regression(int num_of_peak, std::vector<vector<float> >& d3, std::vector<line>& d4);
void outlier_kicking(int num_of_peak, std::vector<vector<float> >& accum_Intens_unit, std::vector<line>& manylines, float threshold);

int main(int argc, char *argv[])
{
	string sss, temp_string;
	//  std::vector<ms2key> lala;
	const float mass_dif_3DH = 5.025539917;//3.018830238; 
	ms2key lala;
	std::vector<ms2key> dudu;
	std::string delimiter1 = "\t";
	std::string delimiter2 = " ";
	ifstream infile;
	infile.open (argv[1]);
	std::fstream outfile1;
	outfile1.open ("ms2dic.txt", std::fstream::in | std::fstream::out | std::fstream::app); //we changed test.txt to ms2dic.txt
	unsigned threshold_for_number_of_samples = 3; //we need at least 3 points to do regression.
	int i, ii,j,k, pos, num_of_data;
	string family_seq_pre="whatever";
	info_MS2_of_an_MS1peak temp_ms1p;
	seqfamily tempfamily;
	std::vector<seqfamily> seqfamilies, newseqfamilies;
	vector<float> stoi_in_single_ms1_peak;

	while(getline(infile,sss))
	{
		size_t pos = 0;
		if((pos = sss.find("Scannum")) != std::string::npos) {
			//	if((pos = sss.find(" ")) != std::string::npos)
			pos = sss.find(delimiter1);
			lala.sequence = sss.substr(0, pos);
			sss.erase(0, pos + delimiter1.length());
			
			pos = sss.find(delimiter1);
			temp_string = sss.substr(0, pos);
			lala.num_of_K = atoi(temp_string.c_str());
			sss.erase(0, pos + delimiter1.length());
			
			pos = sss.find(delimiter1);
			temp_string = sss.substr(0, pos);
			lala.ms1peak_order = atoi(temp_string.c_str());
			sss.erase(0, pos + 2*delimiter1.length()+7); // length("Scannum") =7 ?
			
			pos = sss.find(delimiter1);
			temp_string = sss.substr(0, pos);
			lala.scannum = atoi(temp_string.c_str());
			sss.erase(0, pos + delimiter1.length());
			
			pos = sss.find(delimiter1);
			lala.rawfname = sss.substr(0, pos);
			sss.erase(0, pos + delimiter1.length());

			pos = sss.find(delimiter1);
			temp_string = sss.substr(0, pos);
			lala.mz_ms1 = atof(temp_string.c_str());
			sss.erase(0, pos + delimiter1.length());
			lala.charge = atoi(sss.c_str());

			cout << lala.sequence<<" K"<< lala.num_of_K<<" O"<<lala.ms1peak_order<<" S"<<lala.scannum<<" "<<lala.mz_ms1<<" "<<lala.charge<<endl;
			getline(infile,sss);
			lala.num_of_peak_to_search.clear();
			lala.biondataset_total.clear();
			lala.yiondataset_total.clear();
			lala.bionstring.clear();
			lala.yionstring.clear();
			for (i=0; i < (lala.num_of_K-1); i++){
				getline(infile,sss);
				pos = sss.find(delimiter1);

				sss.erase(0, pos + delimiter1.length());
				pos = sss.find(delimiter1);
				temp_string = sss.substr(0, pos);
				num_of_data = atoi(temp_string.c_str());
				lala.biondataset_total.push_back(num_of_data);
				sss.erase(0, pos + delimiter1.length());

				pos = sss.find(delimiter1);
				temp_string = sss.substr(0, pos);
				num_of_data = atoi(temp_string.c_str());
				lala.yiondataset_total.push_back(num_of_data);
				sss.erase(0, pos + delimiter1.length());

				num_of_data = atoi(sss.c_str());
				lala.num_of_peak_to_search.push_back(num_of_data);

				cout << lala.biondataset_total[i] << " K "<< lala.yiondataset_total[i] <<  " K "<< lala.num_of_peak_to_search[i]<< endl;
				getline(infile,sss);
				lala.bionstring.push_back(sss); 
				getline(infile,sss);
				lala.yionstring.push_back(sss);
				//	  cout << lala.yionstring[i] << endl;
				
			}

			//use push_back to add this info from a row in msms.txt to the vector dudu
			dudu.push_back(lala);

		}//if((pos = sss.find("Scannum")) != std::string::npos)

	}//while(getline(infile,sss))

	cout << "dudu.size()= "<< dudu.size() <<endl;
	//  cout << "std::string::max_size()" << lala.yionstring.max_size() <<endl;

	if(dudu.size()>0){
		tempfamily.familyseq = dudu[0].sequence;
		tempfamily.num_of_K = dudu[0].num_of_K;

		temp_ms1p.ms1peak_order = dudu[0].ms1peak_order;
		temp_ms1p.scannum.push_back(dudu[0].scannum);
		temp_ms1p.rawfname.push_back(dudu[0].rawfname);
		temp_ms1p.mz_ms1.push_back(dudu[0].mz_ms1);
		temp_ms1p.charge.push_back(dudu[0].charge);
		temp_ms1p.biondataset_total.push_back(dudu[0].biondataset_total);
		temp_ms1p.yiondataset_total.push_back(dudu[0].yiondataset_total);
		//temp_ms1p.num_of_peak_to_search = dudu[0].num_of_peak_to_search; //temp_ms1p.num_of_peak_to_search.push_back(dudu[0].num_of_peak_to_search);
		temp_ms1p.bionstring.push_back(dudu[0].bionstring);
		temp_ms1p.yionstring.push_back(dudu[0].yionstring);
		tempfamily.ms1p.push_back(temp_ms1p);

		seqfamilies.push_back(tempfamily);
		cout << "################"<< endl;
		cout << seqfamilies[0].ms1p[0].bionstring[0][0] << endl;
		// cout << seqfamilies[0].ms1p[0].bionstring[0][1] << endl;
		// cout << seqfamilies[0].ms1p[0].bionstring[0][2] << endl;
		cout << seqfamilies[0].ms1p[0].biondataset_total[0][0]<< endl;
		cout << seqfamilies[0].ms1p[0].biondataset_total[0][1]<< endl;
	}
	int same_seq;
	int merge;
	for (ii=1; ii<dudu.size(); ii++){
		same_seq = 0;     
		merge = 0;     
		for (i=0; i<seqfamilies.size(); i++){
			if (dudu[ii].sequence == seqfamilies[i].familyseq){
				same_seq = 1;
				for (j=0; j < seqfamilies[i].ms1p.size(); j++){
					if (dudu[ii].ms1peak_order == seqfamilies[i].ms1p[j].ms1peak_order){
						merge = 1;
						seqfamilies[i].ms1p[j].scannum.push_back(dudu[ii].scannum);
						seqfamilies[i].ms1p[j].rawfname.push_back(dudu[ii].rawfname);
						seqfamilies[i].ms1p[j].mz_ms1.push_back(dudu[ii].mz_ms1);
						//seqfamilies[i].ms1p[j].num_of_peak_to_search.push_back(dudu[ii].num_of_peak_to_search);
						seqfamilies[i].ms1p[j].charge.push_back(dudu[ii].charge);
						seqfamilies[i].ms1p[j].biondataset_total.push_back(dudu[ii].biondataset_total);
						seqfamilies[i].ms1p[j].yiondataset_total.push_back(dudu[ii].yiondataset_total);
						seqfamilies[i].ms1p[j].bionstring.push_back(dudu[ii].bionstring);
						seqfamilies[i].ms1p[j].yionstring.push_back(dudu[ii].yionstring);
						break;
					}
				}
				if (merge == 0){
					//add this new temp_ms1p into vector ms1p
					//seqfamilies[i].ms1p.push_back(temp_ms1p)
					// delete &temp_ms1p;####################supposed to use delete or destruct but glitch here
					temp_ms1p.scannum.clear();  temp_ms1p.rawfname.clear();  temp_ms1p.mz_ms1.clear(); temp_ms1p.charge.clear();
					temp_ms1p.biondataset_total.clear();  temp_ms1p.yiondataset_total.clear(); //temp_ms1p.num_of_peak_to_search.clear();
					temp_ms1p.bionstring.clear();  temp_ms1p.yionstring.clear();

					temp_ms1p.ms1peak_order = dudu[ii].ms1peak_order;
					temp_ms1p.scannum.push_back(dudu[ii].scannum);
					temp_ms1p.rawfname.push_back(dudu[ii].rawfname);
					temp_ms1p.mz_ms1.push_back(dudu[ii].mz_ms1);
					temp_ms1p.charge.push_back(dudu[ii].charge);
					temp_ms1p.biondataset_total.push_back(dudu[ii].biondataset_total);
					temp_ms1p.yiondataset_total.push_back(dudu[ii].yiondataset_total);
					//temp_ms1p.num_of_peak_to_search = dudu[ii].num_of_peak_to_search;//temp_ms1p.num_of_peak_to_search.push_back(dudu[ii].num_of_peak_to_search);
					temp_ms1p.bionstring.push_back(dudu[ii].bionstring);
					temp_ms1p.yionstring.push_back(dudu[ii].yionstring);
					seqfamilies[i].ms1p.push_back(temp_ms1p);

				}//if (merge == 0){
			}//if (dudu[ii].sequence == seqfamilies[i].familyseq){
		}//for(i=0, i<seqfamilies.size(); i++){
		if (same_seq == 0){
			tempfamily.familyseq = dudu[ii].sequence;
			tempfamily.num_of_K = dudu[ii].num_of_K;

			temp_ms1p.scannum.clear();  temp_ms1p.rawfname.clear();  temp_ms1p.mz_ms1.clear(); temp_ms1p.charge.clear(); //temp_ms1p.num_of_peak_to_search.clear();
			temp_ms1p.biondataset_total.clear();  temp_ms1p.yiondataset_total.clear();
			temp_ms1p.bionstring.clear();  temp_ms1p.yionstring.clear();

			temp_ms1p.ms1peak_order = dudu[ii].ms1peak_order;
			temp_ms1p.scannum.push_back(dudu[ii].scannum);
			temp_ms1p.rawfname.push_back(dudu[ii].rawfname);
			temp_ms1p.mz_ms1.push_back(dudu[ii].mz_ms1);
			temp_ms1p.charge.push_back(dudu[ii].charge);
			temp_ms1p.biondataset_total.push_back(dudu[ii].biondataset_total);
			temp_ms1p.yiondataset_total.push_back(dudu[ii].yiondataset_total);
			//temp_ms1p.num_of_peak_to_search = dudu[ii].num_of_peak_to_search;//temp_ms1p.num_of_peak_to_search.push_back(dudu[ii].num_of_peak_to_search);
			temp_ms1p.bionstring.push_back(dudu[ii].bionstring);
			temp_ms1p.yionstring.push_back(dudu[ii].yionstring);
			tempfamily.ms1p.clear();
			tempfamily.ms1p.push_back(temp_ms1p);
			seqfamilies.push_back(tempfamily);
		}
	}//for (ii=1, ii<dudu.size(); i++){	  
	/*  
cout <<"seqfamilies.size()        =" << seqfamilies.size() << endl;
cout <<"seqfamilies[0].num_of_K   =" << seqfamilies[0].num_of_K << endl;
cout <<"seqfamilies[0].ms1p.size()=" << seqfamilies[0].ms1p.size() << endl;
cout <<"seqfamilies[0].ms1p[0].ms1peak_order=" << seqfamilies[0].ms1p[0].ms1peak_order << endl;
cout <<"seqfamilies[0].ms1p[1].ms1peak_order=" << seqfamilies[0].ms1p[1].ms1peak_order << endl;
cout <<"seqfamilies[0].ms1p[2].ms1peak_order=" << seqfamilies[0].ms1p[2].ms1peak_order << endl;
*/

	cout <<"%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%" << endl;
	/*  cout <<"seqfamilies[1].num_of_K   =" <<           seqfamilies[1].num_of_K << endl;
cout <<"seqfamilies[1].ms1p.size()=" <<           seqfamilies[1].ms1p.size() << endl;
cout <<"seqfamilies[1].ms1p[0].ms1peak_order=" << seqfamilies[1].ms1p[0].ms1peak_order << endl;
cout <<"seqfamilies[1].ms1p[1].ms1peak_order=" << seqfamilies[1].ms1p[1].ms1peak_order << endl;
cout <<"seqfamilies[1].ms1p[2].ms1peak_order=" << seqfamilies[1].ms1p[2].ms1peak_order << endl;


cout << "seqfamilies[1].ms1p[0].rawfname[0]=" << seqfamilies[1].ms1p[0].rawfname[0] << endl;
cout << "seqfamilies[1].ms1p[0].biondataset_total[0][0]="<< seqfamilies[1].ms1p[0].biondataset_total[0][0]<< endl;
cout << "seqfamilies[1].ms1p[0].biondataset_total[0][1]="<< seqfamilies[1].ms1p[0].biondataset_total[0][1]<< endl;
cout << "seqfamilies[1].ms1p[0].bionstring[0][0]     = "<< seqfamilies[1].ms1p[0].bionstring[0][0] << endl;
cout << "seqfamilies[1].ms1p[0].bionstring[0][1]     = "<< seqfamilies[1].ms1p[0].bionstring[0][1] << endl;
// cout << seqfamilies[0].ms1p[0].bionstring[0][2] << endl;


cout << "seqfamilies[1].ms1p[0].rawfname[1]=" << seqfamilies[1].ms1p[0].rawfname[1] << endl;
cout << "seqfamilies[1].ms1p[0].biondataset_total[1][0]="<< seqfamilies[1].ms1p[0].biondataset_total[0][0]<< endl;
cout << "seqfamilies[1].ms1p[0].biondataset_total[1][1]="<< seqfamilies[1].ms1p[0].biondataset_total[0][1]<< endl;
cout << "seqfamilies[1].ms1p[0].bionstring[1][0]     = "<< seqfamilies[1].ms1p[0].bionstring[0][0] << endl;
cout << "seqfamilies[1].ms1p[0].bionstring[1][1]     = "<< seqfamilies[1].ms1p[0].bionstring[0][1] << endl;
// cout << seqfamilies[0].ms1p[0].bionstring[0][2] << endl;

*/

	//now exam
	// 1. if each seqfamilies has ms1p[].ms1peak_order from 2 to num_of_K;
	//   if ms1p[].ms1peak_order == 3 is missing then check integral MS1 of this peak
	//   using scannum, rawfname, mz_ms1 in the cases that ms1p[].ms1peak_order == 2,
	//         ms1p[].ms1peak_order == 4.
	// 2. if there is any group has no elements


	int dummy, gr;
	int bsum_temp, ysum_temp;
	int h, found_it[8];
	int counter_for_nofound;
	float input_mz;

	for (i=0; i < seqfamilies.size(); i++){
		cout << "familyseq=" << seqfamilies[i].familyseq << endl;
		//check if there is empty cell ("no b-ion nor y-ion" in cell) 
		//j is the index for ms1 peak... but its real peak order number is... .ms1p[0].ms1peak_order
		for (j=0; j<seqfamilies[i].ms1p.size(); j++){ // for each peak

			seqfamilies[i].ms1p[j].executep=1;
			for (gr=0; gr<(seqfamilies[i].num_of_K-1); gr++){ // for group
				bsum_temp=0; ysum_temp=0;
				for (dummy=0; dummy < seqfamilies[i].ms1p[j].biondataset_total.size(); dummy++){
					bsum_temp += seqfamilies[i].ms1p[j].biondataset_total[dummy][gr];
					ysum_temp += seqfamilies[i].ms1p[j].yiondataset_total[dummy][gr];
				}
				cout << "In the cell that "<<seqfamilies[i].ms1p[j].ms1peak_order <<"-th MS1 peak, and group"<<gr;
				cout << ",  there are "<< bsum_temp << " b datadets ";
				cout << "and "<<  ysum_temp << " y datadets."<< endl;
				if ((bsum_temp + ysum_temp) <= threshold_for_number_of_samples){
					//trash whole seqfamilies[i]
					cout <<"Too few fragments in group"<< (gr+1) <<" bsum_temp ="<<bsum_temp<<"  ysum_temp=" << ysum_temp << endl;
					seqfamilies[i].ms1p[j].executep=0; // for a MS1 peak, if any of its MS2 fragment group is empty, we don't do
					break;                             // further MS2 analysis and jump to next peak(j)
				}
			}//for (gr=0;

		}//for (j=0;
		//The above is to kick out the case if there is empty cell ("no b-ion nor y-ion" in cell)
		//The below is to kick out the case that no MS2 done but MS1 is not negligible. 
		//code AAA  consider removing this code.
		//end code AAA
		// This code BBB may be redundant and can be replaced by "seqfamilies[i].execute=1;"
		// This just to make sure that we will not deal with any sequence which has no executable peak.
		seqfamilies[i].execute=0;
		for (h=2; h <= seqfamilies[i].num_of_K; h++){
			for (j=0; j<seqfamilies[i].ms1p.size(); j++){
				if (seqfamilies[i].ms1p[j].ms1peak_order==h){
					if (seqfamilies[i].ms1p[j].executep > 0){ //
						seqfamilies[i].execute ++;
					}
					break;
				}
			}
		}//  seqfamilies[i].execute now is the number of excutable MS1 peaks for seqfamilies[i] 
		// end of code BBB
	}//for (i=0; i < seqfamilies.size(); i++){

	// B4 REGRESSION: Clean up 1. remove execute=0  2. make sure newseqfamilies[i].ms1p[0].ms1peak_order==2; newseqfamilies[i].ms1p[1].ms1peak_order==3;
	//3. if we remove the code AAA, then execute will be "a member of ms1p" instead of "a member of sefamily."
	for (i=0; i < seqfamilies.size(); i++){

		if (seqfamilies[i].execute > 0){

			tempfamily.familyseq=seqfamilies[i].familyseq;
			tempfamily.num_of_K=seqfamilies[i].num_of_K;
			tempfamily.execute=seqfamilies[i].execute;
			//sort ms1p[] by seqfamilies[i].ms1p[j].ms1peak_order
			tempfamily.ms1p.clear();
			for (h=2; h <= seqfamilies[i].num_of_K; h++){
				for (j=0; j<seqfamilies[i].ms1p.size(); j++){
					if (seqfamilies[i].ms1p[j].ms1peak_order==h){
						if (seqfamilies[i].ms1p[j].executep > 0){ 
							tempfamily.ms1p.push_back(seqfamilies[i].ms1p[j]);
						}
						break; // because ms1peak_order is unique when seqfamilies was built.
					}
				}
			}
			newseqfamilies.push_back(tempfamily);
			//Now newseqfamilies[i].ms1p[0].ms1peak_order is lighest middle MS1 peak 
			//(It is I2 if I2 is fragmented between each 2 adjecent K.) which has
			//enough fragments to get MS2 info (conditional probability.)
		}
	}
	//  seqfamilies.clear();//hope this can de-allocate the memory
	cout <<"newseqfamilies.size() = "<< newseqfamilies.size() << endl;
	if (newseqfamilies.size() > 0 ) {
		for (i=0; i< newseqfamilies.size() ;i++) {
			cout << "newseqfamilies["<<i<<"].familyseq = " << newseqfamilies[i].familyseq << endl;
		}
	}

	//START HERE TONIGHT.

	//  cout << newseqfamilies[0].ms1p[0].bionstring[0][2] <<endl; 
	//                   seq      I2  (row read in msms) group_(arrayindex+1)    
	//                     g      h                  i   j
	int g, product_ind,jj,ms1peak_order_temp;
	masch temp_duo;
	std::vector<masch> duo, duoy;
	std::vector<line> manylines;
	slopeanditsvar temp_ratio;
	std::vector<slopeanditsvar> ratio_of_MS2_for_a_group;
	std::vector<vector<slopeanditsvar> > all_groups_ratio_of_MS2;
	// REGRESSION
	// REGRESSION
	for (g=0; g < newseqfamilies.size(); g++){
		//   outfile1 << newseqfamilies[g].familyseq <<"\t"<< newseqfamilies[g].num_of_K<<endl;
		for (h=0; h <  newseqfamilies[g].ms1p.size(); h++){
			// h is NOT peak number, though it deals with peak number. peak number is ms1p[h].ms1peak_order
			// Since now we accept cases in which some MS1 peaks may be negligible (no MS2 for the peaks), ms1p.size(), or say number of fragmented middle peaks, 
			// cannot be used to determine the upper bound of group index j. But num_of_K and ms1p[h].ms1peak_order together can.  
			for (j=0; j < (newseqfamilies[g].num_of_K-1); j++){ //for example num_of_K=4, that is grp1,2,3 allowed; that is j=0,1,2 allowed.
				duo.clear();
				duoy.clear();   
				for (i=0; i <  newseqfamilies[g].ms1p[h].bionstring.size(); i++){ 
					//for each row in msms.txt which refer to I_(ms1p[h].ms1peak_order) and group number = j+1 
					//split newseqfamilies[g].ms1p[h].bionstring[i] into
					sss = newseqfamilies[g].ms1p[h].bionstring[i][j];
					cout << "ms1p[h].ms1peak_order=" << newseqfamilies[g].ms1p[h].ms1peak_order << "  j=" << j <<"  i="<< i <<endl;
					cout << sss << endl;
					if (newseqfamilies[g].ms1p[h].biondataset_total[i][j] != 0 ) {
						for (k=0;k<newseqfamilies[g].ms1p[h].biondataset_total[i][j];k++){       
							pos = sss.find(delimiter2);
							temp_string = sss.substr(0, pos);	    
							temp_duo.mz=atof(temp_string.c_str());
							sss.erase(0, pos + delimiter2.length());
							pos = sss.find(delimiter2);
							temp_string = sss.substr(0, pos);
							temp_duo.charge=atoi(temp_string.c_str());
							temp_duo.scannum= newseqfamilies[g].ms1p[h].scannum[i];
							temp_duo.rawfname= newseqfamilies[g].ms1p[h].rawfname[i];
							duo.push_back(temp_duo);
							sss.erase(0, pos + delimiter2.length());//will it be a problem at the end of line?
						}//for k
					}
					//do the same on y-ion here.
					sss = newseqfamilies[g].ms1p[h].yionstring[i][j];
					if (newseqfamilies[g].ms1p[h].yiondataset_total[i][j] != 0 ) {
						for (k=0;k<newseqfamilies[g].ms1p[h].yiondataset_total[i][j];k++){
							pos = sss.find(delimiter2);
							temp_string = sss.substr(0, pos);
							//mzb.push_back(atof(temp_string.c_str()));
							temp_duo.mz=atof(temp_string.c_str());
							sss.erase(0, pos + delimiter2.length());
							pos = sss.find(delimiter2);
							temp_string = sss.substr(0, pos);
							//chargeb.push_back(atoi(temp_string.c_str()));
							temp_duo.charge=atoi(temp_string.c_str());
							temp_duo.scannum= newseqfamilies[g].ms1p[h].scannum[i];
							temp_duo.rawfname= newseqfamilies[g].ms1p[h].rawfname[i];
							duoy.push_back(temp_duo);
							sss.erase(0, pos + delimiter2.length());//will it be a problem at the end of line?
						}//for k
					}
				}//for (i=0;

				cout << "seq,     h,           I_ms1p[h].ms1peak_order      group (j+1)    final i=num_of_row_in_msms"<<endl;
				cout << "g =" << g << " h =" << h<< "  ms1p[h].ms1peak_order="<< newseqfamilies[g].ms1p[h].ms1peak_order<<" j=" << j<< "    i="<< i<< endl;
				cout << "BBB" <<endl;
				cout << "YYY" <<endl;
				cout << "BBB b4 getting in masch function    duo.size()=" << duo.size() << endl;
				if (duo.size() < 10) {
					for (i=0; i< duo.size() ;i++) {
						cout << duo[i].mz << " " <<  duo[i].scannum << " "<<  duo[i].charge << " "<< duo[i].rawfname << endl;
					}
				} else {
					for (i=0; i<10; i++) {
						cout << duo[i].mz << " " <<  duo[i].scannum << " "<<  duo[i].charge << " "<< duo[i].rawfname << endl;

					}
				}
				cout << "YYY b4 getting in masch function    duoy.size()=" << duoy.size() << endl;
				if (duoy.size() < 10) {
					for (i=0; i< duoy.size() ;i++) {
						cout << duoy[i].mz << " " <<  duoy[i].scannum << " "<<  duoy[i].charge << " "<< duoy[i].rawfname << endl;
					}
				} else {
					for (i=0; i<10; i++) {
						cout << duoy[i].mz << " " <<  duoy[i].scannum << " "<<  duoy[i].charge << " "<< duoy[i].rawfname << endl;

					}
				}

				//                   seq      I2  (row read in msms) group_(arrayindex+1) 
				//                     g      h                  i   j                 

				ms1peak_order_temp = newseqfamilies[g].ms1p[h].ms1peak_order;
				masch_receiver(newseqfamilies[g].num_of_K, ms1peak_order_temp, j, duo, duoy, manylines);
				//masch_receiver(newseqfamilies[g].num_of_K, h, j, duo, duoy, manylines);
				cout << "WE ARE OUT of masch_receiver!"<< endl;
				cout << "manylines.size()=" << manylines.size() << endl;
				cout << "manylines[0].slope=" << manylines[0].slope << endl;
				cout << "now we should use this and combine it with MS1 to get real stoicheometry." << endl<<endl<<endl;
				ratio_of_MS2_for_a_group.clear();
				for(i=0; i< manylines.size(); i++){
					temp_ratio.slope = manylines[i].slope;
					temp_ratio.var_slope = manylines[i].var_slope;
					temp_ratio.infinity_indicator = manylines[i].infinity_indicator;
					ratio_of_MS2_for_a_group.push_back(temp_ratio);	  
				}
				all_groups_ratio_of_MS2.push_back(ratio_of_MS2_for_a_group);
				ratio_of_MS2_for_a_group.clear();
				manylines.clear();
				duo.clear();
				duoy.clear();
				cout << "j=" << j << " at the end of for j loop" << endl;
			}// for j
			product_ind = 1;
			for (jj=0; jj<all_groups_ratio_of_MS2.size(); jj++){
				product_ind *= all_groups_ratio_of_MS2[jj].size();
			}
			ms1peak_order_temp = newseqfamilies[g].ms1p[h].ms1peak_order;
			if (product_ind > 0){
				stoiche_in_a_single_MS1_peak(newseqfamilies[g].num_of_K, ms1peak_order_temp-2, all_groups_ratio_of_MS2, stoi_in_single_ms1_peak);
			} else { 
				cout << "$$$$$$$$$$$$$ NOT ENOUGH INFOMATION TO GET STOICHEOMETRY $$$$$$$$$$ h="<< h << endl << endl;
			}

			outfile1 << newseqfamilies[g].familyseq <<" ";
			outfile1 << newseqfamilies[g].ms1p[h].ms1peak_order << " " << stoi_in_single_ms1_peak.size();
			for(i=0;i<stoi_in_single_ms1_peak.size();i++){
				cout << "stoi_in_single_ms1_peak" << i << " = " << stoi_in_single_ms1_peak[i] << endl;
				outfile1 << " " << stoi_in_single_ms1_peak[i] ;
			}
			outfile1 << endl;
			all_groups_ratio_of_MS2.clear();
		}// for h
	}//for g

	outfile1.close();
}//end of main() 


//What's input: a set of (mz, charge) and num_of_peak_tosearch 
//what's output in the middle: a set of "intensity set containing num_of_peak_to_search intensities" 
//what's final output: a (set of) ratio.

//Before March h = peak_order-2; Now this does not hold.
//ms1p[h].ms1peak_order 
//Below group_num starts from 0;

void masch_receiver(int num_of_K, int ms1p_order, int group_num, vector<masch>& duo1, vector<masch>& duo1y, vector<line>& manylines)
{
	int i,j,same;
	int num_of_peak;//the number of MS2 peaks in an assembly
	std::vector <whatms2fetcherneed> ms2fetcher_inputs, yms2fetcher_inputs;
	whatms2fetcherneed tempfetcher_input;
	trio1 temp_trio;
	std::vector<vector<float> > Intens_unit, accum_Intens_unit;
	float temp_intense_ratio,M,QU,QL,temp,upper_dev,lower_dev;
	float multiple_of_dev= 1.3;
	int k, median,quarter_upper,quarter_lower;
	std::vector<float>  intense_ratio, Intens_subunit;
	std::vector<vector<float> > Intens_unit1, Intens_unit2;
	line temp_line;
	//std::vector <line> manylines, newmanylines;
	vector<line> manylines2;
	// The real group number ranges [1, $num_of_K-1]
	// Here group_num ranges [1, $num_of_K-2]
	// The following is to determine the number of MS2 peaks in an assembly, num_of_peak. We will use this to search the MS2 peaks.
	if ((ms1p_order == 2)||(ms1p_order == num_of_K)||(group_num == 0)||(group_num == (num_of_K -2))) {            
		num_of_peak = 2;                                             
	} else {
		if (num_of_K == 4) {
			if ((ms1p_order == 3)&&(group_num == 1)){              
				num_of_peak = 3;
			}
		} 
		if (num_of_K == 5) {
			if ((ms1p_order == 3)||(ms1p_order == 4)||(group_num == 1)||(group_num == 2)){
				num_of_peak = 3;
			}
		}
		if (num_of_K == 6) {
			if ((ms1p_order == 3)||(ms1p_order == 5)||(group_num == 1)||(group_num == 3)){
				num_of_peak = 3;
			}	  
			if ((ms1p_order == 4)&&(group_num == 2)){
				num_of_peak = 4;
			} 
		}
	}

	cout << "BBB in masch function    duo1.size()=" << duo1.size() << endl;
	if (duo1.size() < 10) {
		for (i=0; i< duo1.size() ;i++) {
			cout << duo1[i].mz << " " <<  duo1[i].scannum << " "<<  duo1[i].charge << " "<< duo1[i].rawfname << endl;
		}
	} else {
		for (i=0; i<10; i++) {
			cout << duo1[i].mz << " " <<  duo1[i].scannum << " "<<  duo1[i].charge << " "<< duo1[i].rawfname << endl;

		}
	}
	cout << "YYY in masch function    duo1y.size()=" << duo1y.size() << endl;
	if (duo1y.size() < 10) {
		for (i=0; i< duo1y.size() ;i++) {
			cout << duo1y[i].mz << " " <<  duo1y[i].scannum << " "<<  duo1y[i].charge << " "<< duo1y[i].rawfname << endl;
		}
	} else {
		for (i=0; i<10; i++) {
			cout << duo1y[i].mz << " " <<  duo1y[i].scannum << " "<<  duo1y[i].charge << " "<< duo1y[i].rawfname << endl;

		}
	}

	cout << "######### Just got INSIDE OF FUNCTION RECEIVER ###########"<<endl;
	cout << "   num_of_K =  "<< num_of_K <<endl;
	cout << " ms1p_order =  "<< ms1p_order <<endl;
	cout << "  group_num =  "<< group_num <<endl;
	cout << "num_of_MS2peak="<< num_of_peak << endl;

	//
	// CHECK IF FILENAMES ARE THE SAME
	//
	tempfetcher_input.fname = duo1[0].rawfname;

	temp_trio.mz = duo1[0].mz;
	temp_trio.charge = duo1[0].charge; // you should give either charge or delta mz.
	temp_trio.scannum = duo1[0].scannum;

	tempfetcher_input.trio.clear();
	tempfetcher_input.trio.push_back(temp_trio);
	ms2fetcher_inputs.push_back(tempfetcher_input);

	cout << "checking point 000"<< endl;

	for (i=1; i<duo1.size(); i++) {
		same=0;
		for (j=0; j<ms2fetcher_inputs.size(); j++) {
			if (duo1[i].rawfname == ms2fetcher_inputs[j].fname) {
				temp_trio.mz = duo1[i].mz;
				temp_trio.charge = duo1[i].charge; // you should give either charge or delta mz.
				temp_trio.scannum = duo1[i].scannum;
				ms2fetcher_inputs[j].trio.push_back(temp_trio);
				same=1;
				break;
			}
		}
		if (same ==0) {
			tempfetcher_input.fname = duo1[i].rawfname;
			temp_trio.mz = duo1[i].mz;
			temp_trio.charge = duo1[i].charge; // you should give either charge or delta mz.
			temp_trio.scannum = duo1[i].scannum;
			tempfetcher_input.trio.clear();
			tempfetcher_input.trio.push_back(temp_trio);
			ms2fetcher_inputs.push_back(tempfetcher_input);
		}
	}

	cout << "checking point 001"<< endl;

	tempfetcher_input.fname = duo1y[0].rawfname;
	temp_trio.mz = duo1y[0].mz;
	temp_trio.charge = duo1y[0].charge; // you should give either charge or delta mz.
	temp_trio.scannum = duo1y[0].scannum;
	tempfetcher_input.trio.clear();
	tempfetcher_input.trio.push_back(temp_trio);
	yms2fetcher_inputs.push_back(tempfetcher_input);

	for (i=1; i<duo1y.size(); i++) {
		same=0;
		for (j=0; j<yms2fetcher_inputs.size(); j++) {
			if (duo1y[i].rawfname == yms2fetcher_inputs[j].fname) {
				temp_trio.mz = duo1y[i].mz;
				temp_trio.charge = duo1y[i].charge; // you should give either charge or delta mz.
				temp_trio.scannum = duo1y[i].scannum;
				yms2fetcher_inputs[j].trio.push_back(temp_trio);
				same=1;
				break;
			}
		}
		if (same == 0) {
			tempfetcher_input.fname = duo1y[i].rawfname;
			temp_trio.mz = duo1y[i].mz;
			temp_trio.charge = duo1y[i].charge; // you should give either charge or delta mz.
			temp_trio.scannum = duo1y[i].scannum;
			tempfetcher_input.trio.clear();
			tempfetcher_input.trio.push_back(temp_trio);
			yms2fetcher_inputs.push_back(tempfetcher_input);
		}
	}
	//
	// END OF "CHECK IF FILENAMES ARE THE SAME" 
	//
	cout << " ms2fetcher_inputs.size() is the number of the rawfiles will be accessed to get the input of regression." << endl;
	cout << "         ms2fetcher_inputs.size() = "<<  ms2fetcher_inputs.size() << endl;
	cout << "        yms2fetcher_inputs.size() = "<< yms2fetcher_inputs.size() << endl;

	for (i=0; i<ms2fetcher_inputs.size(); i++) {
		cout << " ms2fetcher_inputs[" << i << "].trio.size()=" << ms2fetcher_inputs[i].trio.size() << endl;
		cout << " ms2fetcher_inputs[" << i << "].fname="<<  ms2fetcher_inputs[i].fname << endl; 
		cout << "charge   scannum    mz" << endl;
		if (ms2fetcher_inputs[i].trio.size() <= 5) {
			for (j=0; j<ms2fetcher_inputs[i].trio.size(); j++) {
				cout << ms2fetcher_inputs[i].trio[j].charge << " " << ms2fetcher_inputs[i].trio[j].scannum << " " << ms2fetcher_inputs[i].trio[j].mz <<endl;
			}
		} else {
			for (j=0; j<5; j++) {
				cout << ms2fetcher_inputs[i].trio[j].charge << " " << ms2fetcher_inputs[i].trio[j].scannum << " " << ms2fetcher_inputs[i].trio[j].mz <<endl;
			}
		}
	}

	for (i=0; i<yms2fetcher_inputs.size(); i++) {
		cout << " yms2fetcher_inputs[" << i << "].trio.size()=" << yms2fetcher_inputs[i].trio.size() << endl;
		cout << " yms2fetcher_inputs[" << i << "].fname="<<  yms2fetcher_inputs[i].fname << endl;
		cout << "charge   scannum    mz" << endl;
		if (yms2fetcher_inputs[i].trio.size() <= 5) {
			for (j=0; j<yms2fetcher_inputs[i].trio.size(); j++) {
				cout << yms2fetcher_inputs[i].trio[j].charge << " " << yms2fetcher_inputs[i].trio[j].scannum << " " << yms2fetcher_inputs[i].trio[j].mz <<endl;
			}
		} else {
			for (j=0; j<5; j++) {
				cout << yms2fetcher_inputs[i].trio[j].charge << " " << yms2fetcher_inputs[i].trio[j].scannum << " " << yms2fetcher_inputs[i].trio[j].mz <<endl;
			}
		}
	}

	accum_Intens_unit.clear(); Intens_unit.clear();
	// Since each raw file generate an Intens_unit, here we
	// should have accum_Intens_unit to accumilate Intens_unit.
	//  ms2fetcher_inputs.size() = # of the rawfiles
	cout << "after Intens_unit.clear(); Intens_unit.size()=" << Intens_unit.size() << endl;
	cout << " ms1p_order =  "<< ms1p_order <<endl;
	cout << "  group_num =  "<< group_num <<endl;

	//WOW PROBLEMATIC PART, we should use two loops to deal with bion and yion because yms2fetcher_inputs.size() and ms2fetcher_inputs.size() differ.
	if (ms2fetcher_inputs.size()>=1) {
		for (i=0; i< ms2fetcher_inputs.size(); i++) {
			cout <<endl<< "Ummm....B-ion, give me the Intensity pair of B-ion in the single raw file assigned i="<< i<<endl;
			ms2fetcher(num_of_peak, ms2fetcher_inputs[i], Intens_unit, 0);//the last argument 0 for bion and 1 for yion
			cout << "Intens_unit.size()=" << Intens_unit.size() << endl;
			if (i == 0){
				accum_Intens_unit = Intens_unit;
			} else {
				accum_Intens_unit.insert(accum_Intens_unit.end(), Intens_unit.begin(), Intens_unit.end());
			}
		}
		cout << "just right after all B-ion  ms2fetcher accum_Intens_unit.size()=" << accum_Intens_unit.size() << endl;
		for (i=0; i< yms2fetcher_inputs.size(); i++) {
			cout <<endl<< "Ummm....Y-ion, give me the Intensity pair of Y-ion in the single raw file assigned i="<< i<<endl;
			ms2fetcher(num_of_peak, yms2fetcher_inputs[i], Intens_unit, 1);//the last argument 0 for bion and 1 for yion
			cout << "Intens_unit.size()=" << Intens_unit.size() << endl;
			accum_Intens_unit.insert(accum_Intens_unit.end(), Intens_unit.begin(), Intens_unit.end());
		}
	} else {
		cout << "no B-ions" <<endl;
		for (i=0; i< yms2fetcher_inputs.size(); i++) {
			cout <<endl<< "Ummm....Y-ion, give me the Intensity pair of Y-ion in the single raw file assigned i="<< i<<endl;
			ms2fetcher(num_of_peak, yms2fetcher_inputs[i], Intens_unit, 1);//the last argument 0 for bion and 1 for yion
			cout << "Intens_unit.size()=" << Intens_unit.size() << endl;
			if (i == 0) {
				accum_Intens_unit = Intens_unit;
			} else {
				accum_Intens_unit.insert(accum_Intens_unit.end(), Intens_unit.begin(), Intens_unit.end());
			}
		}
	}
	cout << "accum_Intens_unit.size()=" << accum_Intens_unit.size() << endl;
	cout << "accum_Intens_unit[0].size()=" << accum_Intens_unit[0].size() <<endl;  

	if (accum_Intens_unit[0].size() == 3) {
		//cout << "check pt AA01" << endl;
		intense_ratio.clear();
		for (i=0; i < accum_Intens_unit.size(); i++){
			if (accum_Intens_unit[i][2] != 0.000) {
				temp_intense_ratio = accum_Intens_unit[i][0]/accum_Intens_unit[i][2];
			} else {
				temp_intense_ratio = 500.0;
			}
			intense_ratio.push_back(temp_intense_ratio);
		}
		//This is sorting by L/H
		//median = int( intense_ratio.size()/2 );
		//for (i=1; i< (median+1); i++) {
		for (i=0; i< intense_ratio.size(); i++) {
			for (j=i+1; j< intense_ratio.size(); j++){
				if (intense_ratio[i]<intense_ratio[j]) {
					temp_intense_ratio = intense_ratio[i];
					intense_ratio[i]=intense_ratio[j];
					intense_ratio[j]=temp_intense_ratio;
					for (k=0; k < accum_Intens_unit[i].size(); k++){
						temp = accum_Intens_unit[i][k];
						accum_Intens_unit[i][k]=accum_Intens_unit[j][k];
						accum_Intens_unit[j][k]=temp;
					}
					// or
				}//if  (intense_ratio[i]<intense_ratio[j])
			}
		}
		median = int( intense_ratio.size()/2 );
		quarter_upper = int(0.25*intense_ratio.size()); // Right! because intense_ratio is decreasing series.
		quarter_lower = int(0.75*intense_ratio.size()); // 
		M = intense_ratio[median];
		QU= intense_ratio[quarter_upper];
		QL= intense_ratio[quarter_lower];
		upper_dev = QU - M;
		lower_dev = M- QL;
		if (upper_dev < 1.0) {
			upper_dev = 5;
		}  
		if (lower_dev < 1.0) {
			lower_dev = 5;
		}

		cout << "upper_dev ="<< upper_dev << endl;
		cout << "lower_dev ="<< lower_dev << endl;
		cout << "   M      ="<< M << endl;
		cout << " intense_ratio.size()= " << intense_ratio.size()<< endl;
		cout << "accum_Intens_unit.size()=" <<accum_Intens_unit.size()<<endl;
		Intens_unit2.clear();
		for (i=0; i< intense_ratio.size(); i++) { 
			//here  intense_ratio.size() is the same as  accum_Intens_unit.size() 
			if (((intense_ratio[i] - M) < multiple_of_dev*upper_dev) && ((M - intense_ratio[i]) < multiple_of_dev*lower_dev)){
				if (intense_ratio[i] !=0.00){
					Intens_subunit=accum_Intens_unit[i];
					Intens_unit2.push_back(Intens_subunit);
				} else {
					if (M < 0.3) {
						Intens_subunit=accum_Intens_unit[i];
						Intens_unit2.push_back(Intens_subunit);
					}
				}
			}
		}
		cout << "Intens_unitLH.size()=" << Intens_unit2.size() << endl;

		for (i=0; i< Intens_unit2.size(); i++) {
			cout << i<<"\t";
			for (j=0; j< Intens_unit2[0].size(); j++){
				cout << Intens_unit2[i][j]<<"\t";
			}
			cout << endl;
		}

		if(Intens_unit2.size()>0){
			cout << "MS1 peak order:" << ms1p_order << "    group_number:" << group_num+1<<"  ";
			regression(num_of_peak, Intens_unit2, manylines2);
			cout << "AFTER regression function:"<<endl;
			cout << "     Intens_unitLH.size() =" << Intens_unit2.size() << endl;
			cout << "accum_Intens_unit.size() =" << accum_Intens_unit.size() << endl;
			cout << "       manylinesLH.size() =" << manylines2.size() << endl;
			cout << "    manylinesLH[0].slope   =" << manylines2[0].slope << endl;
			cout << "   manylinesLH[0].intercept=" << manylines2[0].intercept << endl;
			temp_line.slope=manylines2[0].slope;
			temp_line.intercept=manylines2[0].intercept;
			temp_line.var_slope=manylines2[0].var_slope;
			temp_line.corr_coef=manylines2[0].corr_coef;
			temp_line.infinity_indicator=0;
			if ((temp_line.slope < 0.03) && (temp_line.slope > -0.03)){
				temp_line.slope = 0.00;
			} else if ((temp_line.slope < -0.1) || (temp_line.slope > 50)){
				temp_line.infinity_indicator =1;
				temp_line.slope = 100000.00;
			}
			if (temp_line.slope < -1.0) {} else if ( temp_line.slope >= -1.0 ) {} else {
				temp_line.infinity_indicator=1;
			}
			manylines.push_back(temp_line);
		} else {
			cout << "Intens_unit2.size()=0, regression was not done" << endl;
			/*	temp_line.slope=100000.00; temp_line.intercept=0.00;
	temp_line.var_slope=0.00; temp_line.corr_coef=0.00; manylines.push_back(temp_line); */
			//OR SHOULD WE trash the whole seq family and go to next.
		}

		//
		// The above is for L/H. The below is for M/H  
		//
		intense_ratio.clear();
		for (i=0; i < accum_Intens_unit.size(); i++){
			if (accum_Intens_unit[i][2] != 0.000) {
				temp_intense_ratio = accum_Intens_unit[i][1]/accum_Intens_unit[i][2];
			} else {
				temp_intense_ratio = 500.0;
			}
			intense_ratio.push_back(temp_intense_ratio);
		}
		//This is sorting by M/H    
		//median = int( intense_ratio.size()/2 );    
		//for (i=1; i< (median+1); i++) {
		for (i=0; i< intense_ratio.size(); i++) {
			for (j=i+1; j< intense_ratio.size(); j++){
				if (intense_ratio[i]<intense_ratio[j]) {
					temp_intense_ratio = intense_ratio[i];
					intense_ratio[i]=intense_ratio[j];
					intense_ratio[j]=temp_intense_ratio;
					for (k=0; k < accum_Intens_unit[i].size(); k++){
						temp = accum_Intens_unit[i][k];
						accum_Intens_unit[i][k]=accum_Intens_unit[j][k];
						accum_Intens_unit[j][k]=temp;
					}
					// or
				}//if  (intense_ratio[i]<intense_ratio[j])
			}
		}
		median = int( intense_ratio.size()/2 );
		quarter_upper = int(0.25*intense_ratio.size()); // Right! because intense_ratio is decreasing series.
		quarter_lower = int(0.75*intense_ratio.size()); //
		M = intense_ratio[median];
		QU= intense_ratio[quarter_upper];
		QL= intense_ratio[quarter_lower];
		upper_dev = QU - M;
		lower_dev = M- QL;
		if (upper_dev < 1.0) {
			upper_dev = 5;
		}
		if (lower_dev < 1.0) {
			lower_dev = 5;
		}

		cout << "upper_dev ="<< upper_dev << endl;
		cout << "lower_dev ="<< lower_dev << endl;
		cout << "   M      ="<< M << endl;
		cout << " intense_ratio.size()= " << intense_ratio.size()<< endl;
		cout << "accum_Intens_unit.size()=" <<accum_Intens_unit.size()<<endl;
		Intens_unit2.clear();
		for (i=0; i< intense_ratio.size(); i++) {
			//here  intense_ratio.size() is the same as  accum_Intens_unit.size()
			if (((intense_ratio[i] - M) < multiple_of_dev*upper_dev) && ((M - intense_ratio[i]) < multiple_of_dev*lower_dev)){
				if (intense_ratio[i] != 0.00){
					Intens_subunit=accum_Intens_unit[i];
					Intens_unit2.push_back(Intens_subunit);
				} else {
					if (M < 0.3) {
						Intens_subunit=accum_Intens_unit[i];
						Intens_unit2.push_back(Intens_subunit);
					}
				}
			}
		}

		cout << "Intens_unitMH.size()=" << Intens_unit2.size() << endl;

		for (i=0; i< Intens_unit2.size(); i++) {
			cout << i<<"\t";
			for (j=0; j< Intens_unit2[0].size(); j++){
				cout << Intens_unit2[i][j]<<"\t";
			}
			cout << endl;
		}

		if(Intens_unit2.size()>0){
			cout << "MS1 peak order:" << ms1p_order << "    group_number:" << group_num+1<<"  ";
			regression(num_of_peak, Intens_unit2, manylines2);
			
			cout << "AFTER regression function:"<<endl;
			cout << "     Intens_unitMH.size() =" << Intens_unit2.size() << endl;
			cout << "accum_Intens_unit.size() =" << accum_Intens_unit.size() << endl;
			cout << "       manylinesMH.size() =" << manylines2.size() << endl;
			cout << "    manylinesMH[0].slope   =" << manylines2[0].slope << endl;
			cout << "   manylinesMH[0].intercept=" << manylines2[0].intercept << endl;
			cout << "    manylinesMH[1].slope   =" << manylines2[1].slope << endl;
			cout << "   manylinesMH[1].intercept=" << manylines2[1].intercept << endl;
			temp_line.slope=manylines2[1].slope;
			temp_line.intercept=manylines2[1].intercept;
			temp_line.var_slope=manylines2[1].var_slope;
			temp_line.corr_coef=manylines2[1].corr_coef;
			temp_line.infinity_indicator=0;
			if ((temp_line.slope < 0.03) && (temp_line.slope > -0.03)){
				temp_line.slope = 0.00;
			} else if ((temp_line.slope < -0.1) || (temp_line.slope > 50)){
				temp_line.infinity_indicator =1;
				temp_line.slope = 100000.00;
			}
			if (temp_line.slope < -1.0) {} else if ( temp_line.slope >= -1.0 ) {} else {
				temp_line.infinity_indicator=1;
			}
			manylines.push_back(temp_line);
		}else {
			cout << "Intens_unit2.size()=0, regression was not done" << endl;
			//OR SHOULD WE trash the whole seq family and go to next.
		}
	}//if (accum_Intens_unit[0].size() == 3)


	if ( (accum_Intens_unit[0].size()==2)|| ((accum_Intens_unit[0].size()==3) && ((manylines[0].infinity_indicator==1)||(manylines[1].infinity_indicator==1))) ) {
		intense_ratio.clear();
		for (i=0; i < accum_Intens_unit.size(); i++){
			if (accum_Intens_unit[i][1] != 0.000) {
				temp_intense_ratio = accum_Intens_unit[i][0]/accum_Intens_unit[i][1];
			} else {
				if (accum_Intens_unit[i][0] != 0.000) {
					temp_intense_ratio = 500.0;
				} else {
					temp_intense_ratio = -20.00;
				}
			}
			intense_ratio.push_back(temp_intense_ratio);
		}
		//here if in 3-peak-case, sorting by L/M
		for (i=0; i<intense_ratio.size(); i++) {     
			for (j=i+1; j<intense_ratio.size(); j++){
				if (intense_ratio[i]<intense_ratio[j]) {  // sorting into decreasing series
					temp_intense_ratio = intense_ratio[i];
					intense_ratio[i]=intense_ratio[j];
					intense_ratio[j]=temp_intense_ratio;
					for (k=0; k < accum_Intens_unit[i].size(); k++){
						temp = accum_Intens_unit[i][k];
						accum_Intens_unit[i][k]=accum_Intens_unit[j][k];
						accum_Intens_unit[j][k]=temp;
					}
					// or 
				}//if  (intense_ratio[i]<intense_ratio[j])
			} 
		}
		median = int( intense_ratio.size()/2 );
		quarter_upper = int(0.25*intense_ratio.size()); // Right! because intense_ratio is decreasing series.
		quarter_lower = int(0.75*intense_ratio.size()); //
		M = intense_ratio[median];
		QU= intense_ratio[quarter_upper];
		QL= intense_ratio[quarter_lower];
		upper_dev = QU - M;
		lower_dev = M- QL;
		if (upper_dev < 1.0) {
			upper_dev = 5;
		}
		if (lower_dev < 1.0) {
			lower_dev = 5;
		}

		cout << "upper_dev ="<< upper_dev << endl;
		cout << "lower_dev ="<< lower_dev << endl;
		cout << "   M      ="<< M << endl;
		cout << " intense_ratio.size()= " << intense_ratio.size()<< endl;
		cout << "accum_Intens_unit.size()=" <<accum_Intens_unit.size()<<endl;
		Intens_unit1.clear();
		for (i=0; i< intense_ratio.size(); i++) {
			//here  intense_ratio.size() is the same as  accum_Intens_unit.size()
			if (((intense_ratio[i] - M) < multiple_of_dev*upper_dev) && ((M - intense_ratio[i]) < multiple_of_dev*lower_dev)){
				if (intense_ratio[i] !=0){
					Intens_subunit=accum_Intens_unit[i];
					Intens_unit1.push_back(Intens_subunit);
				} else {
					if (M < 0.3) {
						Intens_subunit=accum_Intens_unit[i];
						Intens_unit1.push_back(Intens_subunit);
					}
				}
			}
		}

		cout << "Intens_unitLHorLM.size()=" << Intens_unit1.size() << endl;    
		for (i=0; i< Intens_unit1.size(); i++) {
			cout << i<<"\t";
			for (j=0; j< Intens_unit1[0].size(); j++){
				cout << Intens_unit1[i][j]<<"\t";
			}
			cout << endl;
		}

		if(Intens_unit1.size()>0){
			cout << "MS1 peak order:" << ms1p_order << "    group_number:" << group_num+1<<"  ";
			regression(num_of_peak, Intens_unit1, manylines2);
			//Here we know that
			//if accum_Intens_unit[0].size() == 2, we will use manylines[0];
			//if accum_Intens_unit[0].size() == 3, we will use manylines[2]; r5 or say L/M
			if (accum_Intens_unit[0].size()==2) {
				cout << "AFTER regression function:"<<endl;
				cout << "accum_Intens_unit.size() =" << accum_Intens_unit.size() << endl;
				cout << "       manylines.size()  =" << manylines2.size() << endl;
				cout << "    manylines[0].slope   =" << manylines2[0].slope << endl;
				cout << "   manylines[0].intercept=" << manylines2[0].intercept << endl;
				temp_line.slope=manylines2[0].slope;
				temp_line.intercept=manylines2[0].intercept;
				temp_line.var_slope=manylines2[0].var_slope;
				temp_line.corr_coef=manylines2[0].corr_coef;
			} else if (accum_Intens_unit[0].size()==3) {
				cout << "AFTER regression function:"<<endl;
				cout << "accum_Intens_unit.size() =" << accum_Intens_unit.size() << endl;
				cout << "       manylines.size()  =" << manylines2.size() << endl;
				cout << "    manylines[2].slope   =" << manylines2[2].slope << endl;
				cout << "   manylines[2].intercept=" << manylines2[2].intercept << endl;
				temp_line.slope=manylines2[2].slope;
				temp_line.intercept=manylines2[2].intercept;
				temp_line.var_slope=manylines2[2].var_slope;
				temp_line.corr_coef=manylines2[2].corr_coef;
			}
			temp_line.infinity_indicator =0;
			if ((temp_line.slope < 0.03) && (temp_line.slope > -0.03)){
				temp_line.slope = 0.00;
			} else if ((temp_line.slope < -0.1) || (temp_line.slope > 50)){
				temp_line.infinity_indicator =1;
				temp_line.slope = 100000.00;
			}
			if (temp_line.slope < -1.0) {} else if ( temp_line.slope >= -1.0 ) {} else {
				temp_line.infinity_indicator=1;
			}
			manylines.push_back(temp_line);
		} else {
			cout << "Intens_unit1.size()=0, regression was not done" << endl;
			/*      temp_line.slope=100000.00; temp_line.intercept=0.00;
		temp_line.var_slope=0.00; temp_line.corr_coef=0.00; manylines.push_back(temp_line);*/
			//OR SHOULD WE trash the whole seq family and go to next.
		}
	}

	//We may need to put judgement by number of sample points on or close to two axes                           
	//here if (No of samples on L axis > 20 times of No of  samples on H axis)                                  

	accum_Intens_unit.clear();
	cout << "TEST! TEST! this is the bottom of function masch_receiver." << endl;
}//end of masch_receiver()


void regression(int num_of_peak, std::vector<vector<float> >& accum_Intens_unit, vector<line>& manylines){
	line line;
	int i,j;
	float sum[num_of_peak],  sumsq[num_of_peak],  sumprod[num_of_peak-1], sumprod_xy;
	float SSE, S_yy, S_zz, S_xx, S_xy, S_xz, S_yz;
	if (accum_Intens_unit.size() < 6) {
		cout << "Warning, sample size may not be large enough, std dev is not reliable."<<endl;
	}
	for (j=0; j<num_of_peak; j++){
		sum[j]=0;
		sumsq[j]=0;
	}
	for (j=0; j<(num_of_peak-1); j++){
		sumprod[j]=0;
	}

	for (i=0; i<accum_Intens_unit.size(); i++){
		for (j=0; j<num_of_peak; j++){
			sum[j] += accum_Intens_unit[i][j];
			sumsq[j] += (accum_Intens_unit[i][j])* (accum_Intens_unit[i][j]);
		}
	} 
	for (j=0; j<num_of_peak; j++){
		cout <<"    sum["<<j<<"]="<<  sum[j] << endl;
	}
	for (j=0; j<num_of_peak; j++){
		cout <<"  sumsq["<<j<<"]="<<sumsq[j] << endl;
	}
	//    sum[0]= summation of x,      sum[1] = summation of y,     sum[2] = summation of z
	//  sumsq[0]= summation of x^2,  sumsq[1] = summation of y^2, sumsq[2] = summation of z^2
	//sumprod[0]= summation of xz, sumprod[1] = summation of yz
	for (i=0; i<accum_Intens_unit.size(); i++){
		for (j=0; j<(num_of_peak-1); j++){
			sumprod[j] += accum_Intens_unit[i][j]*accum_Intens_unit[i][(num_of_peak-1)]; 
		}
	}

	for (j=0; j<(num_of_peak-1); j++){
		cout <<"sumprod["<<j<<"]="<<sumprod[j] << endl;
	}

	if (num_of_peak==3){
		sumprod_xy=0;
		for (i=0; i<accum_Intens_unit.size(); i++){
			sumprod_xy += accum_Intens_unit[i][0]*accum_Intens_unit[i][1];
		}
		cout << "sumprod_xy="<< sumprod_xy << endl;
	}


	switch (num_of_peak) {
	case 2:
		// for  y=f(x)=beta1*x+beta0
		// SSE = Sum of Square for Error = (sum of y^2) - beta0*(sum of y) + beta1*(sum of xy)
		// S^2 = MSE = SSE/(n-2) = (sigma^2)
		// S_XX = Sum of Square for X = (sum of x^2) - ((sum of x)^2/n) 
		// Variance of beta1 = (sigma^2)/S_xx

		//for x=f(y)=beta1*y+beta0
		// SSE = Sum of Square for Error = (sum of x^2) - beta0*(sum of x) + beta1*(sum of xy)
		// S^2 = MSE = SSE/(n-2) = (sigma^2)
		// S_yy = Sum of Square for y = (sum of y^2) - ((sum of y)^2/n)
		// Variance of beta1 = (sigma^2)/S_yy
		line.slope = (accum_Intens_unit.size()*sumprod[0] - sum[1]*sum[0]) / (accum_Intens_unit.size()*sumsq[1] - sum[1]*sum[1]);
		line.intercept = (sum[0]*sumsq[1] - sum[1]*sumprod[0]) / (accum_Intens_unit.size()*sumsq[1] - sum[1]*sum[1]);

		SSE = sumsq[0] - line.intercept *sum[0] + line.slope*sumprod[0];
		S_yy= sumsq[1] - sum[1]*sum[1]/accum_Intens_unit.size();
		line.var_slope = SSE/((accum_Intens_unit.size()-2)*S_yy);
		cout << "Intensity L/H =" << line.slope << "   intercept with L axis:"<< line.intercept <<"  var_beta1 ="<< line.var_slope;
		S_xx = sumsq[0] - sum[0]*sum[0]/accum_Intens_unit.size();
		line.SSE = SSE;
		S_xy = sumprod[0] - sum[0]*sum[1]/accum_Intens_unit.size();
		line.corr_coef = S_xy /( sqrt(S_xx*S_yy) );
		cout << "    corr coef = "<< line.corr_coef <<endl;
		manylines.clear();
		manylines.push_back(line);
		break;
	case 3:
		//for x=f(z)=beta1*z+beta0
		//beta1 = {n*(sum of zx) - (sum of z)(sum of x)} / {n*(sum of z^2) - (sum of z)^2}
		line.slope = (accum_Intens_unit.size()*sumprod[0] - sum[2]*sum[0]) / (accum_Intens_unit.size()*sumsq[2] - sum[2]*sum[2]);
		//beta0 = {(summation of x)(summation of z^2) - (summation of z)(summation of zx)} / {n*(summation of z^2) - (summation of z)^2}
		line.intercept = (sum[0]*sumsq[2] - sum[2]*sumprod[0]) / (accum_Intens_unit.size()*sumsq[2] - sum[2]*sum[2]);

		SSE = sumsq[0] - line.intercept*sum[0] + line.slope*sumprod[0];
		line.SSE = SSE;
		S_zz= sumsq[2] - sum[2]*sum[2]/accum_Intens_unit.size();
		line.var_slope = SSE/((accum_Intens_unit.size()-2)*S_zz);
		cout << "Intensity L/H =" << line.slope << "   intercept with L axis:"<< line.intercept <<"  var_beta1 ="<< line.var_slope;

		S_xx = sumsq[0] - sum[0]*sum[0]/accum_Intens_unit.size();
		S_xz = sumprod[0] - sum[0]*sum[2]/accum_Intens_unit.size();
		line.corr_coef = S_xz /( sqrt(S_xx*S_zz) );
		cout << "    corr coef = "<< line.corr_coef <<endl;
		manylines.clear();
		manylines.push_back(line);
		//for y=f(z)=beta1*y+beta0
		//beta1 = {n*(summation of yz) - (summation of z)(summation of y)} / {n*(summation of z^2) - (summation of z)^2}
		line.slope = (accum_Intens_unit.size()*sumprod[1] - sum[2]*sum[1]) / (accum_Intens_unit.size()*sumsq[2] - sum[2]*sum[2]);
		//beta0 = {(summation of y)(summation of z^2) - (summation of z)(summation of zy)} / {n*(summation of z^2) - (summation of z)^2}
		line.intercept = (sum[1]*sumsq[2] - sum[2]*sumprod[1]) / (accum_Intens_unit.size()*sumsq[2] - sum[2]*sum[2]);    
		SSE = sumsq[1] - line.intercept*sum[1] + line.slope*sumprod[1];
		line.SSE = SSE;
		line.var_slope = SSE/((accum_Intens_unit.size()-2)*S_zz);
		cout << "                               Intensity M/H =" << line.slope << "   intercept with M axis:"<< line.intercept <<"  var_beta1 ="<< line.var_slope;
		S_yy = sumsq[1] - sum[1]*sum[1]/accum_Intens_unit.size();
		S_yz = sumprod[1] - sum[1]*sum[2]/accum_Intens_unit.size();
		line.corr_coef  = S_yz /( sqrt(S_yy*S_zz) );
		cout << "    corr coef = "<< line.corr_coef <<endl;
		manylines.push_back(line);
		//for x=f(y)=beta1*y+beta0
		//beta1 = {n*(summation of xy) - (summation of x)(summation of y)} / {n*(summation of y^2) - (summation of y)^2}
		//beta0 = {(summation of x)(summation of y^2) - (summation of y)(summation of xy)} / {n*(summation of y^2) - (summation of y)^2}
		line.slope = (accum_Intens_unit.size()*sumprod_xy - sum[0]*sum[1]) / (accum_Intens_unit.size()*sumsq[1] - sum[1]*sum[1]);
		line.intercept = (sum[0]*sumsq[1] - sum[1]*sumprod_xy) / (accum_Intens_unit.size()*sumsq[1] - sum[1]*sum[1]);
		SSE = sumsq[0] - line.intercept*sum[0] + line.slope*sumprod_xy;
		line.SSE = SSE;
		S_yy = sumsq[1] - sum[1]*sum[1]/accum_Intens_unit.size();
		S_xx = sumsq[0] - sum[0]*sum[0]/accum_Intens_unit.size();
		line.var_slope = SSE/((accum_Intens_unit.size()-2)*S_yy);
		cout << "                               Intensity L/M =" << line.slope << "   intercept with L axis:"<< line.intercept <<"  var_beta1 ="<<line.var_slope;
		S_xy = sumprod_xy - sum[1]*sum[0]/accum_Intens_unit.size();
		line.corr_coef  = S_xy /( sqrt(S_yy*S_xx) );
		cout << "    corr coef = "<< line.corr_coef <<endl;
		manylines.push_back(line);
		break;
	}
}


void stoiche_in_a_single_MS1_peak(int num_of_K, int h, std::vector<vector<slopeanditsvar> >& all_groups_ratio_of_MS2, std::vector<float>& stoi_in_single_ms1_peak){
	//float dd[3][3];
	int i,j;
	float D,b,c,d;
	//  float alpha_ratio, beta_ratio, gamma_ratio, delta_ratio, ita_ratio, alpha_ratio2;
	float beta_above, beta_below, gamma_above, gamma_below;//  delta_above,  delta_below;
	//later allocate anarray GreekL_frac[num_of_K] make the pointer of the array as an argument of this function;
	float alphaL_frac, betaL_frac, gammaL_frac, deltaL_frac;
	stoi_in_single_ms1_peak.clear();

	cout << "Inside function stoiche_in_a_single_MS1_peak" << endl;
	cout << " num_of_K = "<< num_of_K  << "     h="  <<h  << endl;
	cout << " all_groups_ratio_of_MS2.size() = "<< all_groups_ratio_of_MS2.size() << endl;
	cout << " all_groups_ratio_of_MS2[0].size() = "<< all_groups_ratio_of_MS2[0].size() << endl;
	cout << " all_groups_ratio_of_MS2[1].size() = "<< all_groups_ratio_of_MS2[1].size() << endl;
	cout << " all_groups_ratio_of_MS2[2].size() = "<< all_groups_ratio_of_MS2[2].size() << endl;
	cout << " all_groups_ratio_of_MS2[0][0].slope = "<< all_groups_ratio_of_MS2[0][0].slope << endl;

	if  (num_of_K >=3) {
		cout << " all_groups_ratio_of_MS2[1][0].slope = "<< all_groups_ratio_of_MS2[1][0].slope << endl;
		
		if  ((num_of_K ==4)&&(h==1)){
			cout << " all_groups_ratio_of_MS2[1][1].slope = "<< all_groups_ratio_of_MS2[1][1].slope << endl;
			cout << " all_groups_ratio_of_MS2[1][2].slope = "<< all_groups_ratio_of_MS2[1][2].slope << endl;
		}
		//  cout << " all_groups_ratio_of_MS2[1][1].slope = "<< all_groups_ratio_of_MS2[1][1].slope << endl;
		cout << " all_groups_ratio_of_MS2[2][0].slope = "<< all_groups_ratio_of_MS2[2][0].slope << endl;
	}

	cout << " all_groups_ratio_of_MS2[0][0].infinity_indicator = "<< all_groups_ratio_of_MS2[0][0].infinity_indicator << endl;
	if  (num_of_K >=3) {
		cout << " all_groups_ratio_of_MS2[1][0].infinity_indicator = "<< all_groups_ratio_of_MS2[1][0].infinity_indicator << endl;
		if  ((num_of_K ==4)&&(h==1)){
			cout << " all_groups_ratio_of_MS2[1][1].infinity_indicator = "<< all_groups_ratio_of_MS2[1][1].infinity_indicator << endl;
			cout << " all_groups_ratio_of_MS2[1][2].infinity_indicator = "<< all_groups_ratio_of_MS2[1][2].infinity_indicator << endl;
		}
		//  cout << " all_groups_ratio_of_MS2[1][1].infinity_indicator = "<< all_groups_ratio_of_MS2[1][1].infinity_indicator << endl;
		cout << " all_groups_ratio_of_MS2[2][0].infinity_indicator = "<< all_groups_ratio_of_MS2[2][0].infinity_indicator << endl;
	}

	for (i=0; i<all_groups_ratio_of_MS2.size(); i++){
		for (j=0; j< all_groups_ratio_of_MS2[i].size(); j++){
			if ( all_groups_ratio_of_MS2[i][j].infinity_indicator==1){
				all_groups_ratio_of_MS2[i][j].slope = 10000;
			}
		}
	}


	if (num_of_K ==4) {
		float dd[3][3];
		//const int  MAX=3;
		//float determ(float a[MAX][MAX],int n);
		if (h==0) {
			if (all_groups_ratio_of_MS2[0][0].slope==0){
				if ((all_groups_ratio_of_MS2[1][0].slope==0) && (all_groups_ratio_of_MS2[2][0].slope==0)){
					alphaL_frac = 0;
					betaL_frac  = 1;
					gammaL_frac = 1;
					deltaL_frac = 1;
				} else {
					//game over, skip to next seq family.
				}
			}else if (all_groups_ratio_of_MS2[1][0].slope==0){ //r2==0
				if (all_groups_ratio_of_MS2[2][0].slope==0){
					alphaL_frac = all_groups_ratio_of_MS2[0][0].slope/(1+all_groups_ratio_of_MS2[0][0].slope);
					betaL_frac  = 1/(1+all_groups_ratio_of_MS2[0][0].slope);
					gammaL_frac = 1;
					deltaL_frac = 1;
				} else {
					//game over, skip to next seq family.    
				}
			} else if (all_groups_ratio_of_MS2[2][0].slope==0){ //r3==0
				alphaL_frac = all_groups_ratio_of_MS2[0][0].slope/(1+all_groups_ratio_of_MS2[0][0].slope);
				betaL_frac  = (1+2*all_groups_ratio_of_MS2[1][0].slope+all_groups_ratio_of_MS2[0][0].slope*all_groups_ratio_of_MS2[1][0].slope)/((1+all_groups_ratio_of_MS2[0][0].slope)*(1+all_groups_ratio_of_MS2[1][0].slope));
				gammaL_frac = 1/(1+all_groups_ratio_of_MS2[1][0].slope);
				deltaL_frac = 1;
			} else if (all_groups_ratio_of_MS2[2][0].infinity_indicator==1){//r3 goes infinity
				if ((all_groups_ratio_of_MS2[1][0].infinity_indicator==1) && (all_groups_ratio_of_MS2[0][0].infinity_indicator==1)){
					alphaL_frac = 1;
					betaL_frac  = 1;
					gammaL_frac = 1;
					deltaL_frac = 0;
				} else {
					//game over, skip to next seq family.
				}
			} else if (all_groups_ratio_of_MS2[1][0].infinity_indicator==1){ //r2 goes infinity
				if (all_groups_ratio_of_MS2[0][0].infinity_indicator==1){
					alphaL_frac = 1;
					betaL_frac  = 1;
					gammaL_frac = all_groups_ratio_of_MS2[2][0].slope/(1+all_groups_ratio_of_MS2[2][0].slope);
					deltaL_frac = 1/(1+all_groups_ratio_of_MS2[2][0].slope);
				} else {
					//game over, skip to next seq family.
				}
			} else if (all_groups_ratio_of_MS2[0][0].infinity_indicator==1){//r1 goes infinity
				alphaL_frac = 1;
				betaL_frac  = all_groups_ratio_of_MS2[1][0].slope/(1+all_groups_ratio_of_MS2[1][0].slope);;
				gammaL_frac = (1+2*all_groups_ratio_of_MS2[2][0].slope+all_groups_ratio_of_MS2[1][0].slope*all_groups_ratio_of_MS2[2][0].slope)/((1+all_groups_ratio_of_MS2[1][0].slope)*(1+all_groups_ratio_of_MS2[2][0].slope));
				deltaL_frac = 1/(1+all_groups_ratio_of_MS2[2][0].slope);
			} else {
				dd[0]={-1.000/all_groups_ratio_of_MS2[0][0].slope, -1.000/all_groups_ratio_of_MS2[0][0].slope, 1.000};
				dd[1]={-1.000/all_groups_ratio_of_MS2[1][0].slope, 1.000, 1.000};
				dd[2]={1.000, 1.000, 1.000};
				D = determ(dd, 3);
				
				cout << "D=" << D << endl;
				dd[0][0]=1/all_groups_ratio_of_MS2[0][0].slope; 
				dd[1][0]=1/all_groups_ratio_of_MS2[1][0].slope;  
				dd[2][0]=1/all_groups_ratio_of_MS2[2][0].slope;
				b=determ(dd, 3)/D;
				cout << "b=" << b << endl;

				dd[0]={-1.000/all_groups_ratio_of_MS2[0][0].slope, -1.000/all_groups_ratio_of_MS2[0][0].slope, 1.000};
				dd[1]={-1.000/all_groups_ratio_of_MS2[1][0].slope, 1.000, 1.000};
				dd[2]={1.000, 1.000, 1.000};
				dd[0][1]=1/all_groups_ratio_of_MS2[0][0].slope;
				dd[1][1]=1/all_groups_ratio_of_MS2[1][0].slope;
				dd[2][1]=1/all_groups_ratio_of_MS2[2][0].slope;
				c = determ(dd,3)/D;
				cout << "c=" << c << endl;

				dd[0]={-1.000/all_groups_ratio_of_MS2[0][0].slope, -1.000/all_groups_ratio_of_MS2[0][0].slope, 1.000};
				dd[1]={-1.000/all_groups_ratio_of_MS2[1][0].slope, 1.000, 1.000};
				dd[2]={1.000, 1.000, 1.000};
				dd[0][2]=1/all_groups_ratio_of_MS2[0][0].slope;
				dd[1][2]=1/all_groups_ratio_of_MS2[1][0].slope;
				dd[2][2]=1/all_groups_ratio_of_MS2[2][0].slope;
				d = determ(dd,3)/D;
				cout << "d=" << d << endl;

				alphaL_frac = (1+b+c)/(1+b+c+d);
				betaL_frac  = (1+b+d)/(1+b+c+d);
				gammaL_frac = (1+c+d)/(1+b+c+d);
				deltaL_frac = (b+c+d)/(1+b+c+d);
			}
		}//if (h==0)
		if (h==2) {
			if (all_groups_ratio_of_MS2[2][0].slope==0){ //r3==0
				if ((all_groups_ratio_of_MS2[0][0].slope==0) && (all_groups_ratio_of_MS2[1][0].slope==0)){
					alphaL_frac = 0;
					betaL_frac  = 0;
					gammaL_frac = 0;
					deltaL_frac = 1;	  
				} else {
					//game over, skip to next seq family.
				}
			} else if (all_groups_ratio_of_MS2[1][0].slope==0){ //r2==0 	
				if (all_groups_ratio_of_MS2[0][0].slope==0){
					alphaL_frac = 0;
					betaL_frac  = 0;
					gammaL_frac = all_groups_ratio_of_MS2[2][0].slope/(1+all_groups_ratio_of_MS2[2][0].slope);
					deltaL_frac = 1/(1+all_groups_ratio_of_MS2[2][0].slope);
				} else {
					//game over, skip to next seq family.
				}
			} else if (all_groups_ratio_of_MS2[0][0].slope==0){ //r1==0
				alphaL_frac = 0;
				betaL_frac  = all_groups_ratio_of_MS2[1][0].slope/(1+all_groups_ratio_of_MS2[1][0].slope);
				gammaL_frac = (all_groups_ratio_of_MS2[2][0].slope - all_groups_ratio_of_MS2[1][0].slope)/((1+all_groups_ratio_of_MS2[1][0].slope)*(1+all_groups_ratio_of_MS2[2][0].slope)); 
				deltaL_frac = 1/(1+all_groups_ratio_of_MS2[2][0].slope);
			} else if (all_groups_ratio_of_MS2[0][0].infinity_indicator==1){//r1 goes infinity    
				if ((all_groups_ratio_of_MS2[1][0].infinity_indicator==1) && (all_groups_ratio_of_MS2[2][0].infinity_indicator==1)){
					alphaL_frac = 1;
					betaL_frac  = 0;
					gammaL_frac = 0;
					deltaL_frac = 0;
				} else {
					//game over, skip to next seq family.
				}
			} else if (all_groups_ratio_of_MS2[1][0].infinity_indicator==1){ //r2 goes infinity
				if (all_groups_ratio_of_MS2[2][0].infinity_indicator==1){
					alphaL_frac = all_groups_ratio_of_MS2[0][0].slope/(1+all_groups_ratio_of_MS2[0][0].slope);
					betaL_frac  = 1/(1+all_groups_ratio_of_MS2[0][0].slope);
					gammaL_frac = 0;
					deltaL_frac = 0;
				} else {
					//game over, skip to next seq family.
				}
			} else if (all_groups_ratio_of_MS2[2][0].infinity_indicator==1){//r3 goes infinity
				alphaL_frac = all_groups_ratio_of_MS2[0][0].slope/(1+all_groups_ratio_of_MS2[0][0].slope);
				betaL_frac  = (all_groups_ratio_of_MS2[1][0].slope - all_groups_ratio_of_MS2[0][0].slope)/((1+all_groups_ratio_of_MS2[0][0].slope)*(1+all_groups_ratio_of_MS2[1][0].slope));
				gammaL_frac = 1/(1+all_groups_ratio_of_MS2[1][0].slope);
				deltaL_frac = 0;
			} else {
				dd[0]={1.000, 1.000, 1.000};
				dd[1]={-1.000/all_groups_ratio_of_MS2[1][0].slope, 1.000, 1.000};
				dd[2]={-1.000/all_groups_ratio_of_MS2[2][0].slope, -1.000/all_groups_ratio_of_MS2[2][0].slope, 1.000};
				D = determ(dd, 3);

				cout << "D=" << D << endl;
				dd[0][0]=1/all_groups_ratio_of_MS2[0][0].slope;
				dd[1][0]=1/all_groups_ratio_of_MS2[1][0].slope;
				dd[2][0]=1/all_groups_ratio_of_MS2[2][0].slope;
				b=determ(dd, 3)/D;
				cout << "b=" << b << endl;

				dd[0]={1.000, 1.000, 1.000};
				dd[1]={-1.000/all_groups_ratio_of_MS2[1][0].slope, 1.000, 1.000};
				dd[2]={-1.000/all_groups_ratio_of_MS2[2][0].slope, -1.000/all_groups_ratio_of_MS2[2][0].slope, 1.000};
				dd[0][1]=1/all_groups_ratio_of_MS2[0][0].slope;
				dd[1][1]=1/all_groups_ratio_of_MS2[1][0].slope;
				dd[2][1]=1/all_groups_ratio_of_MS2[2][0].slope;
				c = determ(dd, 3)/D;
				cout << "c=" << c << endl;

				dd[0]={1.000, 1.000, 1.000};
				dd[1]={-1.000/all_groups_ratio_of_MS2[1][0].slope, 1.000, 1.000};
				dd[2]={-1.000/all_groups_ratio_of_MS2[2][0].slope, -1.000/all_groups_ratio_of_MS2[2][0].slope, 1.000};
				dd[0][2]=1/all_groups_ratio_of_MS2[0][0].slope;
				dd[1][2]=1/all_groups_ratio_of_MS2[1][0].slope;
				dd[2][2]=1/all_groups_ratio_of_MS2[2][0].slope;
				d = determ(dd, 3)/D;
				cout << "d=" << d << endl;

				alphaL_frac = 1/(1+b+c+d);
				betaL_frac  = b/(1+b+c+d);
				gammaL_frac = c/(1+b+c+d);
				deltaL_frac = d/(1+b+c+d);
			}
		}// if h==2
		if (h==1) {
			//r2=all_groups_ratio_of_MS2[1][0].slope
			//r3=all_groups_ratio_of_MS2[1][1].slope
			//r4=all_groups_ratio_of_MS2[2][0].slope
			//r5=all_groups_ratio_of_MS2[1][2].slope
			if (all_groups_ratio_of_MS2[0][0].slope==0){
				if (all_groups_ratio_of_MS2[1][0].slope==0){
					//alphaL_frac=0;
					//betaL_frac=r3/(1+r3)
					alphaL_frac  = 0;
					betaL_frac   = all_groups_ratio_of_MS2[1][1].slope / (1+all_groups_ratio_of_MS2[1][1].slope);
					gammaL_frac  = (1+ 2 * all_groups_ratio_of_MS2[2][0].slope + all_groups_ratio_of_MS2[1][1].slope * all_groups_ratio_of_MS2[2][0].slope)/(1+all_groups_ratio_of_MS2[1][1].slope + all_groups_ratio_of_MS2[2][0].slope + all_groups_ratio_of_MS2[1][1].slope * all_groups_ratio_of_MS2[2][0].slope);
					deltaL_frac  = 1/(1+all_groups_ratio_of_MS2[2][0].slope);
					
				} else {
					if ((all_groups_ratio_of_MS2[1][0].infinity_indicator==1)&&(all_groups_ratio_of_MS2[1][1].infinity_indicator==1)){
						if (all_groups_ratio_of_MS2[2][0].infinity_indicator==1){
							alphaL_frac=0.0000; betaL_frac=1.0000; gammaL_frac=1.0000; deltaL_frac=0.0000;
						} else {
							alphaL_frac=0.0000; betaL_frac=1.0000;
							gammaL_frac =all_groups_ratio_of_MS2[2][0].slope/(1.00+all_groups_ratio_of_MS2[2][0].slope);
							deltaL_frac=1/(1.00+all_groups_ratio_of_MS2[2][0].slope);
						}
					}
					cout << "check pt \'A1\'"<<endl;
					//game over, skip to next seq family.
				}
			} else if (all_groups_ratio_of_MS2[2][0].slope==0){ //r4=all_groups_ratio_of_MS2[2][0].slope
				if (all_groups_ratio_of_MS2[1][0].slope==0){
					alphaL_frac  = all_groups_ratio_of_MS2[0][0].slope/(1+all_groups_ratio_of_MS2[0][0].slope);
					betaL_frac   = (all_groups_ratio_of_MS2[1][1].slope -all_groups_ratio_of_MS2[0][0].slope)/(all_groups_ratio_of_MS2[0][0].slope*all_groups_ratio_of_MS2[1][1].slope+all_groups_ratio_of_MS2[0][0].slope +all_groups_ratio_of_MS2[1][1].slope+1);
					gammaL_frac  = 1/(1+all_groups_ratio_of_MS2[1][1].slope);
					deltaL_frac  = 1;
				} else {
					if ((all_groups_ratio_of_MS2[1][0].infinity_indicator==1)&&(all_groups_ratio_of_MS2[1][1].infinity_indicator==1)){
						if (all_groups_ratio_of_MS2[0][0].infinity_indicator==1){
							alphaL_frac=1.0000; betaL_frac=0.0000; gammaL_frac=0.0000; deltaL_frac=1.0000;
						} else{
							alphaL_frac =all_groups_ratio_of_MS2[0][0].slope/(1.00+all_groups_ratio_of_MS2[0][0].slope);
							betaL_frac=1/(1.00+all_groups_ratio_of_MS2[0][0].slope);
							gammaL_frac=0.0000; deltaL_frac=1.0000;
						}
					}
					cout << "check pt \'A2\'"<<endl;
					//game over, skip to next seq family.
				}
			} else if (all_groups_ratio_of_MS2[1][1].slope==0){ //r3==0 
				if (  ((all_groups_ratio_of_MS2[0][0].slope - all_groups_ratio_of_MS2[1][0].slope) < 0.03) && ((all_groups_ratio_of_MS2[0][0].slope - all_groups_ratio_of_MS2[1][0].slope) > -0.03) && ((all_groups_ratio_of_MS2[0][0].slope - all_groups_ratio_of_MS2[2][0].slope) < 0.03) && ((all_groups_ratio_of_MS2[0][0].slope - all_groups_ratio_of_MS2[2][0].slope) > -0.03) ){
					alphaL_frac  = all_groups_ratio_of_MS2[0][0].slope/(1+all_groups_ratio_of_MS2[0][0].slope);
					betaL_frac   = alphaL_frac ;
					gammaL_frac  = 1/(1+all_groups_ratio_of_MS2[0][0].slope);
					deltaL_frac  = gammaL_frac ;
				} else {
					//game over, skip to next seq family.
				}
				
			} else if (all_groups_ratio_of_MS2[0][0].infinity_indicator==1){//r1 goes infinity                                                  
				if ((all_groups_ratio_of_MS2[1][0].infinity_indicator==1) && (all_groups_ratio_of_MS2[1][1].infinity_indicator==1)){
					alphaL_frac  = 1;
					betaL_frac   = all_groups_ratio_of_MS2[1][2].slope/(1+all_groups_ratio_of_MS2[1][2].slope);
					gammaL_frac  = (all_groups_ratio_of_MS2[2][0].slope-all_groups_ratio_of_MS2[1][2].slope)/(all_groups_ratio_of_MS2[2][0].slope*all_groups_ratio_of_MS2[1][2].slope+all_groups_ratio_of_MS2[2][0].slope+all_groups_ratio_of_MS2[1][2].slope+1);
					deltaL_frac  = 1/(1+all_groups_ratio_of_MS2[2][0].slope);
				} else {
					//game over, skip to next seq family.	    
				}
			} else if (all_groups_ratio_of_MS2[1][0].infinity_indicator==1){ //r2 goes infinity imply r3 goes infinity, VICE VERSA                                                
				if (all_groups_ratio_of_MS2[1][1].infinity_indicator==1){
					alphaL_frac  = all_groups_ratio_of_MS2[0][0].slope/(1+all_groups_ratio_of_MS2[0][0].slope);
					//betaL_frac   = all_groups_ratio_of_MS2[1][2].slope- all_groups_ratio_of_MS2[0][0].slope+1;
					betaL_frac   = ((1+all_groups_ratio_of_MS2[0][0].slope)*(1+all_groups_ratio_of_MS2[1][2].slope)- all_groups_ratio_of_MS2[0][0].slope+all_groups_ratio_of_MS2[1][2].slope)/((1+all_groups_ratio_of_MS2[0][0].slope)*(1+all_groups_ratio_of_MS2[1][2].slope));
					gammaL_frac  = (all_groups_ratio_of_MS2[2][0].slope - all_groups_ratio_of_MS2[1][2].slope)/((1+all_groups_ratio_of_MS2[2][0].slope)*(1+all_groups_ratio_of_MS2[1][2].slope));
					deltaL_frac  = 1/(1+all_groups_ratio_of_MS2[2][0].slope);
				} else {
					//game over, skip to next seq family.	
				}
			} else if (all_groups_ratio_of_MS2[1][1].infinity_indicator==1){//r3 goes infinity 
				if (all_groups_ratio_of_MS2[1][0].infinity_indicator==1){
					alphaL_frac  = all_groups_ratio_of_MS2[0][0].slope/(1+all_groups_ratio_of_MS2[0][0].slope);
					betaL_frac   = all_groups_ratio_of_MS2[1][2].slope- all_groups_ratio_of_MS2[0][0].slope+1;
					gammaL_frac  = (all_groups_ratio_of_MS2[2][0].slope - all_groups_ratio_of_MS2[1][2].slope)/((1+all_groups_ratio_of_MS2[2][0].slope)*(1+all_groups_ratio_of_MS2[1][2].slope));
					deltaL_frac  = 1/(1+all_groups_ratio_of_MS2[2][0].slope);
				} else {
					//game over, skip to next seq family.
				}
			} else if (all_groups_ratio_of_MS2[2][0].infinity_indicator==1){//r4 goes infinity
				alphaL_frac  = all_groups_ratio_of_MS2[0][0].slope/(1+all_groups_ratio_of_MS2[0][0].slope);;
				betaL_frac   = (all_groups_ratio_of_MS2[0][0].slope+ all_groups_ratio_of_MS2[1][2].slope +2)/(all_groups_ratio_of_MS2[0][0].slope*all_groups_ratio_of_MS2[1][2].slope);
				gammaL_frac  = 1/(1+all_groups_ratio_of_MS2[1][2].slope);
				deltaL_frac  = 0;
			} else {

				alphaL_frac  = all_groups_ratio_of_MS2[0][0].slope/(1+all_groups_ratio_of_MS2[0][0].slope);
				beta_below = all_groups_ratio_of_MS2[1][1].slope \
				- (all_groups_ratio_of_MS2[1][0].slope + all_groups_ratio_of_MS2[1][1].slope - all_groups_ratio_of_MS2[0][0].slope)/(all_groups_ratio_of_MS2[0][0].slope +1) +1;
				beta_above = all_groups_ratio_of_MS2[1][0].slope	\
				+ (all_groups_ratio_of_MS2[1][0].slope + all_groups_ratio_of_MS2[1][1].slope - all_groups_ratio_of_MS2[0][0].slope)/(all_groups_ratio_of_MS2[0][0].slope +1); 
				betaL_frac  = beta_above/(beta_above+beta_below);
				gamma_above = all_groups_ratio_of_MS2[1][1].slope - (all_groups_ratio_of_MS2[1][0].slope + all_groups_ratio_of_MS2[1][1].slope - all_groups_ratio_of_MS2[2][0].slope )/(all_groups_ratio_of_MS2[2][0].slope +1) +1;
				gamma_below = all_groups_ratio_of_MS2[1][0].slope + (all_groups_ratio_of_MS2[1][0].slope + all_groups_ratio_of_MS2[1][1].slope - all_groups_ratio_of_MS2[2][0].slope)/(all_groups_ratio_of_MS2[2][0].slope +1);
				gammaL_frac  = gamma_above/(gamma_above+gamma_below);
				deltaL_frac =1/(1+all_groups_ratio_of_MS2[2][0].slope);
			}
		}// if (h==1)

		cout <<  " alphaL_frac  ="<<  alphaL_frac  << endl;
		cout <<  " betaL_frac   ="<<  betaL_frac  << endl;
		cout <<  " gammaL_frac  ="<<  gammaL_frac  << endl;
		cout <<  " deltaL_frac  ="<<  deltaL_frac  << endl;
		stoi_in_single_ms1_peak.push_back(alphaL_frac);
		stoi_in_single_ms1_peak.push_back(betaL_frac);
		stoi_in_single_ms1_peak.push_back(gammaL_frac);
		stoi_in_single_ms1_peak.push_back(deltaL_frac);
	}//if (num_of_K ==4)


	if (num_of_K ==3) {
		float dd[2][2];
		//    const int  MAX=2;
		//float determ(float a[MAX][MAX],int n);

		if (h==0) {
			if (all_groups_ratio_of_MS2[0][0].slope ==0) {
				if (all_groups_ratio_of_MS2[1][0].slope ==0) {
					alphaL_frac=0.000; betaL_frac=1.000;gammaL_frac=1.000;
				} else {
					//game over; go to next sequence family
				}
			} else if (all_groups_ratio_of_MS2[1][0].slope ==0){
				if (all_groups_ratio_of_MS2[0][0].infinity_indicator==1){
					alphaL_frac=1.000; betaL_frac=0.000;gammaL_frac=1.000;
				} else {
					alphaL_frac = all_groups_ratio_of_MS2[0][0].slope/(1.000+all_groups_ratio_of_MS2[0][0].slope); 
					betaL_frac  = 1.000/(1.000+all_groups_ratio_of_MS2[0][0].slope) ;
					gammaL_frac = 1.000;
				}
			} else if (all_groups_ratio_of_MS2[1][0].infinity_indicator==1) {
				if (all_groups_ratio_of_MS2[0][0].infinity_indicator ==1) {
					alphaL_frac=1.000; betaL_frac=1.000; gammaL_frac=0.000;
				} else {
					//game over;
				}
			} else if (all_groups_ratio_of_MS2[0][0].infinity_indicator==1) {
				alphaL_frac =1.000;
				betaL_frac  =all_groups_ratio_of_MS2[1][0].slope/(1.000+all_groups_ratio_of_MS2[1][0].slope); 
				gammaL_frac = 1.000/(1.000+all_groups_ratio_of_MS2[1][0].slope);
			} else {
				dd[0]={-1.000/all_groups_ratio_of_MS2[0][0].slope, 1.000};
				dd[1]={1.000, 1.000};
				D = determ2(dd, 2);
				cout << "D=" << D << endl;
				dd[0][0]=1/all_groups_ratio_of_MS2[0][0].slope;
				dd[1][0]=1/all_groups_ratio_of_MS2[1][0].slope;
				b=determ2(dd, 2)/D;
				cout << "b=" << b << endl;
				dd[0]={-1.000/all_groups_ratio_of_MS2[0][0].slope, 1.000};
				dd[1]={1.000, 1.000};
				dd[0][1]=1/all_groups_ratio_of_MS2[0][0].slope;
				dd[1][1]=1/all_groups_ratio_of_MS2[1][0].slope;
				c = determ2(dd, 2)/D;
				cout << "c=" << c << endl;
				alphaL_frac = (1.00+b)/(1.00+b+c);
				betaL_frac  = (1.00+c)/(1.00+b+c);
				gammaL_frac =    (b+c)/(1.00+b+c);
			}
		} // if (h==0) {
		if (h==1) {
			if (all_groups_ratio_of_MS2[1][0].slope ==0) {
				if (all_groups_ratio_of_MS2[0][0].slope ==0) {
					alphaL_frac=0.000; betaL_frac=0.000; gammaL_frac=1.000;
				} else {
					//game over; go to next sequence family 
				}
			} else if (all_groups_ratio_of_MS2[0][0].slope ==0){
				if (all_groups_ratio_of_MS2[0][0].infinity_indicator==1){
					alphaL_frac=0.000; betaL_frac=1.000;gammaL_frac=0.000;
				} else {
					alphaL_frac = 0.00;
					betaL_frac = all_groups_ratio_of_MS2[1][0].slope/(1.000+all_groups_ratio_of_MS2[1][0].slope);
					gammaL_frac  = 1.000/(1.000+all_groups_ratio_of_MS2[1][0].slope) ;
				}
			} else if (all_groups_ratio_of_MS2[0][0].infinity_indicator==1) {
				if (all_groups_ratio_of_MS2[1][0].infinity_indicator==1){
					alphaL_frac=1.000; betaL_frac=0.000; gammaL_frac=0.000;
				} else {
					//game over; go to next sequence family
				}
			} else if (all_groups_ratio_of_MS2[1][0].infinity_indicator==1){
				alphaL_frac = all_groups_ratio_of_MS2[0][0].slope/(1.000+all_groups_ratio_of_MS2[0][0].slope);
				betaL_frac  = 1.000/(1.000+all_groups_ratio_of_MS2[0][0].slope);
				gammaL_frac = 0;
			} else {

				dd[0]={1.000, 1.000};
				dd[1]={-1.000/all_groups_ratio_of_MS2[1][0].slope, 1.000};
				D = determ2(dd, 2);

				cout << "D=" << D << endl;
				dd[0][0]=1/all_groups_ratio_of_MS2[0][0].slope;
				dd[1][0]=1/all_groups_ratio_of_MS2[1][0].slope;
				b = determ2(dd, 2)/D;
				cout << "b=" << b << endl;

				dd[0]={1.000, 1.000};
				dd[1]={-1.000/all_groups_ratio_of_MS2[1][0].slope, 1.000};
				dd[0][1]=1/all_groups_ratio_of_MS2[0][0].slope;
				dd[1][1]=1/all_groups_ratio_of_MS2[1][0].slope;
				c = determ2(dd, 2)/D;
				cout << "c=" << c << endl;

				alphaL_frac = 1/(1+b+c);
				betaL_frac = b/(1+b+c);
				gammaL_frac = c/(1+b+c);
			}
		}//if (h==1)

		cout <<  " alphaL_frac  ="<<  alphaL_frac  << endl;
		cout <<  " betaL_frac   ="<<  betaL_frac  << endl;
		cout <<  " gammaL_frac  ="<<  gammaL_frac  << endl;
		stoi_in_single_ms1_peak.push_back(alphaL_frac);
		stoi_in_single_ms1_peak.push_back(betaL_frac);
		stoi_in_single_ms1_peak.push_back(gammaL_frac);
	} //if (num_of_K ==3)

	if (num_of_K ==2) {
		if (h==0) {
			if (all_groups_ratio_of_MS2[0][0].slope ==0) {
				alphaL_frac=0.000; betaL_frac=1.000;
			} else if (all_groups_ratio_of_MS2[0][0].infinity_indicator==1){
				alphaL_frac=1.000; betaL_frac=0.000;
			} else {
				alphaL_frac = all_groups_ratio_of_MS2[0][0].slope/(1.000+all_groups_ratio_of_MS2[0][0].slope);
				betaL_frac  = 1.000/(1.000+all_groups_ratio_of_MS2[0][0].slope) ;
			}
		} else {
			cout << "Oh!Oh! something wrong in your case of peptide of 2 lysines." << endl;
		}
		cout <<  " alphaL_frac  ="<<  alphaL_frac  << endl;
		cout <<  " betaL_frac   ="<<  betaL_frac  << endl;
		stoi_in_single_ms1_peak.push_back(alphaL_frac);
		stoi_in_single_ms1_peak.push_back(betaL_frac);
	}


}


/*
float determ2(float a[2][2], const int n) {
float det;
det=(a[0][0]*a[1][1]-a[0][1]*a[1][0]);
return det;
}
*/
float determ2(float a[2][2], int n) {
	float det;
	if(n==2) {
		det=(a[0][0]*a[1][1]-a[0][1]*a[1][0]);
		return det;
	} else {
		cout << "Wrong! Not 2." << endl;
	}

}

float determ(float a[MAX][MAX], int n) {
	int p, h, k, i, j; 
	float det=0.0;
	float temp[MAX][MAX];
	if(n==1) {
		return a[0][0];
	} else if(n==2) {
		det=(a[0][0]*a[1][1]-a[0][1]*a[1][0]);
		return det;
	} else {
		for(p=0;p<n;p++) {
			h = 0;
			k = 0;
			for(i=1;i<n;i++) {
				for( j=0;j<n;j++) {
					if(j==p) {
						continue;
					}
					temp[h][k] = a[i][j];
					k++;
					if(k==n-1) {
						h++;
						k = 0;
					}
				}
			}
			det=det+a[0][p]*pow(-1,p)*determ(temp,n-1);
		}
		return det;
	}
}


