#!/bin/bash
perl ../MS2perl/MS2perl_t.pl msms.txt input_of_MS2C > trace1
../MS2C/ms2c input_of_MS2C > trace2
perl ../MS1perl/MS1perl_p1.pl evidence.txt ms2dic.txt > trace3
perl ../MS1perl/MS1perl_p2.pl out_no_mod_Nterm > out_no_mod_Nterm2_given
perl ../MS1perl/MS1perl_t.pl
../MS1C/ms1c out1K ms2dic.txt ./  1.00000E-05 2.5000E-06 1Kout1 1Kout2 > trace-1K
../MS1C/ms1c out2K ms2dic.txt ./  1.00000E-05 2.5000E-06 2Kout1 2Kout2 > trace-2K
../MS1C/ms1c out3K ms2dic.txt ./  1.00000E-05 2.5000E-06 3Kout1 3Kout2 > trace-3K
../MS1C/ms1c out4K ms2dic.txt ./  1.00000E-05 2.5000E-06 4Kout1 4Kout2 > trace-4K
grep 'total' trace-1K > Output-1K.txt
grep 'total' trace-2K > Output-2K.txt
grep 'total' trace-3K > Output-3K.txt
grep 'total' trace-4K > Output-4K.txt
