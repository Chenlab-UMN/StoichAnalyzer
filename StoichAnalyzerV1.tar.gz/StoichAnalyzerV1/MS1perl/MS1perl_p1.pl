#/usr/bin/perl
# usage:
#   perl *.pl evidence.txt test.txt > output
# PART A includes the top and the bottom.
# PART B is in the middle
# PART A1 (top) is building the dictionary for PART A2 (bottom)
# They are used to give number of C, H, O, N,....
# PART B is to extract out the information from evidence file such as score, best_scannumber,
# We found that ms1 summary file cannot give us enough info. so we just directly use evidence.txt
# 
## PART B
 
my ($file1, $file2) = @ARGV;
open my $fh1, '<', $file1;
open my $fh2, '<', $file2;
open my $fouth, '>', "out_ah_Nterm" or die $!;
open my $foutc, '>', "out_ac_Nterm" or die $!;
open my $foutn, '>', "out_no_mod_Nterm" or die $!;

foreach $line (<$fh1>) {
    chomp($line);
    if ($line =~ /^Sequence/) {
	@cell06 = split(/\t/, $line);
	$size_cell06 = @cell06;
	for($i=0; $i<$size_cell06; $i++){
	    if  ($cell06[$i] eq "Modified sequence") {
                $seq_col = $i;
            }
            if  ($cell06[$i] eq "Raw file") {
                $file_col = $i;
            }
	    if  ($cell06[$i] eq "Score") {
                $score_col = $i;
            }
            if  ($cell06[$i] eq "Charge") {
                $charge_col = $i;
            }
	    if  ($cell06[$i] eq "m/z") {
		$mz_col = $i;
            }
            if  ($cell06[$i] eq "MS/MS Scan Number") {
                $scan_col = $i;
            }
	    if  ($cell06[$i] eq "Intensity") {
		$Intens_col = $i;
	    }
	    if  ($cell06[$i] eq "Leading Proteins") {
                $Lprot_col = $i;
            }
        }
    } else {
	@cell = split(/\t/, $line);
	$new_seq = $cell[$seq_col];
	$new_fname = $cell[$file_col];
	$new_score = $cell[$score_col];
	$new_charge = $cell[$charge_col];
	$new_mz = $cell[$mz_col];
        $new_scan = $cell[$scan_col];
	$new_Intens = $cell[$Intens_col];
	$Lprot = $cell[$Lprot_col];
	if ($Lprot =~ /^REV\_/) {
	    next;
	}
	if ($Lprot =~ /^CON\_/) {
            next;
        }
	$num_of_K  = scalar(@{[$new_seq =~ /K/g]});
	$num_of_Kah = scalar(@{[$new_seq =~ /K\(ah\)/g]});
	$num_of_Kac = scalar(@{[$new_seq =~ /K\(ac\)/g]});
	if (($num_of_Kah + $num_of_Kac) ne $num_of_K) {
	    next;   ## KICK OUT the cases containing FREE K.
	}
	if ($num_of_K == 0) {
	    next;   
	}

	if (exists $seqtoIntens{$new_seq}){	    
	    if ($new_Intens > $seqtoIntens{$new_seq}) {
		$seqtoscore{$new_seq} = $new_score;
		$seqtofname{$new_seq} = $new_fname;
		$seqtocharge{$new_seq} = $new_charge;
		$seqtomz{$new_seq} = $new_mz;
		$seqtoscan{$new_seq} = $new_scan;
		$seqtoIntens{$new_seq} = $new_Intens;
	    } 
        } else {
#           print "checkpt 2:  $new_seq\n";
	    $seqtoscore{$new_seq} = $new_score;
	    $seqtofname{$new_seq} = $new_fname;
	    $seqtocharge{$new_seq} = $new_charge;
	    $seqtomz{$new_seq} = $new_mz;
	    $seqtoscan{$new_seq} = $new_scan;
	    $seqtoIntens{$new_seq} = $new_Intens;
#	    @cell2 = split(/[\(ac\)ahoxdi]/,$new_seq);
	    @cell2 = split(/\(a[c|h]\)/,$new_seq);
	    $size2 = @cell2;
	    $c="";
	    for($i=0; $i<$size2; $i++){
		$c=$c.$cell2[$i];
	    }

	    $seqto_pureseq{$new_seq} = $c;
#    print "checkpt 1:   $new_string    $new_fname\n";
	}
    } ##  if ($line =~ /^Sequence/) {} else
}
close $fh1;
#print "size of hash \%seqtoscore:  " . keys(%seqtoscore) . ".\n";

#print "$_ $h{$_}\n" for keys %seqtoscore;

my $temp;
foreach $temp (keys %seqtoscore) { 

    $pureseq = $seqto_pureseq{$temp};
    $charge = $seqtocharge{$temp};
    $Intens = $seqtoIntens{$temp};
    $score =  $seqtoscore{$temp};
    $fname =  $seqtofname{$temp};

##    print $pureseq,' ', $charge, ' ', $Intens,"\n";

    if  (exists $pureseqtoIntens2{$pureseq}){
	if ($Intens > $pureseqtoIntens2{$pureseq}) {
	    $seq_to_familyfname{$pureseq} = $fname;
	    $seq_to_familycharge{$pureseq} = $charge;
	    $pureseqtoIntens2{$pureseq} = $Intens;
	}
    } else {
	$seq_to_familyfname{$pureseq} = $fname;
	$seq_to_familycharge{$pureseq} = $charge;
	$pureseqtoIntens2{$pureseq} = $Intens;
    }

    if  (exists $pureseqtoScore{$pureseq}){
	if ($score > $pureseqtoScore{$pureseq}) {
	    $seq_to_familyfname2{$pureseq} = $fname;
	    $seq_to_familycharge2{$pureseq} = $charge;
	    $pureseqtoScore{$pureseq} = $score;
	}
    } else {
	$seq_to_familyfname2{$pureseq} = $fname;
	$seq_to_familycharge2{$pureseq} = $charge;
	$pureseqtoScore{$pureseq} = $score;
    }

    
    if  (exists $flag{$pureseq}){
    } else {
	$flag{$pureseq} = 0;
    } ##to generate an entity in hash and initialize it as zero.

    if ( $Intens == 0 ) {
	$flag{$pureseq} = 1; ## 1 means use score & $seq_to_familycharge2
    }
}

#print "AAA\n";

foreach $line (<$fh2>) {
    chomp($line);
    @cellms2 = split(/\s/, $line);
    $ms2new_seq = $cellms2[0];
    $ppeakorder = $cellms2[2]; 
#    print $ms2new_seq,"\n";
    if (exists $MS2seqtopp{$ms2new_seq}){
    } else {
	$MS2seqtopp{$ms2new_seq} = $ppeakorder;
    }
}
close $fh2;

#print "BBB\n";


foreach $key (sort(keys %seqtomz)) {
#    $outcome= getformula($key, \%aaAllnum);
    $num_of_K   = scalar(@{[$key =~ /K/g]});
    $num_of_Kah = scalar(@{[$key =~ /K\(ah\)/g]});
    $num_of_Kac = scalar(@{[$key =~ /K\(ac\)/g]});
    if (($num_of_Kah + $num_of_Kac) ne $num_of_K) {
        next;      ## KICK OUT the cases containing FREE K.
    }
#    $peak_order=$num_of_Kah+1;
    
    $MS2indicator=0;
    if (exists $MS2seqtopp{$seqto_pureseq{$key}}){ 
	$MS2indicator=1;
    }

    if ($flag{$seqto_pureseq{$key}} == 0) {
	$fcharge = $seq_to_familycharge{$seqto_pureseq{$key}};
	$ffname = $seq_to_familyfname{$seqto_pureseq{$key}};
    } else {
	$fcharge = $seq_to_familycharge2{$seqto_pureseq{$key}};
	$ffname = $seq_to_familyfname2{$seqto_pureseq{$key}};
    }

    #print $seqto_pureseq{$key},' ',$key,' ',$seqtocharge{$key},' ',$seqtomz{$key},' ',$ffname,' ',$seqtoscan{$key},' ',$num_of_K,' ',$peak_order,' ',$MS2indicator,' ',$fcharge,"\n";

    $num_of_ahN = scalar(@{[$key =~ /\_\(ah\)/g]});
    $num_of_acN = scalar(@{[$key =~ /\_\(ac\)/g]});
    if ( $seqtocharge{$key} ==  $fcharge ) { 

	if (($num_of_ahN == 0) && ($num_of_acN == 0 )) {
	    print $foutn   $seqto_pureseq{$key},' ',$key,' ',$fcharge,' ',$seqtomz{$key},' ',$ffname,' ',$seqtoscan{$key},' ',$MS2indicator,"\n";
	}
	if ($num_of_ahN > 0) {
	    print $fouth   $seqto_pureseq{$key},' ',$key,' ',$fcharge,' ',$seqtomz{$key},' ',$ffname,' ',$seqtoscan{$key},' ',$MS2indicator,"\n";
        }
        if ($num_of_acN > 0) {
            print $foutc   $seqto_pureseq{$key},' ',$key,' ',$fcharge,' ',$seqtomz{$key},' ',$ffname,' ',$seqtoscan{$key},' ',$MS2indicator,"\n";
        }
	## here we throw away the case in which the precursor charge is different from family charge, because
	## 1. if we print it out now, in the next perl program it will replace the "scan_num(default:-1)" and "mz value calculated by fcharge". 
	## 2. if ($seqtocharge{$key} !=  $fcharge) then the case ($ffname ne $fname) may be possible, but we cannot  quantify the species in 
        ##    the same family by using the data coming from different raw files(referring different LC conditions).
    }

}


#foreach $key(sort keys %data){
#    my $dudu = substr $key, 0, (length($key)-length($data{$key}));
#    $outcome= getformula($seq[$data{$key}], \%aaAllnum);
#    if ($seq[$data{$key}] ne $pre_seq){
#      print "$dudu $seq[$data{$key}] $charge[$data{$key}] $mz[$data{$key}] $rawf[$data{$key}] $scann[$data{$key}] $outcome\n";
#    }
#    $pre_seq = $seq[$data{$key}];
#}




