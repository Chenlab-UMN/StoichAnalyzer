#/usr/bin/perl
# usage:
#   perl *.pl evidence.txt test.txt > output
# PART A includes the top and the bottom.
# PART B is in the middle
# PART A1 (top) is building the dictionary for PART A2 (bottom)
# They are used to give number of C, H, O, N,....
# PART B is to extract out the information from evidence file such as score, best_scannumber,
# We found that ms1 summary file cannot give us enough info. so we just directly use evidence.txt
# 
## PART B
#my ($file1, $file2) = @ARGV;
use Switch;

$aaMass{"A"}= 71.0371137900;
$aaMass{"G"}= 57.0214637260;
$aaMass{"S"}= 87.0320284100;
$aaMass{"T"}=101.0476784740;
$aaMass{"C"}=160.0306485;              ##103.009184800;
$aaMass{"V"}= 99.0684139180;
$aaMass{"L"}=113.0840639820;
$aaMass{"I"}=113.0840639820;
$aaMass{"M"}=131.040484900;
$aaMass{"P"}= 97.0527638540;
$aaMass{"F"}=147.0684139180;
$aaMass{"Y"}=163.0633285380;
$aaMass{"W"}=186.0793129600;
$aaMass{"D"}=115.0269430300;
$aaMass{"E"}=129.0425930940;
$aaMass{"N"}=114.0429274520;
$aaMass{"Q"}=128.0585775160;
$aaMass{"H"}=137.0589118740;
$aaMass{"K"}=128.0949630240;
$aaMass{"R"}=156.1011110440;

$mass_ac = 47.0361046 - 5.025539917; ## 42.0105646830
$mass_ah = 47.0361046;
$mass_HO =  17.002739652;
$mass_H =  1.007825032;
$mass_dif_3DH = 5.025539917;

my ($file1) = @ARGV;
open my $fh1, '<', $file1;  ## $file1 is the output of p6-2.pl 
#open my $fh2, '<', $file2;

##print $seqto_pureseq{$key},' ',$key,' ',$seqtocharge{$key},' ',$seqtomz{$key},' ', $seqtofname{$key},' ',$seqtoscan{$key},' ',$num_of_K,' ',$peak_order,' ',$MS2indicator,' ',$fcharge,"\n";

#  $num_of_Kah = scalar(@{[$seq =~ /K\(ah\)/g]});
#  $peak_order=$num_of_Kah+1;

foreach $line (<$fh1>) {
    chomp($line);
    @cell = split(' ', $line);
    $size_cell = @cell;
    if ($size_cell != 7) {
	next;
    }
    
    $pureseq= $cell[0];
    $seq    = $cell[1];
    $fcharge = $cell[2];
    $mz     = $cell[3];
    $fname  = $cell[4];
    $scan   = $cell[5];
    $MS2indicator=$cell[6];
  
    if  (exists $pureseqtofcharge{$pureseq}){
        $num_of_Kah = scalar(@{[$seq =~ /K\(ah\)/g]});
        switch($num_of_Kah){
            case 0   { $pureseqtop1scan{$pureseq}=$scan;  $pureseqtop1ms2{$pureseq}=$MS2indicator;  $pureseqtop1mz{$pureseq}=$mz;}
            case 1   { $pureseqtop2scan{$pureseq}=$scan;  $pureseqtop2ms2{$pureseq}=$MS2indicator;  $pureseqtop2mz{$pureseq}=$mz;}
            case 2   { $pureseqtop3scan{$pureseq}=$scan;  $pureseqtop3ms2{$pureseq}=$MS2indicator;  $pureseqtop3mz{$pureseq}=$mz;}
            case 3   { $pureseqtop4scan{$pureseq}=$scan;  $pureseqtop4ms2{$pureseq}=$MS2indicator;  $pureseqtop4mz{$pureseq}=$mz;}
            case 4   { $pureseqtop5scan{$pureseq}=$scan;  $pureseqtop5ms2{$pureseq}=$MS2indicator;  $pureseqtop5mz{$pureseq}=$mz;}
        }
    } else {
	$pureseqtofcharge{$pureseq} = $fcharge;
	$pureseqtofname{$pureseq} = $fname;
	$pureseqtoseq{$pureseq} = $seq; # we only take first modified seq because it is not useful in MS1.cpp. 
                                        # Sure if you like use the same way as  $pureseqtop1mz{$pureseq} 
	$pureseqtop1scan{$pureseq}  = -1;
	$pureseqtop2scan{$pureseq}  = -1;
	$pureseqtop3scan{$pureseq}  = -1;
	$pureseqtop4scan{$pureseq}  = -1;
	$pureseqtop5scan{$pureseq}  = -1;
	$pureseqtop1ms2{$pureseq}  = 0;
        $pureseqtop2ms2{$pureseq}  = 0;
        $pureseqtop3ms2{$pureseq}  = 0;
        $pureseqtop4ms2{$pureseq}  = 0;
        $pureseqtop5ms2{$pureseq}  = 0;

	$ref_mass_theo = getmass($pureseq,\%aaMass) + $mass_HO + $mass_H*$fcharge;
	$given_mass = $mz * $fcharge;

  	$num_of_K   = scalar(@{[$seq =~ /K/g]});
	$term_ah =  scalar(@{[$seq =~ /\_\(ah\)/g]});
	$term_ac =  scalar(@{[$seq =~ /\_\(ac\)/g]});

	$diff = ($given_mass - $ref_mass_theo)/47.0361046;  
	if (($diff < 1.001) && ($diff > 0.999)){      ## if this sequence containing extractly 1 ah.
	    $ref_mass_theo = $given_mass - 47.0361046; 
	}
	if (($diff < 2.001) && ($diff > 1.999)){      ## if this sequence containing extractly 2 ah.
            $ref_mass_theo = $given_mass - 2*47.0361046;
        }
        if (($diff < 3.001) && ($diff > 2.999)){      ## if this sequence containing extractly 3 ah.
            $ref_mass_theo = $given_mass - 3*47.0361046;
        }
        if (($diff < 4.001) && ($diff > 3.999)){      ## if this sequence containing extractly 4 ah.
            $ref_mass_theo = $given_mass - 4*47.0361046;
        }
        if (($diff < 5.001) && ($diff > 4.999)){      ## if this sequence containing extractly 5 ah.
            $ref_mass_theo = $given_mass - 5*47.0361046;
        }

        $diff = ($given_mass - $ref_mass_theo - 42.0105646830)/47.0361046;
	if (($diff < 0.001) && ($diff > -0.001)){      ## if this sequence containing extractly 0 ah and 1 ac
            $ref_mass_theo = $given_mass - 42.0105646830;
        }
        if (($diff < 1.001) && ($diff > 0.999)){      ## if this sequence containing extractly 1 ah and 1 ac
            $ref_mass_theo = $given_mass - 47.0361046 - 42.0105646830;
        }
        if (($diff < 2.001) && ($diff > 1.999)){      ## if this sequence containing extractly 2 ah and 1 ac
            $ref_mass_theo = $given_mass - 2*47.0361046 - 42.0105646830;
        }
        if (($diff < 3.001) && ($diff > 2.999)){      ## if this sequence containing extractly 3 ah and 1 ac
            $ref_mass_theo = $given_mass - 3*47.0361046 - 42.0105646830;
        }
        if (($diff < 4.001) && ($diff > 3.999)){      ## if this sequence containing extractly 4 ah and 1 ac
            $ref_mass_theo = $given_mass - 4*47.0361046 - 42.0105646830;
        }

        $diff = ($given_mass - $ref_mass_theo - 42.0105646830*2)/47.0361046;
        if (($diff < 0.001) && ($diff > -0.001)){      ## if this sequence containing extractly 0 ah and 2 ac
            $ref_mass_theo = $given_mass - 42.0105646830*2;
        }
        if (($diff < 1.001) && ($diff > 0.999)){      ## if this sequence containing extractly 1 ah and 2 ac
            $ref_mass_theo = $given_mass - 47.0361046 - 42.0105646830*2;
        }
        if (($diff < 2.001) && ($diff > 1.999)){      ## if this sequence containing extractly 2 ah and 2 ac
            $ref_mass_theo = $given_mass - 2*47.0361046 - 42.0105646830*2;
        }
        if (($diff < 3.001) && ($diff > 2.999)){      ## if this sequence containing extractly 3 ah and 2 ac
            $ref_mass_theo = $given_mass - 3*47.0361046 - 42.0105646830*2;
        }

        $diff = ($given_mass - $ref_mass_theo - 42.0105646830*3)/47.0361046;
        if (($diff < 0.001) && ($diff > -0.001)){      ## if this sequence containing extractly 0 ah and 3 ac
            $ref_mass_theo = $given_mass - 42.0105646830*3;
        }
        if (($diff < 1.001) && ($diff > 0.999)){      ## if this sequence containing extractly 1 ah and 3 ac
            $ref_mass_theo = $given_mass - 47.0361046 - 42.0105646830*3;
        }
        if (($diff < 2.001) && ($diff > 1.999)){      ## if this sequence containing extractly 2 ah and 3 ac
            $ref_mass_theo = $given_mass - 2*47.0361046 - 42.0105646830*3;
        }



	if (($term_ah==0)&&($term_ac==0)) {
	    $pureseqtop1mz{$pureseq} = ($ref_mass_theo+$mass_ac*$num_of_K)/$fcharge;
	    $pureseqtop2mz{$pureseq} = ($ref_mass_theo+$mass_ac*($num_of_K-1)+$mass_ah) /$fcharge;
	    $pureseqtop3mz{$pureseq} = ($ref_mass_theo+$mass_ac*($num_of_K-2)+$mass_ah*2)/$fcharge;
	    $pureseqtop4mz{$pureseq} = ($ref_mass_theo+$mass_ac*($num_of_K-3)+$mass_ah*3)/$fcharge;
	    $pureseqtop5mz{$pureseq} = ($ref_mass_theo+$mass_ac*($num_of_K-4)+$mass_ah*4)/$fcharge;
	}
        if (($term_ah==1)&&($term_ac==0)) {
	    $pureseqtop1mz{$pureseq} = ($ref_mass_theo+$mass_ac*$num_of_K    +$mass_ah) / $fcharge;
	    $pureseqtop2mz{$pureseq} = ($ref_mass_theo+$mass_ac*($num_of_K-1)+$mass_ah*2) /$fcharge;
	    $pureseqtop3mz{$pureseq} = ($ref_mass_theo+$mass_ac*($num_of_K-2)+$mass_ah*3)/$fcharge;
	    $pureseqtop4mz{$pureseq} = ($ref_mass_theo+$mass_ac*($num_of_K-3)+$mass_ah*4)/$fcharge;
	    $pureseqtop5mz{$pureseq} = ($ref_mass_theo+$mass_ac*($num_of_K-4)+$mass_ah*5)/$fcharge;
        }

        if (($term_ah==0)&&($term_ac==1)) {
            $pureseqtop1mz{$pureseq} = ($ref_mass_theo+$mass_ac*($num_of_K+1))/$fcharge;
            $pureseqtop2mz{$pureseq} = ($ref_mass_theo+$mass_ac*($num_of_K)+$mass_ah) /$fcharge;
            $pureseqtop3mz{$pureseq} = ($ref_mass_theo+$mass_ac*($num_of_K-1)+$mass_ah*2)/$fcharge;
            $pureseqtop4mz{$pureseq} = ($ref_mass_theo+$mass_ac*($num_of_K-2)+$mass_ah*3)/$fcharge;
            $pureseqtop5mz{$pureseq} = ($ref_mass_theo+$mass_ac*($num_of_K-3)+$mass_ah*4)/$fcharge;
        }


	$num_of_Kah = scalar(@{[$seq =~ /K\(ah\)/g]});

	switch($num_of_Kah){
	    case 0   { $pureseqtop1scan{$pureseq}=$scan;  $pureseqtop1ms2{$pureseq}=$MS2indicator; $pureseqtop1mz{$pureseq}=$mz;}
	    case 1   { $pureseqtop2scan{$pureseq}=$scan;  $pureseqtop2ms2{$pureseq}=$MS2indicator; $pureseqtop2mz{$pureseq}=$mz;}
	    case 2   { $pureseqtop3scan{$pureseq}=$scan;  $pureseqtop3ms2{$pureseq}=$MS2indicator; $pureseqtop3mz{$pureseq}=$mz;}
	    case 3   { $pureseqtop4scan{$pureseq}=$scan;  $pureseqtop4ms2{$pureseq}=$MS2indicator; $pureseqtop4mz{$pureseq}=$mz;}
	    case 4   { $pureseqtop5scan{$pureseq}=$scan;  $pureseqtop5ms2{$pureseq}=$MS2indicator; $pureseqtop5mz{$pureseq}=$mz;}
	}

    }
}## foreach $line (<$fh1>) 
close $fh1;

foreach $key (sort(keys %pureseqtofcharge)) {

    $num_of_K   = scalar(@{[$key =~ /K/g]});
    switch($num_of_K){
	case 1 {
	    print $key,' ',$pureseqtoseq{$key},' ',$pureseqtofcharge{$key},' ', $pureseqtop2mz{$key},' ',$pureseqtofname{$key},' ',$pureseqtop2scan{$key},' ',$num_of_K,' 2 ',$pureseqtop2ms2{$key},"\n";
	    print $key,' ',$pureseqtoseq{$key},' ',$pureseqtofcharge{$key},' ', $pureseqtop1mz{$key},' ',$pureseqtofname{$key},' ',$pureseqtop1scan{$key},' ',$num_of_K,' 1 ',$pureseqtop1ms2{$key},"\n"; 
	}
        case 2 {
            print $key,' ',$pureseqtoseq{$key},' ',$pureseqtofcharge{$key},' ', $pureseqtop3mz{$key},' ',$pureseqtofname{$key},' ',$pureseqtop3scan{$key},' ',$num_of_K,' 3 ',$pureseqtop3ms2{$key},"\n";
            print $key,' ',$pureseqtoseq{$key},' ',$pureseqtofcharge{$key},' ', $pureseqtop2mz{$key},' ',$pureseqtofname{$key},' ',$pureseqtop2scan{$key},' ',$num_of_K,' 2 ',$pureseqtop2ms2{$key},"\n";
            print $key,' ',$pureseqtoseq{$key},' ',$pureseqtofcharge{$key},' ', $pureseqtop1mz{$key},' ',$pureseqtofname{$key},' ',$pureseqtop1scan{$key},' ',$num_of_K,' 1 ',$pureseqtop1ms2{$key},"\n";
        }
        case 3 {
            print $key,' ',$pureseqtoseq{$key},' ',$pureseqtofcharge{$key},' ', $pureseqtop4mz{$key},' ',$pureseqtofname{$key},' ',$pureseqtop4scan{$key},' ',$num_of_K,' 4 ',$pureseqtop4ms2{$key},"\n";
            print $key,' ',$pureseqtoseq{$key},' ',$pureseqtofcharge{$key},' ', $pureseqtop3mz{$key},' ',$pureseqtofname{$key},' ',$pureseqtop3scan{$key},' ',$num_of_K,' 3 ',$pureseqtop3ms2{$key},"\n";
            print $key,' ',$pureseqtoseq{$key},' ',$pureseqtofcharge{$key},' ', $pureseqtop2mz{$key},' ',$pureseqtofname{$key},' ',$pureseqtop2scan{$key},' ',$num_of_K,' 2 ',$pureseqtop2ms2{$key},"\n";
            print $key,' ',$pureseqtoseq{$key},' ',$pureseqtofcharge{$key},' ', $pureseqtop1mz{$key},' ',$pureseqtofname{$key},' ',$pureseqtop1scan{$key},' ',$num_of_K,' 1 ',$pureseqtop1ms2{$key},"\n";
        }
        case 4 {
            print $key,' ',$pureseqtoseq{$key},' ',$pureseqtofcharge{$key},' ', $pureseqtop5mz{$key},' ',$pureseqtofname{$key},' ',$pureseqtop5scan{$key},' ',$num_of_K,' 5 ',$pureseqtop5ms2{$key},"\n";
            print $key,' ',$pureseqtoseq{$key},' ',$pureseqtofcharge{$key},' ', $pureseqtop4mz{$key},' ',$pureseqtofname{$key},' ',$pureseqtop4scan{$key},' ',$num_of_K,' 4 ',$pureseqtop4ms2{$key},"\n";
            print $key,' ',$pureseqtoseq{$key},' ',$pureseqtofcharge{$key},' ', $pureseqtop3mz{$key},' ',$pureseqtofname{$key},' ',$pureseqtop3scan{$key},' ',$num_of_K,' 3 ',$pureseqtop3ms2{$key},"\n";
            print $key,' ',$pureseqtoseq{$key},' ',$pureseqtofcharge{$key},' ', $pureseqtop2mz{$key},' ',$pureseqtofname{$key},' ',$pureseqtop2scan{$key},' ',$num_of_K,' 2 ',$pureseqtop2ms2{$key},"\n";
            print $key,' ',$pureseqtoseq{$key},' ',$pureseqtofcharge{$key},' ', $pureseqtop1mz{$key},' ',$pureseqtofname{$key},' ',$pureseqtop1scan{$key},' ',$num_of_K,' 1 ',$pureseqtop1ms2{$key},"\n";
        }
    }

}

sub getmass {
    my $seq = shift;
    my $aacount  = shift;
    my %aaMo = %{$aacount};
    my $mass = 0;
    ##C2D3H(-1)O = 45.0293949220 (all heavy and light are assign no natural isotope distributed.)
    ##C13_2D3H(-1)O = 47.0361046
    $mass += (47.0361046-5.025539917)*scalar(@{[$seq =~ /\(ac\)/g]});##because we want get heaviest here!
    $mass += 47.0361046*scalar(@{[$seq =~ /\(ah\)/g]});
    $mass += 15.99491462*scalar(@{[$seq =~ /\(ox\)/g]});
    $mass += 79.96633041*scalar(@{[$seq =~ /\(ph\)/g]});
    ##we still need add many modification masses here
    $seq =~ s/_//g;
    $seq =~ s/\([a-z]*\)//g;
    while($seq=~/./g){
        $mass += $aaMo{$&};
    }
    $mass += $mass_H; ## not water but proton ....because it is b-ion not parent peptide
                      ## This give you complete NH2 on N-terminal but CO only on C-terminal.
    return $mass;
}

#foreach $key(sort keys %data){
#    my $dudu = substr $key, 0, (length($key)-length($data{$key}));
#    $outcome= getformula($seq[$data{$key}], \%aaAllnum);
#    if ($seq[$data{$key}] ne $pre_seq){
#      print "$dudu $seq[$data{$key}] $charge[$data{$key}] $mz[$data{$key}] $rawf[$data{$key}] $scann[$data{$key}] $outcome\n";
#    }
#    $pre_seq = $seq[$data{$key}];
#}






