#/usr/bin/perl
##my ($infile, $outfile) = @ARGV;
##open my $fin1, '<', $infile;

#my ($file1, $file2) = @ARGV;
#open my $fh1, '<', $file1;
#open my $fh2, '<', $file2;


open my $fin1, '<', "out_no_mod_Nterm2_given" or die $!;
open my $fout1,'>', "out1K" or die $!;
open my $fout2,'>', "out2K" or die $!;
open my $fout3,'>', "out3K" or die $!;
open my $fout4,'>', "out4K" or die $!;

##open my $fh2, '<', $file2;
##open my $fout1, '>', $outfile or die $!;
##open my $fout2, '>', "out-data" or die $!;

foreach $line (<$fin1>) {
    chomp($line);
    @cell01 = split(/\s+/, $line);
    @cell02 = split(//,$cell01[0]);
    $size_cell02=@cell02;
    ##print $fout1 $cell02[4]," ",$cell02[5]," ",$size_cell02,"\n";
    $num_of_K=0;
    for($i=0; $i<@cell02; $i++) {
	if ($cell02[$i] eq "K"){
	    $num_of_K++;	
    } }
    ##print $fout1 $num_of_K,"\n";
    if ($num_of_K eq 1) {
	print $fout1 $line,"\n";
    }
    if ($num_of_K eq 2) {
        print $fout2 $line,"\n";
    }
    if ($num_of_K eq 3) {
        print $fout3 $line,"\n";
    }
    if ($num_of_K eq 4) {
        print $fout4 $line,"\n";
    }
#    $num_of_K = {$cell01[0]=~ m/K(\d+)/}; 
#    if ($1 == 3) {
#	print $fout1 $line,"\n";	
#    }
}




